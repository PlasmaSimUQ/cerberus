/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// Interface to different RANDOM NUMBER GENERATORS                             //
// Make generators interchangeable                                             //                 
//                                                                             //
// Burkhard Militzer                                    Urbana 1998            //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////

#ifndef _RANDOM_
#define _RANDOM_

#include "Standard.h"

#include <stdlib.h>
inline void InitRandom(const bool randomSeedFlag, const int stream=0) {
  if (randomSeedFlag || stream>0) error("No implemented for DRAND48");

  // added to run properly on G5 using gcc 3.3
  unsigned short seed16v[3]={0,0,0};
  //  unsigned short *j;
  //  j = seed48(seed16v);
  seed48(seed16v);
}

inline double Random() { 
  return drand48();
}

#endif // _RANDOM_
