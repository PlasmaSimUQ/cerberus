from matplotlib.pyplot import *
import numpy
import sys
import os

fig_size = [800/72.27 ,700/72.27]
params = {'backend': 'ps', 'axes.labelsize': 25, 'font.size': 25, 'legend.fontsize': 20,
          'xtick.labelsize': 25, 'ytick.labelsize': 25, 
          'xtick.major.size': 15,'ytick.major.size': 15,
          'xtick.minor.size': 8,'ytick.minor.size': 8,
          'text.usetex': False, 'figure.figsize': fig_size, 'xtick.major.pad': 9,
          'figure.subplot.top': 0.94,'figure.subplot.left': 0.105,'figure.subplot.bottom': 0.095,'figure.subplot.right': 0.978}
#'figure.subplot.bottom': 0.097

rcParams.update(params)
a=subplot(111)

title_ = "First-Principles Equation of State Database";
if (len(sys.argv)>1):
   title_ = str(sys.argv[1])
title(title_)

scriptName = sys.argv[0][:-3]; # [:3] removes ".py" for file name 
try:
   os.remove(scriptName+'.pdf')
   os.remove(scriptName+'.png')
except:
   pass

##############################################################################################################################

d  = numpy.loadtxt('FPEOS_adiabats.txt',usecols=(1,3,7,9,11)); # index,rho,T,P,E
iMin = int(min(d[:,0]))
iMax = int(max(d[:,0]))
# print(iMin,iMax)

for i in range(iMin,iMax+1):
    ii = (d[:,0]==i)
    if (np.where(ii==True)[0].shape[0]>0):
        iii = np.where(ii==True)[0][0]

        label = ''
        if (i==iMin): label='Isentrope'
        plot(d[ii,3],d[ii,2],'--', linewidth=1, markersize=0,color='b',mec='k',mew=2, dashes=(12,2,2,2),mfc='white',label=label);

##############################################################################################################################

d  = numpy.loadtxt('FPEOS_isochor_points.txt',usecols=(1,3,7,9,13)); # index,rho,T,P,E
iMin = int(min(d[:,0]))
iMax = int(max(d[:,0]))
# print(iMin,iMax)

for i in range(iMin,iMax+1):
    ii = (d[:,0]==i)
    if (np.where(ii==True)[0].shape[0]>0):
        iii = np.where(ii==True)[0][0]

        label = ''
        if (i==iMin): label='Isochore'
        plot(d[ii,3],d[ii,2],'o-', linewidth=1, markersize=5,color='k',mec='k',mew=1, mfc='yellow',label=label);

##############################################################################################################################
hug = numpy.loadtxt('FPEOS_Hugoniot.txt',usecols=(1,3,7,9,13)); # T,rho/rho0,rho,P,E

cx = 3
cy = 0
plot(hug[:,cx],hug[:,cy],'-', linewidth=5, markersize=0,color='r',mec='r',mew=2, mfc='white', label='Hugoniot curve');

if os.path.isfile('FPEOS_Hugoniot_rad.txt'): # for hydrogen this file does not get written
   hugRad = numpy.loadtxt('FPEOS_Hugoniot_rad.txt',usecols=(1,3,7,9,13)); # T,rho/rho0,rho,P,E
   f = 0.2
   plot(hugRad[:,cx],hugRad[:,cy],'-', linewidth=3, markersize=0,color='brown',mec='brown',mew=2, mfc='white', dashes=(16*f,3*f,3*f,3*f),label='Hugoniot with\nradiation effects');
   if (hug.shape==hugRad.shape):
      fill_betweenx(hugRad[:,cy], hug[:,cx],hugRad[:,cx],facecolor='r',color='r',alpha=0.1)

#########################################################################################################################################

ch = numpy.loadtxt('FPEOS_convex_hull.txt', usecols=(1,5,7)) # rho,T,P
c = '#bde7fa'
fill(ch[:,2],ch[:,1],edgecolor='none',fc=c,alpha=0.3,zorder=-10);
ch=np.concatenate((ch,ch[0:1,:]),axis=0)
plot(ch[:,2],ch[:,1],color=c,lw=1,label='EOS boundary',zorder=-10)

#########################################################################################################################################

xlabel(r'Pressure (GPa)')
#xlabel(r'Density (g$\,$cm$^{-3}$)')
#xlabel(r'Compression ratio $\rho / \rho_0$')
ylabel(r'Temperature (K)')
#ylabel(r'Pressure (GPa)')

a.set_xscale('log')
a.set_yscale('log')
a.xaxis.set_ticks_position('both')
a.get_xaxis().set_tick_params(which='both', direction='in')
a.yaxis.set_ticks_position('both')
a.get_yaxis().set_tick_params(which='both', direction='in')

legend(loc='lower right',frameon=False,handlelength=3.5,ncol=1,handletextpad=0.4,numpoints=1)

savefig(scriptName+'.pdf', bbox_inches='tight')
savefig(scriptName+'.png', bbox_inches='tight', dpi=200)

