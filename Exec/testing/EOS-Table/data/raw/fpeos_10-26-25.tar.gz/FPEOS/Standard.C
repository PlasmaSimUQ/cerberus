////////////////////////////////////////////////////////////////////////////
//
// Standard definitions and functions that are used almost everywhere
//
// Burkhard Militzer                                    Urbana 4-9-99
//
#include "Standard.h"

#ifdef USE_MPI
#include <mpi.h>
#endif

ofstream COUT;

void Terminate() {
  
#ifdef USE_MPI
  int errorcode=1;
  MPI_Abort(MPI_COMM_WORLD, errorcode);
#endif

   cerr << "Exiting now\n";
   exit(-1);
}

