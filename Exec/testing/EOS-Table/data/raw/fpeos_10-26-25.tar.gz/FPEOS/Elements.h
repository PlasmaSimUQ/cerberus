////////////////////////////////////////////////////////////////////////////
//                                                                         //
// EOS table class                                                         // 
// assume EOS is given on a density grid but the temperatures vary with rho//
//                                                                         //
// Burkhard Militzer                                  Livermore 2-26-03    //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////

#ifndef _ELEMENTS_
#define _ELEMENTS_

#include "Standard.h"

inline double MassNumberFromName(const string & symbol) {
  double mm = 0.0;
  //  if (symbol == "H")  { mm =  2.0; warning("Doing a DEUTERIUM calculation instead HYDROGEN!!!"); }
  if (symbol == "H")  mm =  1.00794;
  if (symbol == "He") mm =  4.00260;
  if (symbol == "Li") mm =  6.94100; // 7
  if (symbol == "Be") mm =  9.01218;
  if (symbol == "B")  mm = 10.81100; // 11
  if (symbol == "C")  mm = 12.0107;
  if (symbol == "N")  mm = 14.00674; // 14.0;
  if (symbol == "O")  mm = 15.9994;  // 16.0;
  if (symbol == "F")  mm = 18.9984;  // 19.0;
  if (symbol == "Mg") mm = 24.3050;  
  if (symbol == "Ne") mm = 20.1797;  // 22.0; 
  if (symbol == "Na") mm = 22.98977; // 23.0;
  if (symbol == "Al") mm = 26.9815386;
  if (symbol == "Si") mm = 28.0855;  // 28
  if (symbol == "P")  mm = 30.973762;
  if (symbol == "S")  mm = 32.065;   // 32
  if (symbol == "Ar") mm = 39.948;  // heavier than "K"
  if (symbol == "K")  mm = 39.0983;
  if (symbol == "Ca") mm = 40.078;
  if (symbol == "Fe") mm = 55.845;
  if (symbol == "Co") mm = 58.9332;
  if (symbol == "Ga") mm = 69.723;
  if (symbol == "Kr") mm = 83.798;
  if (symbol == "I")  mm = 126.90447;
  if (symbol == "Xe") mm = 131.29;
  if (symbol == "Cs") mm = 132.90545196;
  if (symbol == "Gd") mm = 157.25;
  if (symbol == "Pb") mm = 207.2;
  if (symbol == "Po") mm = 209.0;
  if (symbol == "H2O") mm = 18.01528; // wiki
  if (symbol == "D2O") mm = 18.01528+2.0; // need to look up correct mass!!!
  if (mm==0.0) warning("Do not know the mass for the this type",symbol);
  return mm;
}

inline string NameFromChargeNumber(const int Z) {
  if (Z== 1) return "H";
  if (Z== 2) return "He";
  if (Z== 3) return "Li";
  if (Z== 4) return "Be";
  if (Z== 5) return "B";
  if (Z== 6) return "C";
  if (Z== 7) return "N";
  if (Z== 8) return "O";
  if (Z== 9) return "F";
  if (Z==10) return "Ne";
  if (Z==11) return "Na";
  if (Z==12) return "Mg";
  if (Z==13) return "Al";
  if (Z==14) return "Si";
  if (Z==15) return "P";
  if (Z==16) return "S";
  if (Z==17) return "Cl";
  if (Z==18) return "Ar";
  if (Z==19) return "K";
  if (Z==20) return "Ca";
  if (Z==21) return "Sc";
  if (Z==22) return "Ti";
  if (Z==23) return "V";
  if (Z==24) return "Cr";
  if (Z==25) return "Mn";
  if (Z==26) return "Fe";
  if (Z==53) return "I";
  if (Z==54) return "Xe";
  if (Z==55) return "Cs";
  //  error("Names for atoms with Z>20 were not coded.",Z);
  //  return "";
  return "U"+IntToString(Z);
}

inline int ChargeNumberFromName(const string & name) {
  for(int Z=1; Z<=26; Z++) {
    if (NameFromChargeNumber(Z)==name) return Z;
  }
  error("Could not fine charge number of type:",name);
  return -1;
}

inline string NameFromChemicalSymbol(const string & symbol, const bool capitalize=false) {
  string name = "";
  if (symbol == "H")   name = "hydrogen";
  if (symbol == "He")  name = "helium";
  if (symbol == "Li")  name = "lithium";
  if (symbol == "Be")  name = "beryllium";
  if (symbol == "B")   name = "boron";
  if (symbol == "C")   name = "carbon";
  if (symbol == "N")   name = "nitrogen";
  if (symbol == "O")   name = "oxygen";
  if (symbol == "F")   name = "fluorin";
  if (symbol == "Mg")  name = "magnesium";
  if (symbol == "Ne")  name = "neon";
  if (symbol == "Na")  name = "sodium";
  if (symbol == "Al")  name = "aluminum";
  if (symbol == "Si")  name = "silicon";
  if (symbol == "P")   name = "phosphorus";
  if (symbol == "S")   name = "sulfur";
  if (symbol == "Ar")  name = "argon";
  if (symbol == "K")   name = "potassium";
  if (symbol == "Ca")  name = "calsium";
  if (symbol == "Fe")  name = "iron";
  if (symbol == "Co")  name = "cobalt";
  if (symbol == "Ga")  name = "gallium";
  if (symbol == "Kr")  name = "krypton";
  if (symbol == "I")   name = "iodine";
  if (symbol == "Xe")  name = "xenon";
  if (symbol == "Cs")  name = "caesium";
  if (symbol == "Gd")  name = "gadolinium";
  if (symbol == "Pb")  name = "lead";
  if (symbol == "Po")  name = "polonium";
  if (symbol == "H2O") name = "water";
  if (symbol == "D2O") name = "heavy_water";
  if (name=="") warning("Do not know the name for element",symbol);
  if (capitalize) name = UpperCase(name.substr(0,1))+name.substr(1);
  return name;
}

#endif // _ELEMENTS_
