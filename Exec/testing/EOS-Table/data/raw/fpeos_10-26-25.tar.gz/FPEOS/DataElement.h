/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// Mixing entropy                                                          // 
//                                                                         //
// Burkhard Militzer                                Washington, 11-02-01   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////

#ifndef __DATAELEMENT__
#define __DATAELEMENT__

#include "Array.h"

class DataElement {
public:
  DataElement() {};
  DataElement(const double y_):y(y_){}
  DataElement(const double x_,const double y_):x(x_),y(y_){}

  double x,y;
  Array1 <double> yy;

  void PushBack(const double yi) {
    yy.PushBack(yi);
  }
  
  double Mean() {
    int n = yy.Size();
    if (n==0) error("DataElement empty");
    double m=0.0;
    for(int i=0; i<yy.Size(); i++) {
      m += yy[i];
    }
    return m/double(n);
  }

  double Variance() { // from a specific "y" value -  not from mean
    const int n = yy.Size();
    if (n==0) error("DataElement empty");
    double m=0.0;
    for(int i=0; i<yy.Size(); i++) {
      m += sqr(yy[i]-y);
    }
    return sqrt(m/double(n));
  }

  double ErrorBar() { 
    const int n = yy.Size();
    if (n==0) error("DataElement empty");
    double m=0.0;
    double m2=0.0;
    for(int i=0; i<yy.Size(); i++) {
      m  += yy[i];
      m2 += sqr(yy[i]);
    }
    m  /= double(n);
    m2 /= double(n);
    double var = sqrt(max(0.0,m2 - m*m));
    return sqrt(var/double(n-1));
  }

  friend ostream& operator<<(ostream & os, const DataElement & a) {
    os << "(" << a.x << "," << a.y << ")";
    return os;
  }

};

#endif // __DATAELEMENT__
