/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// Relatisitic Ideal Fermi gas in 3D                                       // 
//                                                                         //
// Burkhard Militzer                                  Berkeley, 11-11-15   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////

#ifndef _RELATIVISTICFERMIGAS_
#define _RELATIVISTICFERMIGAS_

double MuRelativisticFermiGas(const double lambda, const double beta, const double ne, const double g);
double EnergyRelativisticFermiGas(const double lambda, const double beta, const double ne, const double g);
double PressureRelativisticFermiGas(const double lambda, const double beta, const double ne, const double g);

#endif // _RELATIVISTICFERMIGAS_

