////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// First-Principles Equation of State Database for Warm Dense Matter Computation  // 
//                                                                                //
// Burkhard Militzer                                         Berkeley, 10-15-20   //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////

#include <cstdlib>
#include <fstream>
#include <iostream>

#include "Standard.h"
#include "EOSTableSimple.h"
#include "Form.h"
#include "Physics.h"
#include "Spline.h"
#include "FindRoot.h"
#include "FindMinimum.h"
#include "DataElement.h"
#include "RelativisticCorrectionsFermiGas.h"
#include "RungeKutta.h"
#include "DataElement.h"
#include "Debye.h"
#include "FermiGas.h"
#include "IdealMixture.h"
#include "IdealMixture3.h"
#include "Parser.h"
#include "ParseCommandLineArguments.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////

void PrintOneEOSPoint(const EOSTableDiffT & eos, const double nn, const double T, const string s="") {
  //  double rhoH2gcc = nn*PC::AUToH2gcc;
  //  double rs = RsFromDensity(nn);
  double rhoGCC = eos.MassDensityGCC(nn);
  
  double E    = eos.Energy(nn,T);
  double EE   = eos.EnergyErrorBar(nn,T);
  double P    = eos.Pressure(nn,T);
  double PE   = eos.PressureErrorBar(nn,T);
  //  double PV   = P/nn;
  //  double PVV  = P/nn/nn;
  //  double PEV  = PE/nn;
  //  double PEVV = PE/nn/nn;

  //  double dPdT = eos.PressureTemperatureDerivative(nn,T);
  //  double dEdT = eos.EnergyTemperatureDerivative(nn,T); // E per electron, if density is per electron
  //  double dLogPdLogT = dPdT * T / P;
  //  double dLogEdLogT = dEdT * T / E;
  
  double TinK     = T*PC::AUToK;
  double EineV    = E*PC::AUToeV;
  double EEineV  = EE * PC::AUToeV;
  double PinGPa   = P*PC::AUToGPa;
  double PEinGPa  = PE * PC::AUToGPa;
  //  double dPdTGPaK = dPdT*PC::AUToGPa / PC::AUToK;
  //  double dEdTeVK  = dEdT*PC::AUToeV  / PC::AUToK;
  
  //  double dSdV      = eos.EntropyVolumeDerivative(nn,T);
  //  double dSdVGPaK  = dSdV*PC::AUToGPa / PC::AUToK;
  //  double TdSdT     = T*eos.EntropyTemperatureDerivative(nn,T);
  //  double TdSdTeVK  = TdSdT*PC::AUToeV  / PC::AUToK;
  
  //  if (dPdTGPaK<0.0) Write10(TinK,nn,rs,rhoH2gcc,eineV,pinGPa,dEdTeVK,dPdTGPaK,dLogEdLogT,dLogPdLogT);
  //  Write10(TinK,nn,rs,rhoH2gcc,eineV,pinGPa,dEdTeVK,dPdTGPaK,dLogEdLogT,dLogPdLogT);
  //  Write8(TinK,nn,rs,rhoH2gcc,eineV,pinGPa,S,F);

  //  Write12(TinK,nn,rs,rhoH2gcc,eineV,pinGPa,S,F,dPdTGPaK,dSdVGPaK,dEdTeVK,mTdSdTeVK);
  //  cout << "eos ";
  //  Write9(TinK,rs,EineV,PinGPa,S,dPdTGPaK,dSdVGPaK,dEdTeVK,TdSdTeVK);
  //  Write8(TinK,nn,rs,eineV,pinGPa,S,dPdTGPaK,dSdVGPaK);
  //  Write10(TinK,rs,rhoH2gcc,EineV,PinGPa,S,dPdTGPaK,dSdVGPaK,dEdTeVK,TdSdTeVK);

  cout << s << " ";
  //  Write9(TinK,rs,rhoH2gcc,EineV,PinGPa,PV,PVV,dEdTeVK,dPdTGPaK);
  //  Write9(TinK,rs,rhoH2gcc,EineV,EEineV,PinGPa,PEinGPa,PVV,PEVV);
  //  Write7(S,TinK,nn,PinGPa,PEinGPa,EineV,EEineV);
  Write7(TinK,nn,rhoGCC,PinGPa,PEinGPa,EineV,EEineV);

  /* 
  if (dPdTGPaK<0.0) { // map out dP/dT<0 region
    cout << s << " ";
    Write7(TinK,rs,rhoH2gcc,EineV,PinGPa,dEdTeVK,dPdTGPaK);
  }
  */
  /*
  double dPdV  = eos.PressureVolumeDerivative(nn,T);
  double dVdP    = 1.0/dPdV;
  double dVH2dP  = 2.0*dVdP;
  double V   = 1.0/nn; // volume per electron in AU
  double VH2 = 2.0*V;

  double VH2OMixing = VH2 - dVH2dP   *   0.2513714 * PC::GPaToAU * 64.0;
  double rhoH2Ogcc  = 18*PC::u/(PC::ab*PC::ab*PC::ab)/1000.0 * VH2OMixing;
  
  cout << s << " ";
  Write9(TinK,rs,nn,PinGPa,VH2,VH2OMixing,dVH2dP,dVH2dP * 0.2513714 * PC::GPaToAU,rhoH2Ogcc);
  */
}

void PrintEOSConstantTemperature(const EOSTableDiffT & eos, const double T, const bool flag=true) {
  double nn1 = flag ? eos.MinimumDensityForTemperature(T) : eos.tnn.First();
  double nn2 = flag ? eos.MaximumDensityForTemperature(T) : eos.tnn.Last();

  Write2(nn1,nn2);
  Write2(RsFromDensity(nn1),RsFromDensity(nn2));
  const int np=101; // Record the result on "np" density points
  for(int i=0; i<np; i++) { 
    double nn = nn1*exp(log(nn2/nn1)*double(i)/double(np-1));
    //    Write2(i,RsFromDensity(nn));
    PrintOneEOSPoint(eos,nn,T,"eosCT");
  }    
}

void PrintEOSConstantTemperaturePoints(const EOSTableDiffT & eos, const double TT) {
  for(int inn=eos.MinimumDensityIndexForTemperature(TT); 
      inn<=eos.MaximumDensityIndexForTemperature(TT); inn++) { 
    PrintOneEOSPoint(eos,eos.tnn[inn],TT,"eosPT");
  }
}

void PrintEOSConstantDensityPoints(const EOSTableDiffT & eos, const int inn) {
  for(int iT=0; iT<eos.lists[inn].Size(); iT++) { 
    PrintOneEOSPoint(eos,eos.tnn[inn],eos.T[eos.lists[inn][iT]],"eosPrho");
  }    
}

void PrintEOSConstantDensityAllPoints(const EOSTableDiffT & eos) {
  for(int i=0; i<eos.tnn.Size(); i++) { 
    PrintEOSConstantDensityPoints(eos,i);
  }
}

void PrintEOSConstantDensity(const EOSTableDiffT & eos, const double nn) {
  const double eps=1e-6;
  if (nn*(1.0+eps)<eos.tnn.First() || nn*(1.0-eps)>eos.tnn.Last()) 
    error("PrintEOSConstantDensity: density out of range",nn,RsFromDensity(nn));

  int inn=0;
  while (eos.tnn[inn]<nn && inn<eos.tnn.Size()-1) inn++;
  if (inn==0) inn++;
  int innn = inn-1;

  double T1 = max(eos.T[eos.lists[inn].First()],eos.T[eos.lists[innn].First()]);
  double T2 = min(eos.T[eos.lists[inn].Last() ],eos.T[eos.lists[innn].Last() ]);
  const int np=101; // Record the result on "np" T points
  for(int i=0; i<np; i++) { 
    double T = T1*exp(log(T2/T1)*double(i)/double(np-1));
    PrintOneEOSPoint(eos,nn,T,"eosCrho");
  }
}

void PrintEOSConstantDensityAll(const EOSTableDiffT & eos) {
  double nn1 = eos.tnn.First();
  double nn2 = eos.tnn.Last();
  const int np=101; // Record the result on "np" density points
  for(int i=0; i<np; i++) { 
    double nn = nn1*exp(log(nn2/nn1)*double(i)/double(np-1));
    PrintEOSConstantDensity(eos,nn);
  }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////

// used to find the zero in the Hugoniot function H(nn,T) by varying nn while keeping T fixed
// called from FindRootBisection() for example
template <class EOS> 
class FindDensityOnHugoniot {
  EOS & eos;
  double nn0,P0,E0,T;
public:
  FindDensityOnHugoniot(EOS & eos_, const double nn0_, const double P0_, const double E0_, const double T_)
    :eos(eos_),nn0(nn0_),P0(P0_),E0(E0_),T(T_) {}

  double operator()(const double nn) const {
    double P = eos.Pressure(nn,T);
    double E = eos.Energy(nn,T);
    double Hug = HugoniotFunction(E,P,nn, E0,P0,nn0); // found in Physics.h
    //    Write7(Hug, E,P,nn, E0,P0,nn0);
    return Hug;
  }

};

// will not work for mixtures because eos.MinimumDensityIndexForTemperature(T) cannot be provided
bool DensityOnHugoniot(EOSTableDiffT & eos, const double nn0, const double P0, const double E0, const double T, double & nn) {
  FindDensityOnHugoniot<EOSTableDiffT> fdoh(eos,nn0,P0,E0,T);
  double nn1 = eos.MinimumDensityForTemperature(T);
  double nn2 = eos.MaximumDensityForTemperature(T);
  //  Write3(eos.MassDensityGCC(nn0),P0*PC::AUToGPa,T*PC::AUToK);
  //  Write2(eos.MassDensityGCC(nn1),eos.MassDensityGCC(nn2));

  int i1 = eos.MinimumDensityIndexForTemperature(T);
  int i2 = eos.MaximumDensityIndexForTemperature(T);
  //    Write5(i1,i2,nn1,nn2,T*PC::AUToK);
  if (i1>=i2) {
    warning("DensityOnHugoniot(): i1==i2",i1,i2);
    return false;
  }

  double H1 = fdoh(nn1);
  double H2 = fdoh(nn2);
  //  Write8(T*PC::AUToK,eos.MassDensityGCC(nn0),eos.MassDensityGCC(nn1),eos.MassDensityGCC(nn2),nn1/nn0,nn2/nn0,H1,H2);
  if (sign(H1)==sign(H2)) {
    //    Write6(T*PC::AUToK,eos.MassDensityGCC(nn0),eos.MassDensityGCC(nn1),eos.MassDensityGCC(nn2),nn1/nn0,nn2/nn0);
    //    warning("DensityOnHugoniot(): H(nn1,T) and H(nn2,T) have same sign:",H1,H2);
    return false;
  }

  double nnRelTol = 1e-6;
  nn = FindRootRegulaFalsiSafely(nn1,nn2,nnRelTol,fdoh,"DensityOnHugoniot");
  return true;
}

// special function for mixtures
template <class IM> 
bool DensityOnHugoniot(IM & im, const double nn0, const double P0, const double E0, const double T, double & nn) {
  if (im.CheckForOverlapAtTemperature(T)==false) return false;

  FindDensityOnHugoniot<IM> fdoh(im,nn0,P0,E0,T);
  double nn1 = im.MinimumDensityForTemperature(T);
  double nn2 = im.MaximumDensityForTemperature(T);
  if (nn1>=nn2*(1.0-1e-8)) return false;

  double H1 = fdoh(nn1);
  double H2 = fdoh(nn2);
  if (sign(H1)==sign(H2)) {
    //    Write6(T*PC::AUToK,eos.MassDensityGCC(nn0),eos.MassDensityGCC(nn1),eos.MassDensityGCC(nn2),nn1/nn0,nn2/nn0);
    //    warning("DensityOnHugoniot(): H(nn1,T) and H(nn2,T) have same sign:",H1,H2);
    return false;
  }

  double nnRelTol = 1e-6*(nn2-nn1);
  nn = FindRootRegulaFalsiSafely(nn1,nn2,nnRelTol,fdoh,"DensityOnHugoniot");
  return true;
}

// Called from FindMaximumTrisection
// Used to find maximum compression by computing the density on the Hugoniot as function of T
// Here the operator()(const double T) returns the density on the Hugoniot(T)
template <class EOS> 
class FindDensityOnHugoniotAsFunctionOfTemperature {
  EOS & eos;
  const double nn0,P0,E0;
public:
  FindDensityOnHugoniotAsFunctionOfTemperature(EOS & eos_):
    eos(eos_),
    nn0(eos.GetHugoniotnn0()),
    P0(eos.GetHugoniotP0()),
    E0(eos.GetHugoniotE0()) 
  {}

  double operator()(const double T) const {
    double nn;
    bool ok = DensityOnHugoniot(eos,nn0,P0,E0,T,nn);
    if (!ok) error("FindDensityOnHugoniotAsFunctionOfTemperature() failed for T[K]=",T*PC::AUToK);
    return nn;
  }

};

template <class EOS> 
double DensityOnHugoniotSafely(EOS & eos, const double nn0, const double P0, const double E0, const double T) {
  double nn;
  bool ok = DensityOnHugoniot(eos,nn0,P0,E0,T,nn);
  if (!ok) {
    Write3(eos.MassDensityGCC(nn0),P0*PC::AUToGPa,T*PC::AUToK);
    error("DensityOnHugoniotSafely(): Could not find density to solve for H=0.");
  }
  return nn;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////

double CalcUs(const double nn1, const double P1, const double nn0, const double P0, const double M) {
  double x=(P1-P0)/nn0 * nn1/(nn1-nn0);
  return sqrt(x/M);
}

double CalcUp(const double nn1, const double P1, const double nn0, const double P0, const double M) {
  double x=(P1-P0)/nn0 * (nn1-nn0)/nn1;
  return sqrt(x/M);
}

template <class EOS> 
void PrintOneHugoniotPoint(ostream & of, EOS & eos, const double nn0, const double P0, const double E0, const double nn, const double T, const string s="") {
  double rho0 = eos.MassDensityGCC(nn0);
  double rho  = eos.MassDensityGCC(nn);

  double E    = eos.Energy(nn,T);
  double EE   = eos.EnergyErrorBar(nn,T);
  double P    = eos.Pressure(nn,T);
  double PE   = eos.PressureErrorBar(nn,T);
  
  double TinK     = T*PC::AUToK;
  //  double EineV    = E*PC::AUToeV;
  //  double EEineV  = EE * PC::AUToeV;
  double PinGPa   = P*PC::AUToGPa;
  double PEinGPa  = PE * PC::AUToGPa;
  //  double S = eos.Entropy(nn,T);
  //  double F = eos.FFromEmTS(nn,T);
  double Hug = HugoniotFunction(E,P,nn, E0,P0,nn0); // found in Physics.h
  //  Write7(E,P,nn,E0,P0,nn0,Hug);

  double us = CalcUs(nn,P,nn0,P0,eos.GetMassFormulaUnit());
  double up = CalcUp(nn,P,nn0,P0,eos.GetMassFormulaUnit());
  double usKmPerS = us * PC::AUTokmPerS;
  double upKmPerS = up * PC::AUTokmPerS;

  of << s;
  of << " T[K]= " << fix(16,3,TinK) << " rho/rho0= " << fix(9,6,rho/rho0) << " rho0[g/cc]= " << fix(11,8,rho0) << " rho[g/cc]= " << fix(11,8,rho);
  of << " P[GPa]= " << fix(16,6,PinGPa);
  of << " +- " << fix(12,6,PEinGPa);
  of << " E[Ha]= " << fix(14,8,E);
  of << " +- " << fix(11,8,EE);
  of << " E0[Ha]= " << fix(14,8,E0);
  of << " (E-E0)[Ha]= " << fix(14,8,E-E0);
  of << " Hug[Ha]= " << fix(14,8,Hug);
  of << " up[km/s]= " << fix(10,4,upKmPerS);
  of << " us[km/s]= " << fix(10,4,usKmPerS);
  of << endl;
}

double DetermineHugoniotDensityForGivenTemperature(EOSTableDiffT & eos, const double nn0, const double P0, const double E0, const double T) {
  FindDensityOnHugoniot<EOSTableDiffT> fdoh(eos,nn0,P0,E0,T);
  double nn1 = eos.MinimumDensityForTemperature(T);
  double nn2 = eos.MaximumDensityForTemperature(T);
  int i1 = eos.MinimumDensityIndexForTemperature(T);
  int i2 = eos.MaximumDensityIndexForTemperature(T);
  //    Write5(i1,i2,nn1,nn2,T);
  if (i1<i2) {
    double H1 = fdoh(nn1);
    double H2 = fdoh(nn2);
    if (sign(H1)!=sign(H2)) {
      double nnTol = 1e-6*(nn2-nn1);
      double nn = FindRootRegulaFalsiSafely(nn1,nn2,nnTol,fdoh);
      return nn;
    }
  }
  return 0.0;
}

double PrintHugoniotCurve(const string & fileName, EOSTableDiffT & eos, const double T1) {
  cout << "Computing the Hugoniot curve for an EOS ..." << endl;
  ofstream of(fileName.c_str());
  if (!of) {
    warning("Could not open file "+fileName+" skipping over Hugoniot file.");
    return -1;
  }

  if (!eos.GetHugoniotFlag()) {
    warning("No initial conditions for Hugoniot curve available. Skipping over Hugoniot file.");
    return -1;
  }
  double nn0 = eos.GetHugoniotnn0();
  double P0  = eos.GetHugoniotP0();
  double E0  = eos.GetHugoniotE0();

  double maxComp  = 0.0;
  double TMaxComp = 0.0;

  double T2 = eos.GetMaximumTemperature();
  int nnn=200;
  for(int iii=0; iii<=nnn; iii++) {
    double T=T1*exp(double(iii)/double(nnn)*log(T2/T1));
    double nn;
    if (DensityOnHugoniot(eos,nn0,P0,E0,T,nn)) {
      double comp = nn/nn0;
      if (comp>maxComp) { maxComp = comp; TMaxComp = T;}
      PrintOneHugoniotPoint(of,eos,nn0,P0,E0,nn,T);
    }
  }
  cout << "Wrote Hugoniot curve to file " << fileName << endl << endl;
  return TMaxComp;
  //  Write(nn0);
}

inline double PrintHugoniotCurve(const string & fileName, EOSTableDiffT & eos) {
  double T1 = eos.GetMinimumTemperature();
  return PrintHugoniotCurve(fileName,eos,T1);
}

template <class IM> 
double PrintHugoniotCurve(const string & fileName, IM & im, bool & notAtBoundary, const int nnn=200) {
  cout << "Computing the Hugoniot curve for a " << im.GetName() << " mixture ..." << endl;
  notAtBoundary = false;
										     
  ofstream of(fileName.c_str());
  if (!of) {
    warning("Could not open file "+fileName+" skipping over Hugoniot file.");
    return -1;
  }

  if (!im.GetHugoniotFlag()) {
    warning("No initial conditions for Hugoniot curve available. Skipping over Hugoniot file.");
    return -1;
  }
  double nn0 = im.GetHugoniotnn0();
  double P0  = im.GetHugoniotP0();
  double E0  = im.GetHugoniotE0();

  double maxComp  = -1.0;
  double TMaxComp = -1.0;
  double T1 = im.GetMinimumTemperature();
  double T2 = im.GetMaximumTemperature();
  double TFirstValid = -1.0;										     
  double TLastValid  = -1.0;										     

  int nnn0 = 0;
  if (im.eos1.GetName()=="Nitrogen" || im.eos2.GetName()=="Nitrogen") nnn0=nnn/10; // avoid lowerst T region for nitrogen where dP/dT may be negative								     
  for(int iii=nnn; iii>=nnn0; iii--) { // decrease T
    if (iii%10==0) { cout << iii; } else { cout << "."; }
    cout.flush();
    
    //    Write(iii);
    double T=T1*exp(double(iii)/double(nnn)*log(T2/T1));
    double nn;
    if (DensityOnHugoniot(im,nn0,P0,E0,T,nn)) {
      double comp = nn/nn0;
      if (comp>maxComp) { maxComp = comp; TMaxComp = T; }
      PrintOneHugoniotPoint(of,im,nn0,P0,E0,nn,T);
      if (TFirstValid<0.0) TFirstValid = T;
      TLastValid = T;
    }
    
  }
  cout << endl;
  //  Write(nn0);
  //  return maxComp;
  cout << "Wrote Hugoniot curve for mixture to file " << fileName << endl << endl;
  //  notAtBoundary = (maxCompIndex>nnn0 && maxCompIndex<nnn);
  //  Write3(TFirstValid*PC::AUToK,TMaxComp*PC::AUToK,TLastValid*PC::AUToK);
  //  notAtBoundary = (TMaxComp>TFirstValid && TMaxComp<TLastValid);
  notAtBoundary = (TMaxComp!=TFirstValid && TMaxComp!=TLastValid); // Note that T may be decreasing with index iii
  return TMaxComp;
}



////////////////////////////////////////////////////////////////////////////////////////////////////////

void ApplyRelativisticCorrectionToEnergyAndPressure(EOSTableDiffT & eos) {
  //  warning("Applying relativistic correction to E and P.");

  double NeFU = eos.GetNElectronsFormulaUnit();
  //  Write(NeFU);
  if (NeFU<=0.0) error("eos.GetNElectronsFormulaUnit() wrong",NeFU);

  for(int i=0; i<eos.GetNumber(); i++) {
    double nni,Ti;
    eos.GetDataPoint(i,nni,Ti);
    //    Ti *= 100.0;

    //    if (Ti >= 1e5*PC::KToAU) {
    if (Ti >= 2e6*PC::KToAU) {
      double ne = nni*NeFU; // density of electrons
      double dE = NeFU*RelativisticEnergyCorrectionElectrons(1.0/Ti,ne);
      double dP = RelativisticPressureCorrectionElectrons(1.0/Ti,ne);

      if (dP<0.0) dP=0.0; // dP is always very small, ignore negative values
      if (dE<0.0) {
	//	double rho = eos.MassDensityGCC(nni);
	//	Write4(rho,Ti*PC::AUToK,dE/eos.ee[i], dP/eos.pp[i]);
	//	error("Relativistic energy corrections should not be negative."); // Will happen if T is too small. Happens more for low Z. 
	dE=0.0;
      }
      //      if (dP<0.0) error("Relativistic pressure corrections should not be negative");

      eos.ee[i] += dE;
      eos.pp[i] += dP;
    }
  }

}

////////////////////////////////////////////////////////////////////////////////////////////////////////

// dT/dV_S  = dP/dT_V  /  [ -1/T dE/dT_V ] 
// dT/dnn_S = dP/dT_V  /  [ +1/T dE/dT_V ] * V^2
class DiffAdiabat {
public:
  static const int n=1;
  const EOSTableDiffT & eos;
  double T0;
  Spline s;
  const bool print;

  DiffAdiabat(const EOSTableDiffT & eos_, const double T0_, const bool print_=true):eos(eos_),T0(T0_),print(print_){}
  Array1 <double> GetInitialConditions(const double nn0) {
    Array1 <double> T(1,T0);
    return T;
  }
  void Diff(const double nn, const Array1 <double> & TT, Array1 <double> & dTdnn) const {
    double T = TT[0];
    /*
    if (!eos.PointInside(nn,T)) {
      double rho = eos.MassDensityGCC(nn);
      warning("ODE: Point outside",rho,T*PC::AUToK);
      dTdnn[0] = 0.0; // dows not work well, increases T error
      return;
    }
    */
    //    Write2(RsFromDensity(nn),T[0]*PC::AUToK);
    double dPdT = eos.PressureTemperatureDerivative(nn,T);
    double dEdT = eos.EnergyTemperatureDerivative(nn,T); // E per electron, if density is per electron
    //    dTdnn[0] = -T * dPdT / dEdT;
    dTdnn[0] = T/nn/nn * dPdT / dEdT;
  }
  bool OutPut(const int nFunctionCalls, const double nn, const double h, const Array1 <double> & TT, const Array1 <double> & dTdnn) {
    double rho = eos.MassDensityGCC(nn);
    double T = TT[0];
    //    if (!eos.PointInside(nn,T)) error("Point outside",rho,T*PC::AUToK,eos.Pressure(nn,T)*PC::AUToGPa);
    if (!eos.PointInside(nn,T,false,1e-8)) {
      //      warning("ODE: Point outside",rho,T*PC::AUToK,eos.Pressure(nn,T)*PC::AUToGPa);
      warning("ODE: Point really outside",rho,T*PC::AUToK);
      return true;
    }
    if (h>0.0 && !eos.PointInside(nn,T*1.01)) {
      //      warning("ODE: Point outside",rho,T*PC::AUToK,eos.Pressure(nn,T)*PC::AUToGPa);
      warning("ODE: Point nearly outside",rho,T*PC::AUToK);
      return true;
    }
    /*
    if (fabs(h)<1e-08) { // do ot use b/c initially we set h=0 
      warning("ODE: step size became too small",h,rho,T*PC::AUToK);
      return true;
    }
    */
    if (nFunctionCalls>10000) {
      warning("ODE: got stuck. Too many function calls",nFunctionCalls,h,rho,T*PC::AUToK);
      return true;
    }
    /*
    if (h<0.0 && !eos.PointInside(nn,T*0.99)) {
      //      warning("ODE: Point outside",rho,T*PC::AUToK,eos.Pressure(nn,T)*PC::AUToGPa);
      warning("ODE: Point nearly outside",rho,T*PC::AUToK);
      return true;
    }
    */
    if (print) {
      cout << "RK: "; 
      Write5(nn,rho,h,T*PC::AUToK,eos.Pressure(nn,T)*PC::AUToGPa);
    }
    s.PushBack(nn,T);
    return false;
  }
};

void ComputeAdiabatSimple(const EOSTableDiffT & eos) {
  double nn1 = eos.tnn.First();
  double nn2 = eos.tnn.Last();
  double T1 = 3000.0*PC::KToAU;

  DiffAdiabat da(eos,T1);
  RungeKutta<DiffAdiabat> rk;

  rk.Solve(nn1,nn2,1e-8,0.0,1e-8,da);
  cout << rk;
}

// densityFlag=true:  increase with increasing density
// densityFlag=false: increase with decreasing density
Array1 <DataElement> ComputeAdiabat(ofstream & of, const EOSTableDiffT & eos, const double nn1, const double nn2, const double T1, int & index) {
  const bool print = false;
  //  const bool print = true;

  int np=501; 
  //  double eps=1e-14;
  double eps=1e-8;
  //  double eps=1e-7;
  double h0   = eps*(nn2-nn1);
  double hMax = (nn2-nn1)/np;
  //  double hMax = 0.0;

  //  DiffAdiabat da(eos,T1,true); // print steps
  DiffAdiabat da(eos,T1,false); // do not print steps

  RungeKutta<DiffAdiabat> rk;
  if (print) cout << endl << "RK forward: " << eos.MassDensityGCC(nn1) << " --> " << eos.MassDensityGCC(nn2) << endl;
  rk.Solve(nn1,nn2,h0,hMax,eps,da);
  if (print) cout << rk;

  if (da.s.LastX()!=nn2) warning("RK: ODE solver did not get to the end. rho(gcc)=",eos.MassDensityGCC(da.s.LastX()),eos.MassDensityGCC(nn2));
  double T2   = da.s.LastY();  // record it now because CalculateY2() could reorder s(x,y)
  double nnn1 = da.s.FirstX(); // record it now because CalculateY2() could reorder s(x,y)
  double nnn2 = da.s.LastX();  // record it now because CalculateY2() could reorder s(x,y)
  da.s.CalculateY2();

  // Do the reverse integration just to test the accuracy - do not use the data further below
  //  DiffAdiabat da2(eos,T2,true); // print steps
  DiffAdiabat da2(eos,T2,false); // do not print steps
  if (print) cout << endl << "RK reverse: " << eos.MassDensityGCC(nnn2) << " --> " << eos.MassDensityGCC(nnn1) << endl;
  //  rk.Solve(nn2,nn1,-h0,hMax,eps,da2);
  if (print) Write(h0);
  rk.Solve(nnn2,nnn1,-h0,hMax,eps,da2);
  if (print) cout << rk;
  double diffT = da2.s.LastY() - T1;
  if (print) cout << "Magnitude of the finite step size integration error in T: dT=" << diffT 
		  << " T1=" << T1 << " rel=" << diffT/T1 << endl;

  //  if (fabs(diffT/T1)>1e-5) error("relative error is too large");
  if (fabs(diffT/T1)>1e-4) {
    warning("Relative error in adiabat computation became too large. Skipping over this adiabat.");
    np = 0;
  }

  // Record the result on "np" density points
  Array1 <DataElement> des(np);
  for(int i=0; i<np; i++) { 
    des[i].x = nnn1*exp(log(nnn2/nnn1)*double(i)/double(np-1));
    des[i].y = da.s.f(des[i].x);
  }

  for(int i=0; i<np; i++) { 
    double nn = des[i].x;
    double T  = des[i].y;
    of << "index= " << index;
    eos.PrintOnePoint(of,nn,T);
  }

//  Write(index);
  index++;

  return des;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////

template <class EOS> 
void PrintIsobar(EOS & eos, const double P, const string name="") {
  double nn1 = eos.GetMinimumDensity();
  double nn2 = eos.GetMaximumDensity();
  int nnn=200;
  for(int iii=0; iii<=nnn; iii++) {
    double nn=nn1*exp(double(iii)/double(nnn)*log(nn2/nn1));
    double rho = eos.MassDensityGCC(nn);
    double P1 = eos.GetMinimumPressure(nn);
    double P2 = eos.GetMaximumPressure(nn);
    if (P1<P && P<P2) {
      double T1 = eos.GetMinimumTemperature(nn);
      double T2 = eos.GetMaximumTemperature(nn);
      double T = eos.TemperatureGivenDensityAndPressure(nn,P,T1,T2,1e-8);
      double E = eos.Energy(nn,T);
      cout << name;
      cout << " rho= " << fix(11,8,rho);
      cout << " T[K]= " << fix(16,3,T*PC::AUToK);
      cout << " P[GPa]= " << fix(16,6,P*PC::AUToGPa);
      cout << " E[Ha/fu]= " << fix(14,8,E);
      cout << endl;
    }
  }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////

void AddRadiationCorrectionToEnergyAndPressure(EOSTableDiffT & eos) {
  //  warning("Applying radiation correction to E and P.");

  for(int i=0; i<eos.GetNumber(); i++) {
    double nni,Ti;
    eos.GetDataPoint(i,nni,Ti);

    double TInK   = Ti * PC::AUToK;
    double PRadSI = 4.0/3.0 * PC::StephanBoltzmannConstant / PC::c * pow(TInK,4.0);
    double PRadAU = PRadSI * PC::PaToAU;
    double V      = 1.0/nni;
    double ERadAU = 3.0 * V * PRadAU;
    
    eos.ee[i] += ERadAU;
    eos.pp[i] += PRadAU;

  }

}

////////////////////////////////////////////////////////////////////////////////////////////////////////

void PrintConvexHull(const string fileName, const EOSTableDiffT & eos, const double eps=1e-10) {
  cout << "Computing the convex hull for an EOS ..." << endl;
  Array1 <int> ch = eos.DetermineConvexHull(eps);
  
  ofstream of(fileName.c_str());
  if (!of) {
    error("Could not open file "+fileName+" to write convex hull data EOS points.");
    return;
  }

  for(int i=0; i<ch.Size(); i++) {
    eos.PrintOnePoint(of,ch[i],false);
  }

  cout << "Wrote convex hull info to file " << fileName << endl << endl;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////

void PrintOneEOSPointIdealDebye(ofstream & of, const EOSTableDiffT & eos, const double nn, const double T) {
  //  double f = 1.0/nFU; // print extensive quatities per atom (not per FU)
  double f = 1.0; // print extensive quatities per FU (not per atom nor per electron)

  double rho = eos.MassDensityGCC(nn);
  double V   = 1.0/nn; // volume of formula unit
  of << " rho[g/cc]= " << fix(11,8,rho);
  of << " V[A^3]= " << fix(16,8,V*f*PC::AUToA3);
  of << " T[K]= " << fix(9,0,T*PC::AUToK);

  double P    = eos.Pressure(nn,T);
  double PE   = eos.PressureErrorBar(nn,T);
  //  of << " P[GPa]= " << fix(16,6,P*PC::AUToGPa);

  double E    = eos.Energy(nn,T);
  double EE   = eos.EnergyErrorBar(nn,T);
  //  of << " E[Ha]= " << fix(16,8,E*f);

  of << " P[GPa]= " << fix(14,3,P*PC::AUToGPa);
  of << " +- " << fix(9,3,PE*PC::AUToGPa);
  of << " E[Ha]= " << fix(18,8,E);
  of << " +- " << fix(11,8,EE);

  // electrons
  const double m      = 1.0;
  const double g      = 2.0;
  const double lambda = 0.5/m;
  const double Ne = eos.GetNElectronsFormulaUnit();
  double ne=  Ne/V;

  double EF = FermiEnergy(lambda,ne,g);
  //  cout << endl;
  //  cout << "Fermi degeneracy (electron gas only, no ions, all in AU per electron]:" << endl;
  //  Write3(T,EF,T/EF);

  double beta = 1.0/T;
  double mu   = MuFermiGas(lambda,beta,ne,g); // mu < EF, mu(T->0)=EF
  if (mu>=EF) error(" Check mu<EF: ",mu,EF);

  double PEl      = PressureFermiGas(lambda,beta,ne,g);
  double PElBoltz = PressureBoltzmannGas(beta,ne);
  if (PEl<=PElBoltz*(1-1e-5)) error("Check PEl>PElBoltz: ",PEl,PElBoltz,(PEl-PElBoltz)/PElBoltz);

  double EEl = EnergyFermiGas(lambda,beta,ne,g); // Ha per electron
  //  double EElBoltz = EnergyBoltzmannGas(beta);

  double EIonBoltz = EnergyBoltzmannGas(beta)*eos.GetNAtomsFormulaUnit(); // Ha per FU
  double PIonBoltz = PressureBoltzmannGas(beta,eos.GetNAtomsFormulaUnit()/V); // can add H and O contributions, NI=NI_O+NI_H=2*NMol
  double EElectronIon      = EIonBoltz + EEl*Ne;
  double PElectronIon      = PIonBoltz + PEl;
  //  Write3(P,PIonBoltz,PElectronIon);
  //  Write3(E,EIonBoltz,EElectronIon);
  //  cout << endl;
  of << " PIdeal[GPa]= " << fix(16,6,PElectronIon*PC::AUToGPa);
  of << " EIdeal[Ha]= "  << fix(16,8,EElectronIon*f);

  double eDebye = UDebye(eos.GetNChargesFormulaUnit(),eos.GetZChargesFormulaUnit(),V,T); // per FU
  double pDebye = PDebye(eos.GetNChargesFormulaUnit(),eos.GetZChargesFormulaUnit(),V,T);
  //  Write2(pDebye,eDebye);
  //  cout << endl;

  double EElectronIonDebye      = EElectronIon + eDebye;
  double PElectronIonDebye      = PElectronIon + pDebye;
  of << " PIdealDebye[GPa]= " << fix(16,6,PElectronIonDebye*PC::AUToGPa);
  of << " EIdealDebye[Ha]= "  << fix(16,8,EElectronIonDebye*f);

  double PRelExcess      = (P-PElectronIon)/PElectronIon;
  double PRelExcessDebye = pDebye          /PElectronIon;
  double ERelExcess      = (E-EElectronIon)/EElectronIon;
  double ERelExcessDebye = eDebye          /EElectronIon;

  of << " 1-P/PIdeal= " << fix(16,6,PRelExcess);
  of << " 1-E/EIdeal= " << fix(16,8,ERelExcess);
  of << " 1-PDebye/PIdeal= " << fix(16,6,PRelExcessDebye);
  of << " 1-EDebye/EIdeal= " << fix(16,8,ERelExcessDebye);

  //  double PElectronIonInGPa      = PElectronIon*PC::AUToGPa;
  //  double PElectronIonDebyeInGPa = PElectronIonDebye*PC::AUToGPa;

  //  cout << s << " "; Write7(TinK,rhoGCC,PinGPa,PElectronIonInGPa,PElectronIonDebyeInGPa,PRelExcess,PRelExcessDebye);
  //  cout << s << " "; Write7(TinK,rhoGCC,E,     EElectronIon,EElectronIonDebye,ERelExcess,ERelExcessDebye);
  //  cout << s << " "; Write8(TinK,rhoGCC,PinGPa,E,PRelExcess,ERelExcess,PRelExcessDebye,ERelExcessDebye);
  //  Quit("EOS point");
  of << endl;
}

void PrintIsochorPoints(const string fileName, const EOSTableDiffT & eos) {
  cout << "Computing isochores for an EOS ..." << endl;
  ofstream of(fileName.c_str());
  if (!of) {
    error("Could not open file "+fileName+" to write isochores.");
    return;
  }

  for(int inn=0; inn<eos.tnn.Size(); inn++) {
    for(int iT=0; iT<eos.lists[inn].Size(); iT++) {
      of << "index= " << inn;
      //      eos.PrintOnePoint(of,inn,iT,false);
      double nn = eos.GetDensityPoint(inn);
      double T  = eos.GetTemperaturePoint(inn,iT);
      PrintOneEOSPointIdealDebye(of,eos,nn,T);
    }
  }

  cout << "Wrote isochores with points to file " << fileName << endl << endl;

}

void PrintIsochores(const string fileName, const EOSTableDiffT & eos) {
  cout << "Computing isochores for an EOS ..." << endl;
  ofstream of(fileName.c_str());
  if (!of) {
    error("Could not open file "+fileName+" to write isochores.");
    return;
  }

  for(int inn=0; inn<eos.tnn.Size(); inn++) {
    double nn = eos.tnn[inn];
    double T1 = eos.T[eos.lists[inn].First()];
    double T2 = eos.T[eos.lists[inn].Last()];
    const int np=201; 
    for(int i=0; i<=np; i++) { 
      double T = T1*exp(log(T2/T1)*double(i)/double(np));
      of << "index= " << inn;
      PrintOneEOSPointIdealDebye(of,eos,nn,T);
    }
  }

  cout << "Wrote interpolated isochores to file " << fileName << endl << endl;

}

template <class IM> 
void PrintIsochoresMixture(const string fileName, IM & im) {
  cout << "Computing isochores for a mixture ..." << endl;
  ofstream of(fileName.c_str());
  if (!of) {
    error("Could not open file "+fileName+" to write isochores.");
    return;
  }

  double T1 = im.GetMinimumTemperature();
  double T2 = im.GetMaximumTemperature();

  while(im.CheckForOverlapAtTemperature(T1)==false) {
    T1 *= 1.1;
    if (T1>=T2) {
      cout << "Lacking P-T overlap, could not derive any isochores for the mixtures." << endl;
      return;
    }
  }
  while(im.CheckForOverlapAtTemperature(T2)==false) {
    T2 /= 1.1;
    if (T2<=T1) {
      cout << "Lacking P-T overlap, could not derive any isochores for the mixtures." << endl;
      return;
    }
  }

  double nn1 = min(im.MinimumDensityForTemperature(T1),im.MinimumDensityForTemperature(T2));
  double nn2 = max(im.MaximumDensityForTemperature(T1),im.MaximumDensityForTemperature(T2));

  int nnn = 15;
  for(int inn=0; inn<=nnn; inn++) {
    double nn = nn1*exp(log(nn2/nn1)*double(inn)/double(nnn));

    const int np=201; 
    for(int i=0; i<=np; i++) { 
      double T = T1*exp(log(T2/T1)*double(i)/double(np));
      double P1,P2;
      bool ok = im.MinimumMaximumPressureForTemperatureSafely(T,P1,P2,false);
      if (ok) { 
	double nn1 = im.DensityGivenTemperatureAndPressure(T,P1);
	double nn2 = im.DensityGivenTemperatureAndPressure(T,P2);
	if (nn>=nn1 && nn<=nn2) {
	  double P = im.Pressure(nn,T);
	  of << "index= " << inn;
	  im.PrintOnePoint(of,T,P);
	}
      }
    }
  }
  
  cout << "Wrote isochores for mixtures to file " << fileName << endl << endl;

}

////////////////////////////////////////////////////////////////////////////////////////////////////////

void PrintIsothermPoints(const string fileName, const EOSTableDiffT & eos) {
  cout << "Computing isotherms for an EOS ..." << endl;
  ofstream of(fileName.c_str());
  if (!of) {
    error("Could not open file "+fileName+" to write isochores.");
    return;
  }

  Array1 <double> TT = eos.GetListOfAllTemperatures();
  for(int iT=0; iT<TT.Size(); iT++) {
    double T = TT[iT];
    for(int inn=0; inn<eos.tnn.Size(); inn++) {
      double nn = eos.GetDensityPoint(inn);
      for(int jT=0; jT<eos.lists[inn].Size(); jT++) {
	if (eos.GetTemperaturePoint(inn,jT)==T) {
	  of << "index= " << iT;
	  eos.PrintOnePoint(of,nn,T);
	}
      }
    }
  }

  cout << "Wrote isotherm points to file " << fileName << endl << endl;

}

void PrintIsotherms(const string fileName, const EOSTableDiffT & eos) {
  cout << "Computing isotherms for an EOS ..." << endl;
  ofstream of(fileName.c_str());
  if (!of) {
    error("Could not open file "+fileName+" to write isochores.");
    return;
  }

  Array1 <double> TT = eos.GetListOfAllTemperatures();
  for(int iT=0; iT<TT.Size(); iT++) {
    double T = TT[iT];
    double nn1 = eos. MinimumDensityForTemperature(T);
    double nn2 = eos. MaximumDensityForTemperature(T);
    int nnn=200;
    for(int iii=0; iii<=nnn; iii++) {
      double nn=nn1*exp(double(iii)/double(nnn)*log(nn2/nn1));
      of << "index= " << iT;
      eos.PrintOnePoint(of,nn,T);
    }
  }

  cout << "Wrote isotherms to file " << fileName << endl << endl;

}

template <class IM> 
void PrintIsothermsMixture(const string fileName, IM & im) {
  cout << "Computing isotherms for a mixture ..." << endl;
  ofstream of(fileName.c_str());
  if (!of) {
    error("Could not open file "+fileName+" to write isotherms.");
    return;
  }

  double T1 = im.GetMinimumTemperature();
  double T2 = im.GetMaximumTemperature();
  int nT = 10;

  int index = 1;
  for(int iT=0; iT<=nT; iT++) {
    double T=T1*exp(double(iT)/double(nT)*log(T2/T1));
    double P1,P2;
    bool ok = im.MinimumMaximumPressureForTemperatureSafely(T,P1,P2,false);
    if (ok && P2>2.0*P1) { // only print an isotherm if there is a minimum range in pressure available
      int nP = int(ceil(log(P2/P1)*5.0));
      for(int iP=0; iP<=nP; iP++) {
	double P = P1*exp(double(iP)/double(nP)*log(P2/P1));
	of << "index= " << index;
	im.PrintOnePoint(of,T,P);
      }
      index++;
    }
  }
  
  cout << "Wrote isotherms of mixture to file " << fileName << endl << endl;

}

////////////////////////////////////////////////////////////////////////////////////////////////////////

void PrintIsobar(ofstream & of, const EOSTableDiffT & eos, const double P, const int index) {
  double nn1 = eos.GetMinimumDensity();
  double nn2 = eos.GetMaximumDensity();
  int nnn=200;
  for(int iii=0; iii<=nnn; iii++) {
    double nn=nn1*exp(double(iii)/double(nnn)*log(nn2/nn1));
    //    double rho = eos.MassDensityGCC(nn);
    double P1 = eos.GetMinimumPressure(nn);
    double P2 = eos.GetMaximumPressure(nn);
    if (P1<P && P<P2) {
      double T1 = eos.GetMinimumTemperature(nn);
      double T2 = eos.GetMaximumTemperature(nn);
      double T = eos.TemperatureGivenDensityAndPressure(nn,P,T1,T2,1e-8);
      //      double E = eos.Energy(nn,T);
      of << "index= " << index;
      eos.PrintOnePoint(of,nn,T);
      //      of << " rho[g/cc]= " << fix(11,8,rho);
      //      of << " T[K]= " << fix(16,3,T*PC::AUToK);
      //      of << " P[GPa]= " << fix(16,6,P*PC::AUToGPa);
      //      of << " E[Ha]= " << fix(14,8,E);
      //      of << endl;
    }
  }
}

void PrintIsobars(const string fileName, const EOSTableDiffT & eos) {
  cout << "Computing isobars for an EOS ..." << endl;

  ofstream of(fileName.c_str());
  if (!of) {
    error("Could not open file "+fileName+" to write isobars.");
    return;
  }

  int inn = 0;
  int iT  = 0;
  double nn = eos.GetDensityPoint(inn);
  double T  = eos.GetTemperaturePoint(inn,iT);
  double P1 = eos.Pressure(nn,T);

  inn = eos.GetNumberOfDensities()-1;
  iT  = eos.GetNumberOfTemperatures(inn)-1;
  nn = eos.GetDensityPoint(inn);
  T  = eos.GetTemperaturePoint(inn,iT);
  double P2 = eos.Pressure(nn,T);
 
  int index = 1;
  double fP = 2.5;
  double P = P1;
  while (P < P2) {
    PrintIsobar(of,eos,P,index++);
    P *= fP;
    //    if (index>=3) break;
  }

  cout << "Wrote isobars to file " << fileName << endl << endl;

}

template <class IM> 
void PrintIsobar(ofstream & of, IM & im, const double P, const int index) {
  double T1 = im.GetMinimumTemperature();
  double T2 = im.GetMaximumTemperature();

  const int n=500;
  int nValidPoints = 0;
  for(int i=0; i<=n; i++) { // before printing anything see how many valid points there are
    double T=T1*exp(double(i)/double(n)*log(T2/T1));
    double P1,P2;
    bool ok = im.MinimumMaximumPressureForTemperatureSafely(T,P1,P2,false);
    if (ok && P>=P1 && P<=P2) nValidPoints++;
  }
  if (nValidPoints<3) return; // do not print too short isobars

  for(int i=0; i<=n; i++) {
    double T=T1*exp(double(i)/double(n)*log(T2/T1));
    double P1,P2;
    bool ok = im.MinimumMaximumPressureForTemperatureSafely(T,P1,P2,false);
    if (ok && P>=P1 && P<=P2) {
      of << "index= " << index;
      im.PrintOnePoint(of,T,P);
    }
  }
}


template <class IM> 
void PrintIsobarsMixture(const string fileName, IM & im) {
  cout << "Computing isobars for a mixture ..." << endl;

  ofstream of(fileName.c_str());
  if (!of) {
    error("Could not open file "+fileName+" to write isobars.");
    return;
  }

  double T1 = im.GetMinimumTemperature();
  double T2 = im.GetMaximumTemperature();
  //  double P1Min = im.MinimumPressureForTemperatureSafely(T1);
  //  double P2Max = im.MaximumPressureForTemperatureSafely(T2);
  double P1Min,P1Max;
  while(im.MinimumMaximumPressureForTemperatureSafely(T1,P1Min,P1Max,false)==false) {
    T1 *= 1.1;
    if (T1>=T2) {
      cout << "Lacking P-T overlap, could not derive any isobars for the mixtures." << endl;
      return;
    }
  }
  double P2Min,P2Max;
  while(im.MinimumMaximumPressureForTemperatureSafely(T2,P2Min,P2Max,false)==false) {
    T2 /= 1.1;
    if (T2<=T1) {
      cout << "Lacking P-T overlap, could not derive any isobars for the mixtures." << endl;
      return;
    }
  }

  int index = 1;
  double fP = 2.5;
  double P = P1Min;
  while (P < P2Max) {
    PrintIsobar(of,im,P,index++);
    P *= fP;
  }

  cout << "Wrote isobars of mixture to file " << fileName << endl << endl;

}
 
////////////////////////////////////////////////////////////////////////////////////////////////////////

void PrintAdiabats(const string fileName, const EOSTableDiffT & eos) {
  cout << "Computing adiabats for an EOS ..." << endl;

  ofstream of(fileName.c_str());
  if (!of) {
    error("Could not open file "+fileName+" to write adiabats.");
    return;
  }

  int index = 0;
  //  const double fT = 2.0;
  const double fT = sqrt(10.0);

  //  int inn1 = 4; // <<< will trigger out-of-range error of we only have 4 isochores
  int inn = 0;
  int iT  = 0;
  double nn = eos.GetDensityPoint(inn);
  //  double T  = eos.GetTemperaturePoint(inn,iT)*2.0; // 10000K --> 20000K
  double T  = eos.GetTemperaturePoint(inn,iT);

  Array1 <DataElement> isentrope;
  while (T < eos.GetMaximumTemperature(inn)) {
    //    cout << "Trying to compute adiabat starting from"; Write3(T*PC::AUToK,eos.GetMaximumTemperature(inn)*PC::AUToK,index);
    isentrope = ComputeAdiabat(of,eos,nn,eos.tnn.Last(),T,index);
    T *= fT;
  }

  double TMin = eos.GetTemperatureArray()[0];
  int innTMin = eos.MinimumDensityIndexForTemperature(TMin);
  nn = eos.GetDensityPoint(innTMin);
  if (innTMin>0) {
    int iT  = 0;
    //    double T  = eos.GetTemperaturePoint(innTMin,iT);
    double T  = eos.GetTemperaturePoint(innTMin,iT)*2.0;

    while (T < eos.GetMaximumTemperature(inn)) {
      //    Write2(T1*PC::AUToK,eos.GetMaximumTemperature(inn1)*PC::AUToK);
      isentrope = ComputeAdiabat(of,eos,nn,eos.tnn.Last(),T,index);

      int innTMin2 = eos.MinimumDensityIndexForTemperature(T);
      if (innTMin2<innTMin) { // there is room to march towards lower density
	isentrope = ComputeAdiabat(of,eos,nn,eos.tnn[innTMin2],T,index);
      }
      T *= fT;
    }
  }

  cout << "Wrote adiabats to file " << fileName << endl << endl;

}

////////////////////////////////////////////////////////////////////////////////////////////////////////

class Entry {
  public:
  string fileName;
  Array1 <string> element;
  Array1 <double> number;

  string GetName() const {
    if (element.Size()==1) {
      return NameFromChemicalSymbol(element[0],true);
    } else {
      string name;
      for(int i=0; i<element.Size(); i++) {
	name += element[i];
	if (fabs(number[i]-1.0)>1e-10) {
	  if (fabs(number[i]-round(number[i]))<1e-10) {
	    name += IntToString(int(number[i]));
	  } else {
	    name += DoubleToString(number[i]);
	  }
	}
      }
      return name;
    }
  }

  bool IsAnElement() const {
    return (element.Size()==1);
  }
};

class Database {
  public:
  Array1 <Entry> entries;

  void ReadDataBaseFile(const string & fileName) {
    Parser p(fileName);
    p.SetIgnoreComments();
    p.SetIgnoreEmptyLines();
    while (p.ReadLine()) {
      Entry entry;
      entry.fileName = p.GetString(0);
      for(int i=1; i<p.GetNWords(); i+=2) {
	entry.element.PushBack(p.GetString(i));
	entry.number.PushBack(p.GetDouble(i+1));
      }
      entries.PushBack(entry);
    }
    cout << "Parsed database file \"" << fileName << "\" with " << entries.Size() << " entries." << endl;
  }

  EOSTableDiffT ReadEOSTable(const int k) const {
    double mFU = 0.0;
    for(int i=0; i<entries[k].element.Size(); i++) {
      mFU += entries[k].number[i] * MassNumberFromName(entries[k].element[i]);
    }
    mFU *= PC::u/PC::me; // convert from nuclear mass unit 'u' to electron masses (atomic units)
    double nAtomsPerFormulaUnit = entries[k].number.Sum();
    EOSTableDiffT eos;
    eos.ReadTableInStandardFormat(entries[k].fileName,nAtomsPerFormulaUnit,mFU);
    eos.SetChargesFormulaUnit(entries[k].element,entries[k].number);
    eos.ExtractHugoniotDataFromFile(entries[k].fileName);
    eos.ExtractReferencesFromFile(entries[k].fileName);
    eos.SetName(entries[k].GetName());
    eos.SetDatabaseIndex(k);
    return eos;
  }

  void Print() const {
    for(int i=0; i<entries.Size(); i++) {
      cout << IntToStringMaxNumber(i+1,entries.Size(),' ');
      cout << ": ";
      cout << entries[i].GetName();
      cout << endl;
    }
  }

  void PrintInfoForAllEOS() const {
    Array1 <EOSTableDiffT> eos;
    for(int i=0; i<entries.Size(); i++) { // separate reading part from print the info
      eos.PushBack(ReadEOSTable(i));
    }
    for(int i=0; i<entries.Size(); i++) {
      eos[i].PrintInfo();
    }
  }

  int Size() const {
    return entries.Size(); 
  }

};

////////////////////////////////////////////////////////////////////////////////////////////////////////

void CallPython(EOSTableDiffT & eos, const Array1 <string> & figures, const string & pythonCommand) {
  if (pythonCommand=="") return;
  cout << "Calling Python to make plots. Note that this may fail. Avoid trying this out on Mondays ;=)" << endl << endl;
  for(int i=0; i<figures.Size(); i++) {
    string command = pythonCommand+" "+figures[i]+".py" + " \"First-Principles Equation of State of "+eos.GetName()+"\"";
    cout << "System call: " << command << endl;
    system(command.c_str());
    cout << endl;
  }
}

template <class IM> 
void CallPython(IM & im, const Array1 <string> & figures, const string & pythonCommand) {
  if (pythonCommand=="") return;
  cout << "Calling Python to make plots. Note that this may fail. Avoid trying this out on Mondays ;=)" << endl << endl;
  for(int i=0; i<figures.Size(); i++) {
    string command = pythonCommand+" "+figures[i]+".py" + " \"FPEOS of "+im.GetName()+" Mixture\"";
    cout << "System call: " << command << endl;
    system(command.c_str());
    cout << endl;
  }
}

void OpenPDFFiles(const Array1 <string> & figures, const string & openCommand) {
  if (openCommand=="") return;
  cout << endl << "Trying to open the new PDF files with command \"" << openCommand << "\"." << endl << endl;
  for(int i=0; i<figures.Size(); i++) {
    string command = openCommand+" "+figures[i]+".pdf";
    cout << "System call: " << command << endl;
    system(command.c_str());  
    cout << endl;
  }
}

void PrintReferenceToThisPaper() {
  cout << endl;
  cout << "For this calculation, we ask you to cite these references:" << endl;
  cout << endl;
  cout << "B. Militzer, F. Gonzalez-Cataldo, S. Zhang, K. Driver, F. Soubiran" << endl;
  cout << "\"First-Principles Equation of State Database for Warm Dense Matter Computation\"" << endl;
  cout << "Physical Review E 103 (2021) 013203." << endl;
  cout << "DOI:10.1103/PhysRevE.103.013203" << endl;
  cout << endl;
}

void ProcessSingleEOS(EOSTableDiffT & eos, const bool logInterpolation, const string & pythonCommand, const string & openCommand) {
  PrintConvexHull("FPEOS_convex_hull.txt",eos);
  PrintIsobars("FPEOS_isobars.txt",eos);
  PrintIsochorPoints("FPEOS_isochor_points.txt",eos);
  PrintIsochores("FPEOS_isochores_ideal_Debye.txt",eos);
  PrintIsotherms("FPEOS_isotherms.txt",eos);
  PrintIsothermPoints("FPEOS_isotherm_points.txt",eos);
  PrintAdiabats("FPEOS_adiabats.txt",eos); cout << endl;

  // no longer use log interpolation for ALL Hugoniot calculations (needed for radiative calculations anyway. Keep is all Hug curves consistent.)
  if (logInterpolation) eos.SwitchToLogInterpolation(); 
  double TMaxComp = PrintHugoniotCurve("FPEOS_Hugoniot.txt",eos); // TMaxComp based on ~200 points, not super accurate
  //  return; //  to save time

  EOSTableDiffT eosLower(eos);
  eosLower.hugoniotnn0 *= 0.80;
  PrintHugoniotCurve("FPEOS_Hugoniot_lower_initial_density.txt",eosLower);

  EOSTableDiffT eosHigher(eos);
  eosHigher.hugoniotnn0 *= 1.20;
  PrintHugoniotCurve("FPEOS_Hugoniot_higher_initial_density.txt",eosHigher);

  EOSTableDiffT eosRel(eos);
  ApplyRelativisticCorrectionToEnergyAndPressure(eosRel);
  PrintHugoniotCurve("FPEOS_Hugoniot_rel.txt",eosRel);

  string fileNameHugRad = "FPEOS_Hugoniot_rad.txt";
  if (logInterpolation && eos.name!="Hydrogen") { 
    EOSTableDiffT eosRad(eos);
    //  eosRad.SwitchToLogInterpolation();
    AddRadiationCorrectionToEnergyAndPressure(eosRad);
    //  PrintIsochores("FPEOS_isochores_rad.txt",eosRad);
    PrintHugoniotCurve(fileNameHugRad,eosRad);
  } else { // For hydrogen, do not try to construct the Hugoniot curve with radiative effects because the result would be noisy.
    std::remove(fileNameHugRad.c_str()); 
  }

  Array1 <string> figures;
  figures.PushBack("FPEOS_T_P_Debye_plot");
  figures.PushBack("FPEOS_T_E_Debye_plot");
  figures.PushBack("FPEOS_T_P_Ideal_plot");
  figures.PushBack("FPEOS_T_E_Ideal_plot");
  figures.PushBack("FPEOS_P_T_plot");
  figures.PushBack("FPEOS_rho_T_plot");
  figures.PushBack("FPEOS_comp_T_plot");
  figures.PushBack("FPEOS_comp_P_plot");
  figures.PushBack("FPEOS_up_us_plot");

  if (pythonCommand!="") {
    CallPython(eos,figures,pythonCommand);
    OpenPDFFiles(figures,openCommand);
  }

  PrintReferenceToThisPaper();
  eos.PrintAllReferences();
}

void DetermineHugoniotCompressionMaximumSingleEOS(EOSTableDiffT & eos, const bool logInterpolation) {
  // no longer use log interpolation for ALL Hugoniot calculations (needed for radiative calculations anyway. Keep is all Hug curves consistent.)
  if (logInterpolation) eos.SwitchToLogInterpolation(); 
  double TMaxComp = PrintHugoniotCurve("FPEOS_Hugoniot.txt",eos); // TMaxComp based on ~200 points, not super accurate
  //  return; //  to save time
  
  if (eos.GetName()!="Hydrogen") {
    //  double T1 = eos.GetMinimumTemperature();
    //  double T2 = eos.GetMaximumTemperature();
    double T1 = max(eos.GetMinimumTemperature(),TMaxComp*0.80);
    double T2 = min(eos.GetMaximumTemperature(),TMaxComp*1.20);
    FindDensityOnHugoniotAsFunctionOfTemperature<EOSTableDiffT> f(eos);
    TMaxComp = FindMaximumTrisection(T1,T2,(T2-T1)*1e-8,f,true,"find_T_max_compression");
    double nnMaxComp = f(TMaxComp);
    double maxComp = nnMaxComp / eos.GetHugoniotnn0();
    Form form(fix,LEFT);
    form.width(9);

    double nn0 = eos.GetHugoniotnn0();
    double P0  = eos.GetHugoniotP0();
    double E0  = eos.GetHugoniotE0();
    cout << "compMax: "
	 << form(eos.GetName()) 
	 << " index= " << fix(2,eos.GetDatabaseIndex())
	 << " <Z>= "   << fix(7,3,eos.AverageIonicCharge());
    PrintOneHugoniotPoint(cout,eos,nn0,P0,E0,nnMaxComp,TMaxComp); // will also print up-us
  }

  PrintReferenceToThisPaper();
  eos.PrintAllReferences();
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ProcessBinaryMixture(IdealMixture & im, const string & pythonCommand, const string & openCommand) {
  PrintConvexHull("FPEOS_mixture_convex_hull1.txt",im.eos1);
  PrintConvexHull("FPEOS_mixture_convex_hull2.txt",im.eos2);
  PrintIsobarsMixture("FPEOS_mixture_isobars.txt",im);
  PrintIsochoresMixture("FPEOS_mixture_isochores.txt",im);
  PrintIsothermsMixture("FPEOS_mixture_isotherms.txt",im);
  bool notAtBoundary = false;
  //  PrintHugoniotCurve("FPEOS_Hugoniot.txt",im,notAtBoundary); 
  PrintHugoniotCurve("FPEOS_mixture_Hugoniot.txt",im,notAtBoundary); // use default of 200 temperature points
  //  PrintHugoniotCurve("FPEOS_mixture_Hugoniot.txt",im,notAtBoundary,500); // use 500 temperature points

  Array1 <string> figures;
  figures.PushBack("FPEOS_mixture_P_T_plot");
  figures.PushBack("FPEOS_mixture_rho_T_plot");
  figures.PushBack("FPEOS_mixture_comp_T_plot");
  figures.PushBack("FPEOS_mixture_comp_P_plot");
  figures.PushBack("FPEOS_mixture_up_us_plot");

  if (pythonCommand!="") {
    CallPython(im,figures,pythonCommand);
    OpenPDFFiles(figures,openCommand);
  }

  PrintReferenceToThisPaper();
  im.eos1.PrintFirstReference();
  im.eos2.PrintFirstReference();
}

void DetermineHugoniotCompressionMaximumBinaryMixture(IdealMixture & im) {
  bool notAtBoundary = false;
  //  double TMaxComp = PrintHugoniotCurve("FPEOS_Hugoniot.txt",im,notAtBoundary,100); // reduce number of points from 200 to 100
  double TMaxComp = PrintHugoniotCurve("FPEOS_Hugoniot.txt",im,notAtBoundary, 50); // reduce number of points from 200 to 50

  //  if (notAtBoundary && im.eos1.GetName()!="Hydrogen" && im.eos2.GetName()!="Hydrogen" ) {
  if (notAtBoundary) {
    cout << "Determining compression maximum of " << im.GetName() << " mixture ..." << endl;
    double T1 = max(im.GetMinimumTemperature(),TMaxComp*0.80);
    double T2 = min(im.GetMaximumTemperature(),TMaxComp*1.20);
    FindDensityOnHugoniotAsFunctionOfTemperature<IdealMixture> f(im);
    TMaxComp = FindMaximumTrisection(T1,T2,(T2-T1)*1e-6,f,true,"find_T_max_compression");
    double nnMaxComp = f(TMaxComp);
    double maxComp = nnMaxComp / im.GetHugoniotnn0();
    Form form(fix,LEFT);
    form.width(9+1+9);

    double nn0 = im.GetHugoniotnn0();
    double P0  = im.GetHugoniotP0();
    double E0  = im.GetHugoniotE0();
    cout << "compMax: "
	 << form(im.GetName()) 
	 << " index1= " << fix(2,im.eos1.GetDatabaseIndex()) 
	 << " N1= "     << fix(8,6,im.N1) 
	 << " index2= " << fix(2,im.eos2.GetDatabaseIndex())
	 << " N2= "     << fix(8,6,im.N2) 
	 << " <Z>= "    << fix(7,3,im.AverageIonicCharge());
    PrintOneHugoniotPoint(cout,im,nn0,P0,E0,nnMaxComp,TMaxComp); // will also print up-us
  }

  //  PrintReferenceToThisPaper();
  //  im.eos1.PrintFirstReference();
  //  im.eos2.PrintFirstReference();
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ProcessTernaryMixture(IdealMixture3 & im, const string & pythonCommand, const string & openCommand) {
  PrintConvexHull("FPEOS_mixture_convex_hull1.txt",im.eos1);
  PrintConvexHull("FPEOS_mixture_convex_hull2.txt",im.eos2);
  PrintConvexHull("FPEOS_mixture_convex_hull3.txt",im.eos3);
  PrintIsobarsMixture("FPEOS_mixture_isobars.txt",im);
  PrintIsochoresMixture("FPEOS_mixture_isochores.txt",im);
  PrintIsothermsMixture("FPEOS_mixture_isotherms.txt",im);
  bool notAtBoundary = false;
  //  PrintHugoniotCurve("FPEOS_Hugoniot.txt",im,notAtBoundary); 
  PrintHugoniotCurve("FPEOS_mixture_Hugoniot.txt",im,notAtBoundary); // use default of 200 temperature points
  //  PrintHugoniotCurve("FPEOS_mixture_Hugoniot.txt",im,notAtBoundary,500); // use 500 temperature points

  Array1 <string> figures;
  figures.PushBack("FPEOS_mixture3_P_T_plot");
  figures.PushBack("FPEOS_mixture3_rho_T_plot");
  figures.PushBack("FPEOS_mixture3_comp_T_plot");
  figures.PushBack("FPEOS_mixture_comp_P_plot"); // same of binary and ternary mixtures
  figures.PushBack("FPEOS_mixture3_up_us_plot");

  if (pythonCommand!="") {
    CallPython(im,figures,pythonCommand);
    OpenPDFFiles(figures,openCommand);
  }

  PrintReferenceToThisPaper();
  im.eos1.PrintFirstReference();
  im.eos2.PrintFirstReference();
  im.eos3.PrintFirstReference();
}

void DetermineHugoniotCompressionMaximumTernaryMixture(IdealMixture3 & im) {
  bool notAtBoundary = false;
  //  double TMaxComp = PrintHugoniotCurve("FPEOS_Hugoniot.txt",im,notAtBoundary,100); // reduce number of points from 200 to 100
  double TMaxComp = PrintHugoniotCurve("FPEOS_Hugoniot.txt",im,notAtBoundary, 50); // reduce number of points from 200 to 50

  //  if (notAtBoundary && im.eos1.GetName()!="Hydrogen" && im.eos2.GetName()!="Hydrogen" ) {
  if (notAtBoundary) {
    cout << "Determining compression maximum of " << im.GetName() << " mixture ..." << endl;
    double T1 = max(im.GetMinimumTemperature(),TMaxComp*0.80);
    double T2 = min(im.GetMaximumTemperature(),TMaxComp*1.20);
    FindDensityOnHugoniotAsFunctionOfTemperature<IdealMixture3> f(im);
    TMaxComp = FindMaximumTrisection(T1,T2,(T2-T1)*1e-6,f,true,"find_T_max_compression");
    double nnMaxComp = f(TMaxComp);
    double maxComp = nnMaxComp / im.GetHugoniotnn0();
    Form form(fix,LEFT);
    form.width(9+1+9);

    double nn0 = im.GetHugoniotnn0();
    double P0  = im.GetHugoniotP0();
    double E0  = im.GetHugoniotE0();
    cout << "compMax: "
	 << form(im.GetName()) 
	 << " index1= " << fix(2,im.eos1.GetDatabaseIndex()) 
	 << " N1= "     << fix(8,6,im.N1) 
	 << " index2= " << fix(2,im.eos2.GetDatabaseIndex())
	 << " N2= "     << fix(8,6,im.N2) 
	 << " index3= " << fix(2,im.eos3.GetDatabaseIndex())
	 << " N3= "     << fix(8,6,im.N3) 
	 << " <Z>= "    << fix(7,3,im.AverageIonicCharge());
    PrintOneHugoniotPoint(cout,im,nn0,P0,E0,nnMaxComp,TMaxComp); // will also print up-us
  }

  //  PrintReferenceToThisPaper();
  //  im.eos1.PrintFirstReference();
  //  im.eos2.PrintFirstReference();
  //  im.eos3.PrintFirstReference();
}

////////////////////////////////////////////////////////////////////////////////////////////////////////

bool ExtractEOSName(const Database & database, Array1 <string> & arg, const string & name, const bool fFlag, int & iEOS, double & fEOS) {
  Write2(name,fFlag);
  string s;
  bool flag;
  if (fFlag==false) { flag = ParseCommandLineArgumentNoSpace(arg,name,s); } // read only string
  else { flag = ParseCommandLineArgumentNoSpace(arg,name,s,fEOS); }         // read string+double
  if (flag==false) return false;
  
  if (IsNumber(s)) {
    iEOS = StringToInt(s)-1; // Hydrogen = H = argument(EOS=1) but database index = 0
    if (iEOS<0) error("Argument following "+name+" is too small",StringToInt(s));
    if (iEOS>=database.Size()) error("Argument following "+name+" is too large",StringToInt(s));
    return true;
  }

  // Could make generalized
  if (s=="H")  s = "Hydrogen";
  if (s=="He") s = "Helium";
  if (s=="B")  s = "Boron";
  if (s=="C")  s = "Carbon";
  if (s=="N")  s = "Nitrogen";
  if (s=="O")  s = "Oxygen";
  if (s=="Ne") s = "Neon";
  if (s=="Na") s = "Sodium";
  if (s=="Mg") s = "Magnesium";
  if (s=="Al") s = "Aluminum";
  if (s=="Si") s = "Silicon";

  for(int i=0; i<database.Size(); i++) 
    if (s==database.entries[i].GetName()) {
      iEOS = i;
      //      Write3(i,s,database.entries[i].GetName());
      return true;
    }

  error("Could not find EOS table for "+s+" in database.");
  return false;
}

inline bool ExtractEOSName(const Database & database, Array1 <string> & arg, const string & name, int & iEOS) {
  double fEOS = 1.0;
  return ExtractEOSName(database,arg,name,false,iEOS,fEOS);
}

inline bool ExtractEOSName(const Database & database, Array1 <string> & arg, const string & name, int & iEOS, double & fEOS) {
  return ExtractEOSName(database,arg,name,true,iEOS,fEOS);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////

int main(int argc, char **argv) {
  cout << endl;
  cout << "#################################################################################" << endl;
  cout << "#                                                                               #" << endl;
  cout << "# First-Principles Equation of State Database for Warm Dense Matter Computation #" << endl;
  cout << "#                                                                               #" << endl;
  cout << "# Burkhard Militzer                                     Berkeley, CA, 05-22-23  #" << endl;
  cout << "#                                                                               #" << endl;
  cout << "#################################################################################" << endl;
  cout << endl;

  Array1 <string> arg = CopyCommandLineArgumentsToArray(argc,argv);
  cout.precision(10);

  string databaseFileName = "fpeos_database.txt";
  ParseCommandLineArgumentNoSpace(arg,"databaseFileName=",databaseFileName);
  Database database;
  database.ReadDataBaseFile("fpeos_database.txt");

  if (ParseCommandLineFlagWithOrWithoutDash(arg,"printDatabaseInfo")) {
    database.PrintInfoForAllEOS(); 
    Quit();
  }

  string pythonCommand="python";
  ParseCommandLineArgumentNoSpace(arg,"pythonCommand=",pythonCommand);
  if (ParseCommandLineFlagWithOrWithoutDash(arg,"doNotCallPython")) pythonCommand="";

  string openCommand="open";
  ParseCommandLineArgumentNoSpace(arg,"openCommand=",openCommand);
  if (ParseCommandLineFlagWithOrWithoutDash(arg,"doNotOpenPDFFiles")) openCommand="";

  bool hugoniotCompressionMaximum=false;
  if (ParseCommandLineFlagWithOrWithoutDash(arg,"hugoniotCompressionMaximum")) hugoniotCompressionMaximum=true;
  bool logInterpolation = true; // needed for Hugoniot calculation with radiative effects but not otherwise
  if (ParseCommandLineFlagWithOrWithoutDash(arg,"noLogInterpolation")) logInterpolation=false;

  if (ParseCommandLineFlagWithOrWithoutDash(arg,"processAllEOSs")) {
    for(int i=1; i<database.Size(); i++) { // i=1 to exclude pure hydrogen for the moment
      //    for(int i=0; i<database.Size(); i++) {
      EOSTableDiffT eos = database.ReadEOSTable(i);
      if (!hugoniotCompressionMaximum) ProcessSingleEOS(eos,logInterpolation,"","");
      else DetermineHugoniotCompressionMaximumSingleEOS(eos,logInterpolation);
    }
    Quit("after processing all EOS tables.");
  }

  if (ParseCommandLineFlagWithOrWithoutDash(arg,"processAllMixturesOfElements")) {
    //    for(int i=1; i<database.Size()-1; i++) { // i=1 to exclude pure hydrogen for the moment
    for(int i=0; i<database.Size()-1; i++) { 
      if (database.entries[i].IsAnElement()) {
	EOSTableDiffT eos1 = database.ReadEOSTable(i);
	for(int j=i+1; j<database.Size(); j++) {
	  if (database.entries[j].IsAnElement()) {
	    EOSTableDiffT eos2 = database.ReadEOSTable(j);
	    IdealMixture im(eos1,0.5,eos2,0.5);
	    if (!hugoniotCompressionMaximum) ProcessBinaryMixture(im,"","");
	    else DetermineHugoniotCompressionMaximumBinaryMixture(im);
	  }
	}
      }
    }
    Quit("after processing all mixtures of elements.");
  }

  if (ParseCommandLineFlagWithOrWithoutDash(arg,"processAllMixtures")) {
    for(int i=0; i<database.Size()-1; i++) { 
      EOSTableDiffT eos1 = database.ReadEOSTable(i);
      for(int j=i+1; j<database.Size(); j++) {
	EOSTableDiffT eos2 = database.ReadEOSTable(j);
	IdealMixture im(eos1,0.5,eos2,0.5);
	if (!hugoniotCompressionMaximum) ProcessBinaryMixture(im,"","");
	else DetermineHugoniotCompressionMaximumBinaryMixture(im);
      }
    }
    Quit("after processing all mixtures.");
  }

  if (arg.Size()<2) {
    cout << endl;
    database.Print();
    cout << endl;
    cout << "You can run our " << arg[0] << " code in the following ways:" << endl;
    cout << endl;
    cout << "For helium EOS:         " << arg[0] << " EOS=2 " << endl;
    cout << "                        " << arg[0] << " EOS=He" << endl;
    cout << "For B4C    EOS:         " << arg[0] << " EOS=13" << endl;
    cout << "                        " << arg[0] << " EOS=B4C" << endl;
    cout << "For MgSiO3 EOS:         " << arg[0] << " EOS=21" << endl;
    cout << "                        " << arg[0] << " EOS=MgSiO3" << endl;
    cout << "For H2+O mixture:       " << arg[0] << " binaryMixture  EOS1=1     2.0   EOS2=6      1.0  rho0=1.0" << endl;
    cout << "                        " << arg[0] << " binaryMixture  EOS1=H     2.0   EOS2=O      1.0  rho0=1.0" << endl;
    cout << "For He+Ne mixture:      " << arg[0] << " binaryMixture  EOS1=2     1.0   EOS2=7      1.0  " << endl;
    cout << "                        " << arg[0] << " binaryMixture  EOS1=He    1.0   EOS2=Ne     1.0  " << endl;
    cout << "For H+He mixture:       " << arg[0] << " binaryMixture  EOS1=1     0.92  EOS2=2      0.08 " << endl;
    cout << "                        " << arg[0] << " binaryMixture  EOS1=H     0.92  EOS2=He     0.08 " << endl;
    cout << "For MgO+MgSiO3 mixture: " << arg[0] << " binaryMixture  EOS1=20    1.0   EOS2=21     1.0"  << endl;
    cout << "                        " << arg[0] << " binaryMixture  EOS1=MgO   1.0   EOS2=MgSiO3 1.0"  << endl;
    cout << "For C+O  mixture:       " << arg[0] << " binaryMixture  EOS1=4     1.0   EOS2=6      1.0 rho0=1.0426 E0=-112.9115" << endl;
    cout << "                        " << arg[0] << " binaryMixture  EOS1=C     1.0   EOS2=O      1.0 rho0=1.0426 E0=-112.9115" << endl;
    cout << "For C+O2 mixture:       " << arg[0] << " binaryMixture  EOS1=4     1.0   EOS2=6      2.0 rho0=1.6381 E0=-188.1576" << endl;
    cout << "                        " << arg[0] << " binaryMixture  EOS1=C     1.0   EOS2=O      2.0 rho0=1.6381 E0=-188.1576" << endl;
    cout << "For C10H16O8 mixture:   " << arg[0] << " ternaryMixture EOS1=17    8.0   EOS2=16     2.0 EOS3=6 8.0" << endl;
    cout << "                        " << arg[0] << " ternaryMixture EOS1=CH1.5 8.0   EOS2=CH2    2.0 EOS3=O 8.0" << endl;
    cout << endl;
    cout << "rho0[g/cc] and E0[Ha/FU] overwrite the default values for initial conditions of Hugoniot curves." << endl;
    cout << endl;
    cout << "The extra numbers are number fractions that define the formula unit (FU)," << endl;
    cout << "which is used to normalize extensive quantities like volume and energy." << endl;
    cout << "To normalize per C2H6 unit, write:  " << arg[0] << " binaryMixture EOS1=15 1.0   EOS2=16 1.0  " << endl;
    cout << "To normalize per CH3  unit, write:  " << arg[0] << " binaryMixture EOS1=15 0.5   EOS2=16 0.5  " << endl;
    cout << "To normalize per atom,      write:  " << arg[0] << " binaryMixture EOS1=15 0.125 EOS2=16 0.125" << endl;
    cout << endl;
    cout << "The FPEOS code will write a number of .txt files, then call Python to make plots, and" << endl;
    cout << "finally try to open the .pdf files. To identify all new output files, type \"ls -ltr\"" << endl;
    cout << endl;
    cout << "pythonCommand=... changes the command to start the Python scripts." << endl;
    cout << "                  The default is \"python\", which you may like to change to \"python3\"" << endl; 
    cout << "openCommand=...   changes the command to display the graphics files." << endl;
    cout << "                  Use \"open\" on Macs (default) and \"xdg-open\" on Linux." << endl; 
    cout << endl;
    cout << "Add the options \"doNotCallPython\" or \"doNotOpenPDFFiles\" if you prefer. The arguments" << endl;
    cout << "\"processAllEOSs\",\"processAllMixturesOfElements\", \"processAllMixtures\"," << endl;
    cout << "\"hugoniotCompressionMaximum\", and \"noLogInterpolation\" are available also." << endl;
    cout << endl;
    cout << "Happy FPEOS computing and best wishes from Burkhard Militzer." << endl;
    cout << endl;
    exit(0);
  }

  bool binary  = ParseCommandLineFlagWithOrWithoutDash(arg,"binaryMixture");
  bool ternary = ParseCommandLineFlagWithOrWithoutDash(arg,"ternaryMixture");
  if (binary && ternary) error("Please chose between \"binaryMixture\" and \"ternaryMixture\"");
  if (!binary && !ternary) {

    int iEOS = 2; // He
    if (ParseCommandLineArgumentNoSpace(arg,"EOS1=",iEOS)) error("Need to specify \"binaryMixture\" in combination with \"EOS1\".");
    if (ParseCommandLineArgumentNoSpace(arg,"EOS2=",iEOS)) error("Need to specify \"binaryMixture\" in combination with \"EOS2\".");
    bool EOSFlag = ExtractEOSName(database,arg,"EOS=",iEOS);
    if (EOSFlag==false) error("Must specify at least one argument of type EOS=");

    EOSTableDiffT eos = database.ReadEOSTable(iEOS);

    double rho0GCC;
    bool rho0Flag = ParseCommandLineArgumentNoSpace(arg,"rho0=",rho0GCC);
    if (rho0Flag) eos.OverwriteHugoniotRho0GCC(rho0GCC);

    double E0;
    bool E0Flag = ParseCommandLineArgumentNoSpace(arg,"E0=",E0);
    if (E0Flag) eos.OverwriteHugoniotE0(E0);

    if (!hugoniotCompressionMaximum) ProcessSingleEOS(eos,logInterpolation,pythonCommand,openCommand);
    else DetermineHugoniotCompressionMaximumSingleEOS(eos,logInterpolation);

  } else if (binary) {

    int i1    = 2-1; // He
    double f1 = 0.5;
    ExtractEOSName(database,arg,"EOS1=",i1,f1);

    int i2    = 7-1; // Ne
    double f2 = 1.0-f1;
    ExtractEOSName(database,arg,"EOS2=",i2,f2);

    //    double ff = 1.0/(f1+f2);
    //    f1 *= ff;
    //    f2 *= ff;

    //    Write4(i1,f1,i2,f2); 
    EOSTableDiffT eos1 = database.ReadEOSTable(i1);
    EOSTableDiffT eos2 = database.ReadEOSTable(i2);
    
    IdealMixture im(eos1,f1,eos2,f2);

    double rho0GCC;
    bool rho0Flag = ParseCommandLineArgumentNoSpace(arg,"rho0=",rho0GCC);
    if (rho0Flag) im.OverwriteHugoniotRho0GCC(rho0GCC);

    double E0;
    bool E0Flag = ParseCommandLineArgumentNoSpace(arg,"E0=",E0);
    if (E0Flag) im.OverwriteHugoniotE0(E0);

    if (!hugoniotCompressionMaximum) ProcessBinaryMixture(im,pythonCommand,openCommand);
    else DetermineHugoniotCompressionMaximumBinaryMixture(im);
    
    /*
    //    int nnn = 10;
    //    int nnn = 2;
    int nnn = 50;
    for(int iii=0; iii<=nnn; iii++) {
      double f1 = double(iii)/double(nnn);
      double f2 = 1.0-f1;
      IdealMixture im(eos1,f1,eos2,f2);
      DetermineHugoniotCompressionMaximumBinaryMixture(im);
      cout << endl << endl;
    }
    */

  } else {

    int i1    = 9-1; // Mg
    double f1 = 0.2;
    ExtractEOSName(database,arg,"EOS1=",i1,f1);

    int i2    = 11-1; // Si
    double f2 = 0.2;
    ExtractEOSName(database,arg,"EOS2=",i2,f2);

    int i3    = 6-1; // Ne
    double f3 = 1.0-f1-f2;
    ExtractEOSName(database,arg,"EOS3=",i3,f3);

    EOSTableDiffT eos1 = database.ReadEOSTable(i1);
    EOSTableDiffT eos2 = database.ReadEOSTable(i2);
    EOSTableDiffT eos3 = database.ReadEOSTable(i3);
    
    IdealMixture3 im(eos1,f1,eos2,f2,eos3,f3);

    double rho0GCC;
    bool rho0Flag = ParseCommandLineArgumentNoSpace(arg,"rho0=",rho0GCC);
    if (rho0Flag) im.OverwriteHugoniotRho0GCC(rho0GCC);

    double E0;
    bool E0Flag = ParseCommandLineArgumentNoSpace(arg,"E0=",E0);
    if (E0Flag) im.OverwriteHugoniotE0(E0);

    if (!hugoniotCompressionMaximum) ProcessTernaryMixture(im,pythonCommand,openCommand);
    else DetermineHugoniotCompressionMaximumTernaryMixture(im);

  }

  /////////////////////////////////////////////////////////////////////////////////

  CheckForUnusedCommandLineParameters(arg);

  cout << endl << "Program finished properly. The final result was 42, as expected." << endl;
  return 0;
}
