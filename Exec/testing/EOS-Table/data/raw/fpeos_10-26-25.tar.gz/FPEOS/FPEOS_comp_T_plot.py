from matplotlib.pyplot import *
import numpy
import sys
import os 

fig_size = [800/72.27 ,700/72.27]
params = {'backend': 'ps', 'axes.labelsize': 25, 'font.size': 25, 'legend.fontsize': 16,
          'xtick.labelsize': 25, 'ytick.labelsize': 25, 
          'xtick.major.size': 15,'ytick.major.size': 15,
          'xtick.minor.size': 8,'ytick.minor.size': 8,
          'text.usetex': False, 'figure.figsize': fig_size, 'xtick.major.pad': 9,
          'figure.subplot.top': 0.94,'figure.subplot.left': 0.105,'figure.subplot.bottom': 0.095,'figure.subplot.right': 0.978}
#'figure.subplot.bottom': 0.097

rcParams.update(params)
a=subplot(111)

title_ = "First-Principles Equation of State Database";
if (len(sys.argv)>1):
   title_ = str(sys.argv[1])
title(title_)

scriptName = sys.argv[0][:-3]; # [:3] removes ".py" for file name 
try:
   os.remove(scriptName+'.pdf')
   os.remove(scriptName+'.png')
except:
   pass

##############################################################################################################################

cx = 1
cy = 0

hug = numpy.loadtxt('FPEOS_Hugoniot.txt',usecols=(1,3,5,7,9,13)); # T,rho/rho0,rho0,rho,P,E
rho0 = hug[0,2]
#print(rho)
l = 9;
plot(hug[:,cx],hug[:,cy],'-', linewidth=l, markersize=0,color='r',mec='r',mew=2, mfc='white', dashes=(16/l,3/l,3/l,3/l), label='Hugoniot curve',zorder=20);

l = 8
hugRel = numpy.loadtxt('FPEOS_Hugoniot_rel.txt',usecols=(1,3,5,7,9,13)); # T,rho/rho0,rho0,rho,P,E
plot(hugRel[:,cx],hugRel[:,cy],'-', linewidth=l, markersize=0,color='k',mec='k',mew=2, mfc='white', dashes=(16/l,3/l,3/l,3/l),label='Hugoniot with\nrelativistic effects');

if os.path.isfile('FPEOS_Hugoniot_rad.txt'): # for hydrogen this file does not get written 
   l = 5
   hugRad = numpy.loadtxt('FPEOS_Hugoniot_rad.txt',usecols=(1,3,5,7,9,13)); # T,rho/rho0,rho0,rho,P,E
   plot(hugRad[:,cx],hugRad[:,cy],'-', linewidth=l, markersize=0,color='brown',mec='brown',mew=2, mfc='white', dashes=(16/l,3/l,3/l,3/l),label='Hugoniot with\nradiation effects');
   a.set_xlim(2.0,np.ceil(5.01*max(hugRad[:,cx]))/5 )
   #print(hug.shape,hugRad.shape)
   if (hug.shape==hugRad.shape):
       fill_betweenx(hugRad[:,cy], hug[:,cx],hugRad[:,cx],facecolor='r',color='r',alpha=0.1)
else:
   a.set_xlim(2.0,6.0)

l = 2
hugLower = numpy.loadtxt('FPEOS_Hugoniot_lower_initial_density.txt',usecols=(1,3,5,7,9,13)); # T,rho/rho0,rho0,rho,P,E
plot(hugLower[:,cx],hugLower[:,cy],'-', linewidth=l, markersize=0,color='darkgreen',mec='brown',mew=2, mfc='white',label='Hugoniot with\n'+r'20% lower $\rho_0$');

l = 2
hugHigher = numpy.loadtxt('FPEOS_Hugoniot_higher_initial_density.txt',usecols=(1,3,5,7,9,13)); # T,rho/rho0,rho0,rho,P,E
plot(hugHigher[:,cx],hugHigher[:,cy],'-', linewidth=l, markersize=0,color='navy',mec='brown',mew=2, mfc='white',dashes=(2/l,1/l),label='Hugoniot with\n'+r'20% higher $\rho_0$');

##############################################################################################################################

d  = numpy.loadtxt('FPEOS_isobars.txt',usecols=(1,3,7,9,11)); # index,rho,T,P,E
iMin = int(min(d[:,0]))
iMax = int(max(d[:,0]))
# print(iMin,iMax)

for i in range(iMin,iMax+1):
    ii = (d[:,0]==i)
    iii = np.where(ii==True)[0][0]

    label = ''
    if (i==iMin): label='Isobar'
    plot(d[ii,1]/rho0,d[ii,2],'s-', linewidth=1, markersize=0,color='k',mec='k',mfc='lightblue',mew=1, dashes=(12,2,2,2), label=label,zorder=-10);

##############################################################################################################################

d  = numpy.loadtxt('FPEOS_isochor_points.txt',usecols=(1,3,7,9,13)); # index,rho,T,P,E
plot(d[:,1]/rho0,d[:,2],'o-', linewidth=0, markersize=5,color='r',mec='darkgreen',mew=1, mfc='lightgreen',label='FPEOS point',zorder=-10);

#########################################################################################################################################

#xlabel(r'Pressure (GPa)')
#xlabel(r'Density (g$\,$cm$^{-3}$)')
xlabel(r'Compression ratio $\rho / \rho_0$')
ylabel(r'Temperature (K)')
#ylabel(r'Pressure (GPa)')

# print(min(hug[:,cy]))

#a.set_xscale('log')
a.set_ylim( 10.0**np.floor(np.log10(min(hug[:,cy]))) , 10.0**np.ceil(np.log10(max(hug[:,cy]))) )
#a.set_xlim( 2.0                                   , ceil(5.01*max(hugRad[:,cx]))/5 )
a.xaxis.set_minor_locator(MultipleLocator(0.2));
a.set_yscale('log')
a.xaxis.set_ticks_position('both')
a.get_xaxis().set_tick_params(which='both', direction='in')
a.yaxis.set_ticks_position('both')
a.get_yaxis().set_tick_params(which='both', direction='in')

legend(loc='upper left',frameon=True,framealpha=1.0,handlelength=3.5,ncol=1,handletextpad=0.4,numpoints=1)

savefig(scriptName+'.pdf', bbox_inches='tight')
savefig(scriptName+'.png', bbox_inches='tight', dpi=200)

