/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// Spline interpolation                                                    // 
//                                                                         //
// Burkhard Militzer                                  Livermore 4-27-01    //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////

#ifndef _SPLINE_
#define _SPLINE_

#include "Array.h"

class Spline {
 public:
  Spline():n(0){};
  Spline(const int m):n(0){ // just pre-allocate memory, do not fill in any elements yet
    x.Allocate(m);
    y.Allocate(m);
    y2.Allocate(m);
  };
  Spline(const Array1 <double> & xx, const Array1 <double> & yy):n(0) {
    PushBack(xx,yy);
    Init();
  }

  static void CalculateY2(Array1 <double> & x,
			  Array1 <double> & y, 
			  const int n,
			  Array1 <double> & y2,
			  const bool natural=true, 
			  const double ypLow=0.0, 
			  const double ypHigh=0.0);
  void CalculateY2(const bool natural=true, 
		   const double ypLow=0.0, 
		   const double ypHigh=0.0) {
    CalculateY2(x,y,n,y2,natural,ypLow,ypHigh);
  }
  
  void Init(const bool natural=true, 
	    const double ypLow=0.0, 
	    const double ypHigh=0.0) {
    CalculateY2(x,y,n,y2,natural,ypLow,ypHigh);
  }
  
  // use finite difference to specify dy/dx at the boundaries
  void InitUsingFiniteDifferences() {
    if (n<=2) error("Spline:InitUsingFiniteDifferences is called with two few data points",n);
    Sort(x,y,n);
    MonotonicX(true);
    double ypLow =(y[1]-y[0])    /(x[1]-x[0]);
    double ypHigh=(y[n-1]-y[n-2])/(x[n-1]-x[n-2]);
    Init(false,ypLow,ypHigh);
  }

  void Sort() {
     Sort(x,y,n);
  }   

  static void Sort(Array1 <double> & x,
		   Array1 <double> & y, 
		   const int n);

  void Reset() {
    n=0;
    x.Resize(0);
    y.Resize(0);
  }

  void PushBack(const double xx, const double yy) {
    n++;
    x.PushBack(xx);
    y.PushBack(yy);
  }

  void PushBack(const Array1 <double> & xx, const Array1 <double> & yy) {
    if (xx.Size()!=yy.Size()) 
      error("Array size error ",xx.Size(),yy.Size());
    for(int i=0; i<xx.Size(); i++) {
      PushBack(xx[i],yy[i]);
    }
  }

  static double Interpolate(const Array1 <double> & x,
			    const Array1 <double> & y, 
			    const int n, 
			    const Array1 <double> & y2,
			    const double xx);
  static double Derivative(const Array1 <double> & x,
			   const Array1 <double> & y, 
			   const int n, 
			   const Array1 <double> & y2,
			   const double xx);
  static double SecondDerivative(const Array1 <double> & x,
				 const Array1 <double> & y, 
				 const int n, 
				 const Array1 <double> & y2,
				 const double xx);
  static double InterpolateLinearly(const Array1 <double> & x,
				    const Array1 <double> & y, 
				    const int n, 
				    const double xx);
  
  double Interpolate(const double xx) const {
    return Interpolate(x,y,n,y2,xx);
  }
  double Derivative(const double xx) const {
    return Derivative(x,y,n,y2,xx);
  }
  double SecondDerivative(const double xx) const {
    return SecondDerivative(x,y,n,y2,xx);
  }
  double InterpolateLinearly(const double xx) const {
    return InterpolateLinearly(x,y,n,xx);
  }

  double f(const double xx) const {
    return Interpolate(xx);
  }

  double operator()(const double xx) const {
    return Interpolate(xx);
  }

  double FirstX() const {
    return x[0];
  }

  double LastX() const {
    return x[x.Size()-1];
  }

  double FirstY() const {
    return y[0];
  }

  double LastY() const {
    return y[y.Size()-1];
  }

  int GetNumber() const {
    return x.Size();
  }

  int Size() const {
    return GetNumber();
  }

  void Print(const bool der=false) const {
    for(int i=0; i<GetNumber(); i++) {
      cout << "spline_points:";
      write3(i,x[i],y[i]);
      //      if (der) cout << "dy/dx= " << DerivativeAtPoint(i); // index out of range at last point
      if (der) cout << " dy/dx= " << Derivative(x[i]);
      cout << endl;
    }
  }

  void PrintInterpolation(int n=-1) const {
    if (n<=0) n = 5*GetNumber();
    double x1 = FirstX();
    double x2 = LastX();
    for(int i=0; i<=n; i++) {
      double xx = x1+(x2-x1)*double(i)/double(n);
      double yy = Interpolate(xx);
      double yyp = Derivative(xx);
      double yypp = SecondDerivative(xx);
      cout << "spline x= " << xx << " y= " << yy << " y'= " << yyp << " y''= " << yypp << endl;
    }
  }

  // approach x[k1] from right x[k1]+eps but be careful: only good for k1<n-1
  double DerivativeAtPointFromRight(const int k1) const { 
    int k2=k1+1;
    double h=x[k2]-x[k1];
    //  double a=(x[k2]-xx)/h;  --> xx=x[k1] --> a=1
    //  double b=1.0-a;                      --> b=0
    double dfdx = (y[k2]-y[k1])/h - h/6.0 * ( 2.0*y2[k1] + y2[k2] );
    return dfdx;
  }
  // approach x[k2] from left x[k2]-eps but be careful: only good for k2>=1
  double DerivativeAtPointFromLeft(const int k2) const { 
    int k1=k2-1;
    double h=x[k2]-x[k1];
    //  double a=(x[k2]-xx)/h;  --> xx=x[k2] --> a=0
    //  double b=1.0-a;                      --> b=1
    double dfdx = (y[k2]-y[k1])/h + h/6.0 * ( y2[k1] + 2.0*y2[k2] );
    return dfdx;
  }
  double DerivativeAtPoint(const int k) const { 
    //    if (k>0 && k<GetNumber()-1) Write3(k,DerivativeAtPointFromLeft(k),DerivativeAtPointFromRight(k));
    return (k>0) ? DerivativeAtPointFromLeft(k) : DerivativeAtPointFromRight(k);
  }

  bool MonotonicX(const bool printAndStop) {
    for(int i=0; i<GetNumber()-1; i++) {
      if (x[i+1]<=x[i]) {
	if (printAndStop) {
	  error("Spline not monotonic, may have repeated entries",i,x[i],x[i+1]);
	} else {
	  return false;
	}
      }
    }
    return true;
  }

  bool Monotonic(const int nNotCheck=0, const bool print=false) { // must have been initialized
    bool monotonic=true;
    for(int i=nNotCheck; i<GetNumber()-1-nNotCheck; i++) {
      if (sign(DerivativeAtPoint(i))*sign(DerivativeAtPoint(i+1))<0.0) { // either one equal zero woud be ok
	if (!print) return false;
	cout << "Spline not monotonic: "; Write8(i,n,x[i],x[i+1],y[i],y[i+1],DerivativeAtPoint(i),DerivativeAtPoint(i+1));
	PrintInterpolation();
	Print();
	monotonic=false;
      }
    }
    return monotonic;
  }
  
  static double IntegralTerm1(const double x1, const double x2, const double xx);
  static double IntegralTerm2(const double x1, const double x2, const double xx);
  static double IntegralTerm3(const double x1, const double x2, const double xx);
  static double IntegralTerm4(const double x1, const double x2, const double xx);
  static double IntegralInterval1(const double x1, const double x2, const double xx, const double y1, const double y2, const double ys1, const double ys2);
  static double IntegralFullInterval(const double h, const double y1, const double y2, const double ys1, const double ys2);
  static double IntegralInterval2(const double x1, const double x2, const double xx, const double y1, const double y2, const double ys1, const double ys2);

  static double Integrate(const Array1 <double> & x,
			  const Array1 <double> & y, 
			  const int n, 
			  const Array1 <double> & y2,
			  const double xx1, 
			  const double xx2);
  double Integrate(const double xx1, const double xx2) const {
    return Integrate(x,y,n,y2,xx1,xx2);
  }

  bool Inside(const double x) const {
    return (x>=FirstX() && x<=LastX());
  }

  // protected:

  static int GetIndex(const Array1 <double> & x, const int n, const double xx);
 
  bool operator==(const Spline & s) const {
    return ((n==s.n) && (x==s.x) && (y==s.y) && (y2==s.y2));
  }
  bool operator!=(const Spline & s) const {
    return !(*this==s);
  }

  int n;
  Array1 <double> x;
  Array1 <double> y;
  Array1 <double> y2;
  static Array1 <double> u;

};

#endif // _SPLINE_
