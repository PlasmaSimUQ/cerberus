//////////////////////////////////////////////////////////////////////////////
//                                                                          //
// Runge Kutta algorithm                                                    //
//                                                                          //
// Burkhard Militzer                                  Livermore 9-26-00     //
//                                                    Washington 11-25-05   //
//                                                                          //
//////////////////////////////////////////////////////////////////////////////

#ifndef _RUNGEKUTTA_
#define _RUNGEKUTTA_

#include "Array.h"

class RungeKuttaParameter {
 public:
  static const double tiny;
  static const int stepDivMax;

  static const double alpha[2];
  static const double beta2[1];
  static const double beta3[2];
  static const double beta4[3];
  static const double Gamma[3];
  static const double c[4];
};

template <class T>
class RungeKutta : public RungeKuttaParameter {
 public:
  friend ostream& operator<<(ostream &os, const RungeKutta<T> & rk ) {
    os << " Number of function calls: " << rk.nFunctionCalls << endl;
    os << " Number of computed steps: " << rk.nSteps << endl;
    os << " Number of accepted steps: " << rk.nAccept << endl;
    os << " Number of rejected steps: " << rk.nReject << endl;
    return os;
  }
  // Had difficulties to write function output and diffy that woprk on const Array1's -> leave this out
  void Solve(const double x0, const double xe, const double hInitial, const double hMax, const double localError, T & t);
  
 private:
  
  int nFunctionCalls, nSteps, nAccept, nReject;
  
  Array1 <double> arg, k1, k2, k3, k4;
  Array1 <double> yNew,dydx,dydxNew;
  
  double OneStep(const double x,
		 const double h,
		 const Array1 <double> & y,
		 const Array1 <double> & diffy_dx,
		 const T & t,
		 Array1 <double> & yNew,
		 Array1 <double> & diffy_dxnew) ;
};

template <class T> 
double RungeKutta<T>::OneStep(const double x,
			    const double h,
			    const Array1 <double> & y,
			    const Array1 <double> & diffy_dx,
			    const T & t,
			    Array1 <double> & yNew,
			    Array1 <double> & diffy_dxnew) {
  double tmp= beta2[0]*h;
  for(int i=0; i<t.n; i++)
    arg[i]= y[i]+tmp*(k1[i]= diffy_dx[i]);

  t.Diff(x+tmp,arg,k2);

  for(int i=0; i<t.n; i++)
    arg[i]= y[i]+h*(beta3[0]*k1[i]+beta3[1]*k2[i]);

  t.Diff(x+alpha[1]*h,arg,k3);

  for(int i=0; i<t.n; i++)
    arg[i]= y[i]+h*(beta4[0]*k1[i]+beta4[1]*k2[i]+beta4[2]*k3[i]);

  t.Diff(x+h,arg,k4);

  double err=0.0;
  for(int i= 0; i<t.n; i++){
    yNew[i]= y[i]+h*(Gamma[0]*k1[i]+Gamma[1]*k2[i]+Gamma[2]*k3[i]);
    err += fabs(c[0]*k1[i]+c[1]*k2[i]+c[2]*k3[i]+c[3]*k4[i]);
    diffy_dxnew[i]= k4[i];
  }
  err *= fabs(h); // 'err' must stay positive, even if h<0 from xe<x0

/* Find the biggest error contribution */
   /*
   errmax = 0.0;
   imax = -1;
 
   for((*err)= 0.0,i= 1;i<=n;i++){
       ynew[i]= y[i]+h*(Gamma[0]*k1[i]+Gamma[1]*k2[i]+Gamma[2]*k3[i]);
       erri= fabs(h*(c[0]*k1[i]+c[1]*k2[i]+c[2]*k3[i]+c[3]*k4[i]));
       (*err)+= erri;
       if (errmax<erri) {
	   errmax=erri;
	   imax = i;
       }
       diffy_dxnew[i]= k4[i];
   }
   if ((*err)>errlimit) {
      printf("XXXXXXXXX x=%lf h=%lf Max. Error at i=%d %d e=%e e_sum=%e > emax=%e\n",
	     x,h,imax,imax % 14,errmax,(*err),errlimit);
   } 
   */
   nFunctionCalls += 3;

   return err;
}

// Had difficulties to write function output and diffy that works for const Array1's -> leave this out
template <class T> 
void RungeKutta<T>::Solve(const double x0, const double xe, const double hInitial, const double hMax, const double localError, T & t) {
  //  Write4(x0,xe,hInitial,n);

  double errorLow= localError/64.0;
  int stepDiv= 0;
  
  double h = hInitial;
  if ((xe-x0)*h<0.0) {
    error("Step size has wrong sign",x0,xe,h);
    //    return;
  }

  const double deltaX = fabs(xe-x0);
  nFunctionCalls= nSteps= nAccept= nReject= 0;
  
  Array1 <double> y = t.GetInitialConditions(x0);
  arg.Resize(t.n);
  k1.Resize(t.n);
  k2.Resize(t.n);
  k3.Resize(t.n);
  k4.Resize(t.n);
  yNew.Resize(t.n);
  dydx.Resize(t.n);
  dydxNew.Resize(t.n);
  
  double hNew = h;
  double x    = x0;
  t.Diff(x,y,dydx); 
  nFunctionCalls++;
  t.OutPut(nFunctionCalls,x,0.0,y,dydx);
  
  bool stepHalved;
  do {
    stepHalved= false;
    for (;;) {
      h= hNew;
      if (fabs(x+h-x0)>deltaX) {
	h = xe-x;
	stepHalved = true;
      }
      nSteps++;
      
      double errorSum = OneStep(x,h,y,dydx,t,yNew,dydxNew);

      bool succ;
      if (errorSum>localError) {
	hNew = 0.5*h;
	stepDiv++;
	succ = false;
	nReject++;
	stepHalved = true;
	//	Write3(hNew,h,x);
      } else if (errorSum<errorLow && !stepHalved) {
	hNew = 2.0*h;
	if (hMax>0.0 && fabs(hNew)>hMax) hNew=sign(hNew)*hMax; // hMax==0.0 means there is no maximum step size
	//	Write4(hNew,h,hMax,x);
	stepDiv--;
	succ = true;
      } else{
	succ = true;
	hNew = h;
      }
      if (stepDiv>stepDivMax) {
	//	error("Critical error in RKSecondOrder: Step size more than",stepDivMax,"times divided.");
	warning("Critical error in RKSecondOrder: Step size more than",stepDivMax,"times divided.");
	return;
      }

      if (succ) break;
    }
    
    nAccept++;
    x += h;
    if (fabs(h)>tiny) { // prevents calling OutPut twice at the end
      if (t.OutPut(nFunctionCalls,x,h,yNew,dydxNew)) {
	cout << "Runge Kutta procedure terminated by output() at x= " << x << endl;
	return;
      }
    }
    
    for(int i=0; i<t.n; i++) {
      y[i]   = yNew[i];
      dydx[i]= dydxNew[i];
    }
    
  } while (fabs(x-x0)<=deltaX && fabs(h)>tiny);
  
  //  Write4(x0,x,xe,h);
  if (fabs(x-x0)<deltaX-tiny) 
    //    error("RungeKutta did not integrate till the end, step size went to zero",x0,x,xe,fabs(x-x0)-deltaX,h);
    warning("RungeKutta did not integrate till the end, step size went to zero",x0,x,xe,fabs(x-x0)-deltaX,h);

}

#endif // _RUNGEKUTTA_
