/////////////////////////////////////////////////////////////////////////////
//                                                                         //
//  1D search routines for roots of equation                               //
//  uses templates                                                         //
//                                                                         //
//  B. Militzer                                     Livermore 09-03-01     //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////

#ifndef _FINDROOT_
#define _FINDROOT_

#include "Standard.h"

template <class T>
double FindRootBisection(const double x1, 
			 const double x2, 
			 const double tolX,
			 T & f, const string name="") {
  if (tolX<0.0)
    error("The accuracy parameter must be positive",name,tolX);
  
  double f1=sign(f(x1));
  double f2=sign(f(x2));
  
  if (f1==f2)
    error("FindRootBisection: same sign at both interval boundaries",x1,x2,f1,f2);
  
  const double acc=fabs(x2-x1)*tolX;
  double xx1=x1;
  double xx2=x2;
  double xx;
  do {

    xx=(xx2+xx1)*0.5;
    double ff=sign(f(xx));

    if (ff==f1) xx1=xx;
    else xx2=xx;

    //    Write3(xx1,xx2,fabs(xx2-xx1)/acc);

  } while (fabs(xx2-xx1)>acc);
  return xx;
}

template <class T>
double FindRootRegulaFalsi(const double x1, 
			   const double x2, 
			   const double tolX,
			   const T & f) {
  if (tolX<0.0)
    error("The accuracy parameter must be positive",tolX);

  double f1=f(x1);
  double f2=f(x2);
  
  const double acc=fabs(x2-x1)*tolX;

  double xx1=x1;
  double xx2=x2;
  double xx;
  do {
    xx=(f1*xx2-f2*xx1)/(f1-f2);
    double ff=f(xx);
    xx1=xx2; f1=f2;
    xx2=xx;  f2=ff;
  } while (fabs(xx2-xx1)>acc);
  return xx;
}

// initial f1 and f2 are known - do not call f(x1) and f(x2)
// good for expensive f() functions
template <class T>
double FindRootRegulaFalsiSafely(const double x1, 
				 const double x2, 
				 double f1, 
				 double f2, 
				 const double relTolX,
				 T & f, const string name="", const bool print=false) {
  if (relTolX<0.0)
    error("The accuracy parameter must be positive",relTolX);

  int n=2;

  if (sign(f1)==sign(f2)) {
    cout << "FindRootRegulaFalsiSafely: " << name << endl;
    error("FindRootRegulaFalsiSafely: same sign at both interval boundaries",name,x1,x2,f1,f2);
  }

  const double acc=fabs(x2-x1)*relTolX;

  double xx1=x1;
  double xx2=x2;
  double xx;

  int nOneSideMax = 5;
  int nSide       = 0;
  do {
    if (abs(nSide)<nOneSideMax) { 
      xx=(f1*xx2-f2*xx1)/(f1-f2); // regular regular falsi
    } else {                      // do bisection step if things get too lop-sided
      xx=(xx1+xx2)/2.0;           // bisection step
      nSide = 0;
    }

    double ff=f(xx);
    n++;
    if (ff==0.0) return xx; // not sure if this will avoid getting stuck in all cases
    //    Write6(xx1,xx,xx2,f1,ff,f2);
    if (sign(ff)==sign(f1)) { // make sure that f1 and f2 keep having opposite signs
      f1  = ff;
      xx1 = xx;
      nSide--;
    } else {
      f2  = ff;
      xx2 = xx;
      nSide++;
    }
    if (print) { 
      bool flag = (fabs(xx2-xx1)<acc);
      cout << name; Write8(n,xx1,xx2,fabs(xx2-xx1),acc,flag,f1,f2); 
    }
  } while (fabs(xx2-xx1)>acc);
  return xx;
}

template <class T>
double FindRootRegulaFalsiSafely(const double x1, 
				 const double x2, 
				 const double relTolX,
				 T & f, const string name="", const bool print=false) {
  double f1=f(x1);
  double f2=f(x2);
  return FindRootRegulaFalsiSafely(x1,x2,f1,f2,relTolX,f,name,print);
}

/////////////////////////////////////////////////////////////////////////////////////////////

class FindRootProblem {
 public:
  string s;
  double x1,x2,f1,f2;
  FindRootProblem(string & s_,double x1_, double x2_, double f1_, double f2_)
    :s(s_),x1(x1_),x2(x2_),f1(f1_),f2(f2_){}

  friend ostream& operator<<(ostream & os, const FindRootProblem & frp) {
    os << frp.s;
    os << " x1= " << frp.x1;
    os << " x2= " << frp.x2;
    os << " f(x1)= " << frp.f1;
    os << " f(x2)= " << frp.f2;
    return os;
  }
};

template <class T>
double FindRootRegulaFalsiThrow(const double x1, 
				const double x2, 
				double f1, 
				double f2, 
				const double relTolX,
				T & f, const string name="", const bool print=false) {
  if (relTolX<0.0)
    error("The accuracy parameter must be positive",relTolX);

  int n=2;

  if (sign(f1)==sign(f2)) {
    //    cout << "FindRootRegulaFalsiSafely: " << name << endl;
    //    error("FindRootRegulaFalsiSafely: same sign at both interval boundaries",name,x1,x2,f(x1),f(x2));
    string s = "FindRootRegulaFalsiSafely: same sign at both interval boundaries for \""+name+"\"";
    s += " x1= "+DoubleToString(x1);
    s += " x2= "+DoubleToString(x2);
    s += " f(x1)= "+DoubleToString(f1);
    s += " f(x2)= "+DoubleToString(f2);
    cout << s << endl;
    cout.flush();
    FindRootProblem frp(s,x1,x2,f1,f2);
    //    throw(s.c_str());
    throw(frp);
  }

  const double acc=fabs(x2-x1)*relTolX;

  double xx1=x1;
  double xx2=x2;
  double xx;

  int nOneSideMax = 5;
  int nSide       = 0;
  do {
    if (abs(nSide)<nOneSideMax) { 
      xx=(f1*xx2-f2*xx1)/(f1-f2); // regular regular falsi
    } else {                      // do bisection step if things get too lop-sided
      xx=(xx1+xx2)/2.0;           // bisection step
      nSide = 0;
    }

    double ff=f(xx);
    n++;
    if (ff==0.0) return xx; // not sure if this will avoid getting stuck in all cases
    if (print) { cout << name; Write6(xx1,xx,xx2,f1,ff,f2); }
    if (sign(ff)==sign(f1)) { // make sure that f1 and f2 keep having opposite signs
      f1  = ff;
      xx1 = xx;
      nSide--;
    } else {
      f2  = ff;
      xx2 = xx;
      nSide++;
    }
    if (print) { 
      bool flag = (fabs(xx2-xx1)<acc);
      cout << name; Write8(n,xx1,xx2,fabs(xx2-xx1),acc,flag,f1,f2); 
    }
  } while (fabs(xx2-xx1)>acc);
  return xx;
}

template <class T>
double FindRootRegulaFalsiThrow(const double x1, 
				const double x2, 
				const double relTolX,
				T & f, const string name="", const bool print=false) {
  double f1=f(x1);
  double f2=f(x2);
  return FindRootRegulaFalsiThrow(x1,x2,f1,f2,relTolX,f,name,print);
}
////////////////////////////////////////////////////////////////////////////////////////////

template <class T>
double FindRootStepper(const double x1, 
		       const double x2, 
		       const double tolX,
		       const double tolF,
		       const T & f) {
  if (tolX<0.0)
    error("The accuracy parameter must be positive",tolX);
  if (tolF<0.0)
    error("The accuracy parameter must be positive",tolF);

  const double r=0.2;
  double f1=f(x1);
  double f2=f(x2);

  if (sign(f1)!=sign(f2)) 
    return FindRootBisection(x1,x2,tolX,f);

  double xx,dx,ff;
  if (fabs(f1)<fabs(f2)) {
    xx=x1;
    dx=(x2-x1)*r;
    ff=f1;
  } else {
    xx=x2;
    dx=(x1-x2)*r;
    ff=f2;
  }

  for(;;) {
    const double xxn=xx+dx;
    const double ffn=f(xxn);
    //    Write5(xx,xxn,dx,ff,ffn);

    if (sign(ffn)!=sign(ff))
      return FindRootBisection(xx,xxn,tolX,f);

    if (sign(ffn)!=sign(ff) || fabs(ffn)>fabs(ff)) {
      //      Write2(int(sign(ffn)!=(ff)),int(fabs(ffn)>fabs(ff)));
      dx *= -r;
      if (fabs(dx)<tolX && fabs(ffn)<tolF) {
	return (xxn+xx)*0.5;
      }

      const double overrun=1e-8;
      if (fabs(dx)<tolX*overrun) 
	error("FindRootStepper: Could not find root (dx got too small)",dx,ffn);
    }
    xx=xxn;
    ff=ffn;
  }
  return 0.0;
}

template <class T>
double FindRootStepper(const double x, 
		       const double tolX,
		       const double tolF,
		       const T & f) {
  const double r=0.1;
  return FindRootStepper( (1.0-r)*x, (1.0+r)*x, tolX, tolF, f );
}

template <class T>
double FindRootStepper(const double x1, 
		       const double x2, 
		       const double tolX,
		       const double tolF,
		       T & f, const string name="") {
  if (tolX<0.0)
    error("The accuracy parameter must be positive",tolX);
  if (tolF<0.0)
    error("The accuracy parameter must be positive",tolF);

  const double r=0.2;
  double f1=f(x1);
  double f2=f(x2);

  if (sign(f1)!=sign(f2)) 
    return FindRootBisection(x1,x2,tolX,f,name);

  double xx,dx,ff;
  if (fabs(f1)<fabs(f2)) {
    xx=x1;
    dx=(x2-x1)*r;
    ff=f1;
  } else {
    xx=x2;
    dx=(x1-x2)*r;
    ff=f2;
  }

  for(;;) {
    const double xxn=xx+dx;
    const double ffn=f(xxn);
    //    Write5(xx,xxn,dx,ff,ffn);

    if (sign(ffn)!=sign(ff))
      return FindRootBisection(xx,xxn,tolX,f,name);

    if (sign(ffn)!=sign(ff) || fabs(ffn)>fabs(ff)) {
      //      Write2(int(sign(ffn)!=(ff)),int(fabs(ffn)>fabs(ff)));
      dx *= -r;
      if (fabs(dx)<tolX && fabs(ffn)<tolF) {
	return (xxn+xx)*0.5;
      }

      const double overrun=1e-8;
     if (fabs(dx)<tolX*overrun) 
	error("FindRootStepper: Could not find root (dx got too small)",dx,ffn);
    }
    xx=xxn;
    ff=ffn;
  }
  return 0.0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template <class T>
double FindRootStepperThenRegulaFalsi(const double x1, 
				      const double x2, 
				      const double relTolX,
				      const double tolF,
				      const T & f, const string name="", const bool print=false) {
  if (relTolX<0.0) error("The accuracy parameter must be positive",relTolX);

  const double r=0.2;
  double f1=f(x1);
  double f2=f(x2);

  if (sign(f1)!=sign(f2)) return FindRootRegulaFalsiSafely(x1,x2,f1,f2,relTolX,f,name,print);

  double xx,dx,ff;
  if (fabs(f1)<fabs(f2)) {
    xx=x1;
    dx=(x2-x1)*r;
    ff=f1;
  } else {
    xx=x2;
    dx=(x1-x2)*r;
    ff=f2;
  }

  for(;;) {
    const double xxn=xx+dx; 
    //    Write3(xx,xxn,dx);
    const double ffn=f(xxn);
    //    Write5(xx,xxn,dx,ff,ffn);

    if (sign(ffn)!=sign(ff)) return FindRootRegulaFalsiSafely(xx,xxn,ff,ffn,relTolX,f,name,print);

    if (fabs(ffn)>fabs(ff)) {
      dx *= -r; // shall we go the other way?
      if (fabs(dx)<xx*relTolX && fabs(ffn)<tolF) {
	return (xxn+xx)*0.5;
      }

      const double overrun=1e-8;
      if (fabs(dx)<xx*relTolX*overrun) 
	error("FindRootStepper: Could not find root (dx got too small)",dx,ffn);
    }
    xx=xxn;
    ff=ffn;
  }
  return 0.0;
}

template <class T>
double FindRootStepperThenRegulaFalsi(const double x, 
				      const double relTolX,
				      const double tolF,
				      const T & f, const string name="", const bool print=false) {
  const double r = 0.1;
  return FindRootStepperThenRegulaFalsi(x*(1.0-r),x*(1.0+r),relTolX,tolF,f,name,print);
}

////////////////////////////////////////////////////////////////////////////////////////////

// use bisection directly if possible
// survey the provided interval and then use bisection
// then look outside the provided interval
template <class T>
double FindRootBrancher(const double x1, 
			const double x2, 
			const double tolX,
			const double tolF,
			const T & f) {
  if (tolX<0.0)
    error("The accuracy parameter must be positive",tolX);
  if (tolF<0.0)
    error("The accuracy parameter must be positive",tolF);

  double f1=f(x1);
  double f2=f(x2);

  if (sign(f1)!=sign(f2)) 
    return FindRootBisection(x1,x2,tolX,f);

  // are there any solution inside the interval?
  const int nn=10;
  for(int i=1; i<nn; i++) {
    double xx = x1+(x2-x1)*i/nn;
    double ff = f(xx);
    if (sign(ff)!=sign(f1)) {
      if (i<=nn/2) return FindRootBisection(x1,xx,tolX,f);
      else return FindRootBisection(xx,x2,tolX,f);
    }
  }

  // now look outside
  const int nTrials=100;
  double xx1=x1;
  double xx2=x2;
  for(int i=0; i<nTrials; i++) {
    xx1 /= (1.0+1.0/nn);
    xx2 *= (1.0+1.0/nn);
    double ff1 = f(xx1);
    double ff2 = f(xx2);
    if (sign(f1)!=sign(ff1)) return FindRootBisection(x1,xx1,tolX,f);
    if (sign(f2)!=sign(ff2)) return FindRootBisection(x2,xx2,tolX,f);
  }

  error("Could not find any root in and outside of interval",x1,x2,xx1,xx2);
  return 0.0;
}

template <class T>
double FindRootBrancher(const double x, 
			const double tolX,
			const double tolF,
			const T & f) {
  const double r=0.1;
  return FindRootBrancher( (1.0-r)*x, (1.0+r)*x, tolX, tolF, f );
}

///////////////////////////////////////////////////////////////////////////////////

template <class T> 
class EqualsConstant {
 public:
  EqualsConstant(const T & t_, const double fTarget_):t(t_),fTarget(fTarget_){};
  const T & t;
  const double fTarget;
  double operator()(const double x) const {
    return t(x)-fTarget;
  }
};

template <class T>
double FindRootBisection(const double x1, 
			 const double x2, 
			 const double tolX,
			 const double fTarget,
			 T & f) {
  EqualsConstant <T> ec(f,fTarget);
  return FindRootBisection(x1,x2,tolX,ec);
}

template <class T>
double FindRootRegulaFalsi(const double x1, 
			   const double x2, 
			   const double tolX,
			   const double fTarget,
			   T & f) {
  EqualsConstant <T> ec(f,fTarget);
  return FindRootRegulaFalsi(x1,x2,tolX,ec);
}

template <class T>
double FindRootStepper(const double x1, 
		       const double x2, 
		       const double tolX,
		       const double tolF,
		       const double fTarget,
		       T & f) {
  EqualsConstant <T> ec(f,fTarget);
  return FindRootStepper(x1,x2,tolX,tolF,ec);
}

/*
template <class T>
double FindRootStepper(const double x, 
		       const double tolX,
		       const double tolF,
		       const double fTarget,
		       const T & f) {
  EqualsConstant <T> ec(f,fTarget);
  return FindRootStepper(x,tolX,tolF,ec);
}
*/

template <class T>
double FindRootBrancher(const double x1, 
			const double x2, 
			const double tolX,
			const double tolF,
			const double fTarget,
			T & f) {
  EqualsConstant <T> ec(f,fTarget);
  return FindRootBrancher(x1,x2,tolX,tolF,ec);
}

#endif // _FINDROOT_
