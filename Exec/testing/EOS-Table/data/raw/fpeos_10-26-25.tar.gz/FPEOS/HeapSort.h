//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
// Heap Sort                                                                    //
//                                                                              //
// The first version does not work                                              //
// The one below does                                                           //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

/*
template <class T> 
inline void Swap(T & a, T & b) {
  const T t=a; 
  a=b;
  b=t;
}


template <class T> 
void ShiftDown(vector<T> & v, const int l, const int r) {
  T a = v[l];
  int jOld = l;
  int j    = l+1;

  while (j<=r) {
    
    if (j < r && v[j] < v[j+1]) j++;
    if (a >= v[j]) break;
    v[jOld] = v[j];
    jOld = j;
    j = 2*j+1;

  }
  v[jOld] = a;
}

template <class T> 
void HeapSort(vector<T> & v) {

  int n=v.size();

  for(int i=n/2-1; i>=0; i--) {
    ShiftDown(v,i,n-1);
  }  

  for(int i=n-1; i>0; i--) {
    Swap(v[0],v[i]);
    ShiftDown(v,0,i-1);
  }
}
*/

template <class T> 
void HeapSort(Array1 <T> & v) {

  const int n=v.Size();
  if (n < 2) return;

  T a;
  int l=(n >> 1);
  int ir=n-1;

  for (;;) {

    if (l > 0) {
      a=v[--l];
    } else {
      a=v[ir];
      v[ir]=v[0];
      if (--ir == 0) {
	v[0]=a;
	break;
      }
    }

    int i=l;
    int j=2*l+1;
    while (j <= ir) {
      if (j < ir && v[j] < v[j+1]) j++;
      if (a < v[j]) {
	v[i]= v[j];
	i   = j;
	j   = 2*j+1;
      } else j=ir+1;
    }
    v[i]=a;

  }

}
