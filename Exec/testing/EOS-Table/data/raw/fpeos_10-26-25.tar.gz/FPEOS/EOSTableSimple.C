/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// EOS table class                                                         // 
// assume EOS is given on a density grid but the temperatures vary with rho//
//                                                                         //
// Burkhard Militzer                                  Livermore 2-26-03    //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////

#include "EOSTableSimple.h"
#include "ReadInTable.h"
#include "Physics.h"
#include "Spline.h"
#include "Form.h"
#include "Random.h"
#include "OrderedArray.h"
#include "FindRoot.h"

#define NO_WARNINGS

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int EOSTableDiffT::NumberOfDecimals(const Array1 <double> & nn) const {
  int nMax = 3;
  for(int j=0; j<=nMax; j++) {
    double f = pow(10.0,double(j));
    bool intFlag = true;
    for(int i=0; i<nn.Size(); i++) {
      double nf = nn[i]*f;
      if ( fabs(nf-int(nf))>1e-8 ) intFlag = false;
    }
    if (intFlag) return j;
  }
  return nMax;
}

void EOSTableDiffT::ReadTableInStandardFormat(const string & fileName, const double nFU, const double mFU) {
  SetMassFormulaUnit(mFU);
  SetNAtomsFormulaUnit(nFU);
  PrintFileOpeningStatement(fileName);

  Array1 <double> nAtoms;
  ReadInTable(fileName,4,8,10,12,13,15,16, n, nAtoms,nn,T,pp,pE,ee,eE);
  SetName(fileName);

  PutIn1DArrays(nn,T,tnn,lists);
  PrintFileClosingStatement(fileName);
  errorBars =true;
  errorBarsT=false;
  //  Quit("XXX");

  // nAtoms has number of atoms
  // nn     has volume of the cell
  
  int gi = 1+int(ceil(log10(double(n+1))));
  int gn = 1+int(ceil(log10(double(nAtoms.Max()))));
  int gnd = NumberOfDecimals(nAtoms);
  int gT = 1+int(ceil(log10(T.Max())));
  int dV = 3;
  int gV = dV+2+int(ceil(log10(nn.Max())));
  for(int i=0; i<n; i++) {
    cout << gen(gi,i+1) << " ";
    cout << "N/FU= " << fix(gn,gnd,nAtoms[i]);
    cout << " V[A^3/FU]= " << fix(gV,dV,nn[i]);
    cout << " T[K]= " << fix(gT,0,T[i]);
    cout << " P[GPa]= " << fix(13,3,pp[i]);
    if (pE[i]>0) cout << " +- " << fix(8,3,pE[i]);
    cout << " E[Ha/FU]= " << fix(18,8,ee[i]);
    if (eE[i]>0) cout << " +- " << fix(17,8,eE[i]);
    //    cout << " F[Ha/FU]= " << fix(14,8,ff[i]);
    //    cout << " +- " << fix(11,8,fE[i]);
    cout << endl;

    T[i]  *= PC::KToAU;
    pp[i] *= PC::GPaToAU;
    pE[i] *= PC::GPaToAU;

    if (nAtoms[i]<=0.0) error("Wrong number of atoms (check column index)",nAtoms[i],i);
    double f = nFU/nAtoms[i];
    ee[i] *= f;
    eE[i] *= f;
    //    ff[i] *= f;
    //    fE[i] *= f;

    // F=E-TS TS=E-F S=(E-F)/T
    //    ss[i] = (ee[i]-ff[i])/T[i]; // entropy in kb per FU
    //    sE[i] = (eE[i]+fE[i])/T[i]; // entropy in kb per FU

    if (nn[i] <= 0.0) error("Wrong cell volume",nn[i],i);
    double VCellAU = nn[i]*PC::A3ToAU;
    double VFUAU   = VCellAU*f;
    nn[i] = 1.0/VFUAU; // density of formula units in a0^3
    //    Write(nn[i]);
  }

  SetName(fileName);
  PutIn1DArrays(nn,T,tnn,lists);
  Print();
  //  PrintAllPoints();
  //  Quit("DDD");
  //  cout << " Finished ReadTableInStandardFormat()" << endl; cout.flush();
}

void EOSTableDiffT::PrintFileStatement(const string & filename, const bool open) const {
  int L = 120;
  int n1 = max(1,(L-filename.length()-6)/2);
  int n2 = max(1, L-filename.length()-6-n1);
  cout << ((open) ? "/" : "\\");
  cout << "-";
  for(int i=0; i<n1; i++) cout << "-";
  cout << " \"" << filename << "\" " << "-";
  for(int i=0; i<n2; i++) cout << "-";
  cout << ((open) ? "\\" : "/");
  cout << endl;
  if (!open) cout << endl;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Add more points to an existing and functioning EOSTable
void EOSTableDiffT::AddEOSPoints(const int nPoints, 
				 const Array1 <double> & nnNew,
				 const Array1 <double> & TNew,
				 const Array1 <double> & TENew,
				 const Array1 <double> & ppNew,
				 const Array1 <double> & pENew,
				 const Array1 <double> & eeNew,
				 const Array1 <double> & eENew) {
  nn.PushBack(nnNew);
  T.PushBack(TNew);
  pp.PushBack(ppNew);
  pE.PushBack(pENew);
  ee.PushBack(eeNew);
  eE.PushBack(eENew);
  n += nPoints;

  for(int i=0; i<nPoints; i++) {
    cout << "Adding EOS point:     "; 
    cout << "rs= " << fix(6,4,RsFromDensity(nnNew[i])) << " T[K]= " << fix(6,0,TNew[i]*PC::AUToK) 
	 << " P[GPa]= " << fix(10,3,ppNew[i]*PC::AUToGPa) << " E[eV]= " << fix(10,4,eeNew[i]*PC::AUToeV) << endl;
    //    Write4(rs,TNew[i]*PC::AUToK,eeNew[i],ppNew[i]*PC::AUToGPa);
  }

  PutIn1DArrays(nn,T,tnn,lists); // process the 1D arrays pp, pE etc one more time
}

// Add more points to an existing and functioning EOSTable
void EOSTableDiffT::AddEOSPoints(const int nPoints, 
				 const Array1 <double> & nnNew,
				 const Array1 <double> & TNew,
				 const Array1 <double> & ppNew,
				 const Array1 <double> & pENew,
				 const Array1 <double> & eeNew,
				 const Array1 <double> & eENew) {
  Array1 <double> TENew(nPoints,0.0);
  AddEOSPoints(nPoints,nnNew,TNew,TENew,ppNew,pENew,eeNew,eENew);
}

// Add more points to an existing and functioning EOSTable
// No error bars
void EOSTableDiffT::AddEOSPoints(const int nPoints, 
				 const Array1 <double> & nnNew,
				 const Array1 <double> & TNew,
				 const Array1 <double> & ppNew,
				 const Array1 <double> & eeNew) {
  Array1 <double> TENew(nPoints,0.0);
  Array1 <double> pENew(nPoints,0.0);
  Array1 <double> eENew(nPoints,0.0);
  AddEOSPoints(nPoints,nnNew,TNew,TENew,ppNew,pENew,eeNew,eENew);
}

// Add one points to an existing and functioning EOSTable
// Does not call PutIn1DArrays(nn,T,tnn,lists);
// to be classed from FinishedAddingPoints() 
void EOSTableDiffT::AddOneEOSPoint(const double nnNew, const double TNew, const double ppNew, const double pENew, const double eeNew, const double eENew) {
  nn.PushBack(nnNew);
  T.PushBack(TNew);
  pp.PushBack(ppNew);
  pE.PushBack(pENew);
  ee.PushBack(eeNew);
  eE.PushBack(eENew);
  n++;

  cout << "Adding EOS point:     "; 
  cout << "rs= " << fix(6,4,RsFromDensity(nnNew)) << " T[K]= " << fix(6,0,TNew*PC::AUToK) 
       << " P[GPa]= " << fix(10,3,ppNew*PC::AUToGPa) << " E[eV]= " << fix(10,4,eeNew*PC::AUToeV) << endl;
  //      Write4(rs,TNew*PC::AUToK,eeNew,ppNew*PC::AUToGPa);

  // do not call  PutIn1DArrays(nn,T,tnn,lists); // process the 1D arrays pp, pE etc one more time
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Find pair (x,y) in Arrays x and y
// return index if found, otherwise -1
int EOSTableDiffT::FindTableIndex(const Array1 <double> x, 
				  const Array1 <double> y, 
				  const double xx, 
				  const double yy) const {
  const int n(min(x.Size(),y.Size()));

  int i=0;
  while ( i<n && (!Equal(x[i],xx) || !Equal(y[i],yy)) ) {
    i++; 
  }

  if (i==n) return -1;

  for(int j=i+1; j<n; j++) {
    if (Equal(x[j],xx) && Equal(y[j],yy)) {
      error("Table seem to contain the same entry twice (A)",i,j,xx,yy,x[i],y[i],x[j],y[j]);
    }
  }

  Write3(i,xx,yy);

  return i;
}

// Find pair (x,y) in Arrays x and y
// return index if found, otherwise -1
int EOSTableDiffT::FindFirstYForGivenX(const Array1 <double> x, 
				       const Array1 <double> y, 
				       const double xx) const {
  const int n(min(x.Size(),y.Size()));

  bool flag= false;
  int iy   = -1;
  for(int i=0; i<n; i++) {
    if (Equal(x[i],xx)) {
      if (!flag) {
	iy = i;
	flag=true;
      } else {
	if (Equal(y[i],y[iy])) error("Two table entries seem to be identical",i,iy,x[i],y[i],x[iy],y[iy]);
	if (y[i]<y[iy]) iy=i;
      }
    }
  }
  if (!flag) error("Could not find in table: xx=",xx);

  return iy;
}

// Find pair (x,y) in Arrays x and y
// return index if found, otherwise -1
int EOSTableDiffT::FindNextYForGivenX(const Array1 <double> x, 
				      const Array1 <double> y, 
				      const double xx, const double yy) const {
  const int n(min(x.Size(),y.Size()));

  bool flag= false;
  int iy   = -1;
  for(int i=0; i<n; i++) {
    if (Equal(x[i],xx)) {
      if (y[i]>yy) {
	if (!flag) {
	  iy = i;
	  flag=true;
	} else {
	  if (Equal(y[i],y[iy])) error("Two table entries seem to be identical",i,iy,x[i],y[i],x[iy],y[iy]);
	  if (y[i]<y[iy]) iy=i;
	}
      }
    }
  }

  //  if (iy>=0) Write4(xx,yy,iy,y[iy])
  //  else Write4("not found",xx,yy,iy)

  return iy;
}

// Find the smallest value bigger then xmin in x[] 
// return the index of it
// do not assume x[] is ordered
int EOSTableDiffT::FindBigger(const Array1 <double> & x, const double xmin) const {
  int    ii = -1;
  double xm = 1e30;
  for(int i=0; i<x.Size(); i++) {
    if (x[i]>xmin && x[i]<xm) {
      ii=i;
      xm=x[i];
    }
  }
  return ii;
}

// find all the possible values occuring in the table
// put them in tx in order form
// the total number can be obtained from x.Size()
void EOSTableDiffT::FindAllValues(const Array1<double> & x,
				  Array1 <double> & tx) const {
  double xx=-1e30;
  int ii;
  do {
    ii=FindBigger(x,xx);
    if (ii!=-1) {
      tx.PushBack(x[ii]);
      xx=x[ii];
    }
  } while (ii!=-1);
}

// sets the tT array contain all distinct T in table. This is normally not set in EOSTableDiff
// only in EOSTable
void EOSTableDiffT::GetTemperatureArray(Array1 <double> & TT) const {
  OrderedArray1 <double> oTT;
  oTT.AddIfDistinct(T); // --> ordered array containing even the smallest diff as different entries

  TT.Clear();
  TT.PushBack(oTT.v[0]); // will constain only entries differ according to Equal()
  for(int i=1; i<oTT.v.Size(); i++) {
    if (!Equal(oTT.v[i],TT.Last())) TT.PushBack(oTT.v[i]);
  }
}

void EOSTableDiffT::PutIn1DArraysSlow(const Array1<double> & x,
				      const Array1<double> & y,
				      Array1 <double> & tx,
				      Array1 <Array1<int> > & lists) {
  cout << "Sorting " << x.Size() << " EOS data points in 1D arrays ..." << endl;
  FindAllValues(x,tx);
  Write("A");

  // Just to check that the data are actually on a grid 
  const int max=2000;
  if (tx.Size()>max) {
    cout << tx << endl;
    error("Number of x values exceeds limit - possible error in tables detected.",tx.Size(),max);
  }

  lists.Resize(tx.Size());
  for(int ix=0; ix<tx.Size(); ix++) {
    Write(ix);
    double xx = tx[ix];
    int iy = FindFirstYForGivenX(x,y,xx);

    lists[ix].PushBack(iy);

    while ( (iy=FindNextYForGivenX(x,y,xx,y[iy]))>=0 ) 
      lists[ix].PushBack(iy);

    // check if lists of constant density ordered by T have been created correctly
//     for(int iy=0; iy<lists[ix].Size(); iy++) {
//       int i=lists[ix][iy];
//       Write5(ix,iy,i,RsFromDensity(x[i]),y[i]*PC::AUToK);
//     } 
    
  }
  Check();
  cout << "... done sorting EOS data in 1D arrays." << endl;
}

void EOSTableDiffT::PutIn1DArrays(const Array1<double> & x,
				  const Array1<double> & y,
				  Array1 <double> & tx,
				  Array1 <Array1<int> > & lists) {
  pTTLast=-1.0; // should be in the constructors
  eTTLast=-1.0; // should be in the constructors

  if (x.Size()==0 || x.Size()!=y.Size()) error("Error in array sizes",x.Size(),y.Size());

  //  cout << "Sorting " << x.Size() << " EOS data points in 1D arrays ..." << endl;
  OrderedArray1 <double> ox;
  ox.AddIfDistinct(x); // --> ordered array containing even the smallest diff as different entries

  tx.Clear();
  tx.PushBack(ox.v[0]); // will constain only entries differ according to Equal()
  for(int i=1; i<ox.v.Size(); i++) {
    if (!Equal(ox.v[i],tx.Last())) tx.PushBack(ox.v[i]);
  }

  // Just to check that the data are actually on a grid 
  const int max=2000;
  if (tx.Size()>max) {
    cout << tx << endl;
    error("Number of x values exceeds limit - possible error in tables detected.",tx.Size(),max);
  }

  lists.Reset(); // added recently to clear old records (so that EOS point can be added)
  lists.Resize(tx.Size());
  //  Write(tx);

  for(int i=0; i<x.Size(); i++) {
    int ix = FindIndex(x[i],tx);
    if (ix>0 && Equal(x[i],tx[ix-1])) ix--;
    if (ix<tx.Size()-1 && Equal(x[i],tx[ix+1])) ix++;
    if (!Equal(x[i],tx[ix])) error("Could not find x value in x table",x[i],tx);

    if (lists[ix].Size()==0) {
      lists[ix].PushBack(i);
    } else {
      double yy = y[lists[ix].Last()];
      if (Equal(y[i],yy)) error("Same data point seems to exist twice (B)",x[i],y[i],RsFromDensity(x[i]),MassDensityGCC(x[i]),y[i]*PC::AUToK);
      //      if (Equal(y[i],yy)) error("Same data point seems to exist twice (B)",x[i],y[i],ix,MassDensityGCC(tx[ix]),MassDensityGCC(x[i]),y[i]*PC::AUToK);
      if (y[i]>yy) {
	lists[ix].PushBack(i);
      } else {
	int iy=0;
	while(iy<lists[ix].Size() && y[i]>y[lists[ix][iy]]) iy++;
	if (iy>0 && Equal(y[i],y[lists[ix][iy-1]])) iy--;
	if (iy<lists[ix].Size()-1 && Equal(y[i],y[lists[ix][iy+1]])) iy++;
	if (Equal(y[i],y[lists[ix][iy]])) error("Same data point seems to exist twice (C)",x[i],y[i],RsFromDensity(x[i]),MassDensityGCC(x[i]),y[i]*PC::AUToK,i,lists[ix][iy]);
	lists[ix].Insert(i,iy);
      }
    }
  }

  Check();
  //  cout << "... done sorting EOS data in 1D arrays." << endl;
  //  if (splineExtraplolationFlag)
  //    warning("Splines are now used for EXTRAPOLATION (needed for T and V derivatives) - was linear extrap. before");
}

void EOSTableDiffT::Check() {
  int n = nn.Size();
  if (T.Size()!=n) error("T array size incorrect");
  if (pp.Size()!=n) error("pp array size incorrect");
  if (ee.Size()!=n) error("ee array size incorrect");
  if (errorBars) {
    if (pE.Size()!=n) error("pE array size incorrect");
    if (eE.Size()!=n) error("eE array size incorrect");
  }
  if (errorBarsT) {
    if (TE.Size()!=n) error("TE array size incorrect",errorBarsT,TE.Size(),n);
  }

  if (tnn.Size()!=lists.Size()) error("tnn array size incorrect");

  for(int i=0; i<tnn.Size()-1; i++) {
    if (Equal(tnn[i],tnn[i+1])) error("Density tnn",i);
    if (tnn[i]>=tnn[i+1]) error("Density tnn",i);
  }

  int s=0;
  for(int i=0; i<lists.Size(); i++) 
    s+=lists[i].Size();
  if (s!=n) error("Lists array size incorrect");

  for(int ix=0; ix<lists.Size(); ix++) {
    for(int iy=0; iy<lists[ix].Size(); iy++) {
      if (!Equal(tnn[ix],nn[lists[ix][iy]])) error("Density problem",ix,iy,tnn[ix],nn[lists[ix][iy]]);
      if (iy<lists[ix].Size()-1 && T[lists[ix][iy]]>T[lists[ix][iy+1]]) 
	  error("ordering error",ix,iy,T[lists[ix][iy]],T[lists[ix][iy+1]]);
    }
  }
  
  //  cout << "EOSTableDiffT::Check() passed." << endl;
}


/*
// without entropy values
void EOSTableDiffT::Print() const {
  cout << "/-------------------- Printing all EOS points in table --------------------\\" << endl;
  for(int inn=0; inn<tnn.Size(); inn++) {
    //    double rs = RsFromDensity(tnn[inn]);
    //    cout << "  rs= " << fix(5,2,rs) << " T=";
    double rho = MassDensityGCC(tnn[inn]);
    cout << "  rho[g/cc]= " << fix(9,6,rho) << " T=";
    for(int iT=0; iT<lists[inn].Size(); iT++) {
      cout << " " << fix(6,0,GetTemperaturePoint(inn,iT)*PC::AUToK);
      //      if (GetFSFlagPoint(inn,iT)) cout << "*";
      cout << ((GetFSFlagPoint(inn,iT)) ? "*" : " ");
    }
    cout << endl;
  }
  cout << "\\--------------------------------------------------------------------------/" << endl;
}
*/

// with entropy values
void EOSTableDiffT::Print() const {
  //  const int d = int(log10(GetMaximumTemperature()*PC::AUToK));
  const int d = 6;
  cout << "/-------------------- Printing all EOS points in table --------------------\\" << endl;
  for(int inn=0; inn<tnn.Size(); inn++) {
    //    double rs = RsFromDensity(tnn[inn]);
    //    cout << "  rs= " << fix(5,2,rs) << " T=";
    double rho = MassDensityGCC(tnn[inn]);
    cout << "  rho[g/cc]= " << fix(9,6,rho) << " T(K)=";
    //    cout << "  rho[g/cc]= " << fix(9,6,rho) << " T(K)_[P(GPa)]=";
    for(int iT=0; iT<lists[inn].Size(); iT++) {
      cout << " " << fix(d,0,GetTemperaturePoint(inn,iT)*PC::AUToK);
      //      int np = int(ceil(log10(GetPressurePoint(inn,iT)*PC::AUToGPa)));
      //      cout << "_[" << fix(np,0,GetPressurePoint(inn,iT)*PC::AUToGPa) << "]";
      //      int ns = int(ceil(log10(GetEntropyPoint(inn,iT)*PC::AUToGPa)));
      //      cout << "_[" << fix(ns,0,GetEntropyPoint(inn,iT)*PC::AUToGPa) << "]";
      //      cout << ((GetFSFlagPoint(inn,iT)) ? "*" : " ");
      cout << Spaces(5-n);
    }
    cout << endl;
  }
  cout << "\\--------------------------------------------------------------------------/" << endl;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// use for anything BUT the free energy
double EOSTableDiffT::Interpolate2D(const double nnn, const double TT, const Array1 <double> & f, 
				    double & TTLast, Spline & sLast) const {
// For linear interpolation, switch off SPLINE_NNN_SAFER and SPLINE_NNN
#define SPLINE_NNN_SAFER
#ifdef SPLINE_NNN_SAFER
  // this allows for different Tmax in data set (see Interpolate2DF)
  const double eps=1e-3;
  int inn1 = MinimumDensityIndexForTemperature(TT,false,eps); // choose large tolerance for dF/dT to work
  int inn2 = MaximumDensityIndexForTemperature(TT,false,eps);
  if (inn1==notFound || inn2==notFound) error(name+": No density has data points for this T=",TT*PC::AUToK);
  if (inn1==inn2) error(name+": Not enough for interpolation, just one density has data points for this T=",TT*PC::AUToK);
  Spline s(inn2-inn1+1);
  for(int inn=inn1; inn<=inn2; inn++) {
    if (TT*(1.0+eps)>GetMinimumTemperature(inn) && TT*(1.0-eps)<GetMaximumTemperature(inn)) {
      double ff = Interpolate1D(lists[inn],T,f,TT); // interpolate as function of T as constant density
      //      Write4(RsFromDensity(nnn),RsFromDensity(tnn[inn]), TT*PC::AUToK, ff);
      //      s.PushBack(tnn[inn],ff);                      // store results at different densities (at fixed T)
      s.PushBack(argnn(tnn[inn]),ff);                      // store results at different densities (at fixed T)
    }
  }
  if (s.Size()<2) error("Spline has too few data points");
  s.Init();
  //  TTLast=TT; // do not use because it might not work with missing data points!!!
  //  sLast =s;
  //  return s.Interpolate(nnn); // interpolate as function of density (at fixed T)
  return s.Interpolate(argnn(nnn)); // interpolate as function of density (at fixed T)
#endif

#define SPLINE_NNN
#ifdef SPLINE_NNN
  if (splineExtraplolationFlag || (tnn[0]<=nnn && nnn<=tnn.Last())) {
    if (TTLast>0.0 && TT==TTLast) return sLast.Interpolate(nnn); // to speed things up
    Spline s(tnn.Size());
    for(int inn=0; inn<tnn.Size(); inn++) {
      double ff = Interpolate1D(lists[inn],T,f,TT);
      //      s.PushBack(tnn[inn],ff);
      s.PushBack(argnn(tnn[inn]),ff);
    }
    s.Init();
    TTLast=TT;
    sLast =s;
    return s.Interpolate(argnn(nnn));
  }
#endif    

  // density nnn is between nn1=tnn[inn] and nn2=tnn[inn+1] (unless at boundaries)
  int inn=FindInTable(nnn,tnn);  
  double nn1 = tnn[inn];
  double nn2 = tnn[inn+1];

  //  double rs  = RsFromDensity(nnn);
  double rs1 = RsFromDensity(nn1);
  double rs2 = RsFromDensity(nn2);
  //  Write3(nnn,nn1,nn2)
  //  Write3(rs,rs1,rs2)
  if (lists[inn].Size()<2)   error("Too few data points for rs=",rs1,lists[inn].Size());
  if (lists[inn+1].Size()<2) error("Too few data points for rs=",rs2,lists[inn+1].Size());
  //  Write4(inn,nn1,nn2,nnn);

  //  int ii1 = lists[inn][0];
  //  int ii2 = lists[inn+1][0];
  //  Write2(nn[ii1],nn[ii2]);

  // interpolate f for T at constant density (nn1 and nn2)
  double f1 = Interpolate1D(lists[inn],T,f,TT);
  double f2 = Interpolate1D(lists[inn+1],T,f,TT);
  double ff = LinearInterpolation(argnn(nn1),f1,argnn(nn2),f2,argnn(nnn));
  //  Write3(f1,f2,ff);
  return ff;
}

//////////////////////////////////////////////////////////////////////////////////////////////////

// use for anything BUT the free energy
double EOSTableDiffT::Interpolate1D(const Array1 <int> & list, 
				    const Array1 <double> & y,
				    const Array1 <double> & f,
				    const double yy) const {
  if (y.Size()<2) error("EOSTableDiffT::Interpolate1D (a): Too few elements in array for interpolation",y.Size(),f.Size());
  if (y.Size()!=f.Size()) error("Array size mismatch",y.Size(),f.Size());
  if (list.Size()<2) {
    Write(y);
    Write(f);
    Write(list);
    for(int i=0; i<list.Size(); i++) {
      Write3(i,y[list[i]],f[list[i]]);
    }
    Write(yy);
    error("EOSTableDiffT::Interpolate1D (b): Too few elements in selected list for interpolation:",list.Size());
  }

#define SPLINE_T
#ifdef SPLINE_T
  if (splineExtraplolationFlag || (y[list[0]]<=yy && yy<=y[list.Last()]) ) {
    Spline s(list.Size());
    for(int i=0; i<list.Size(); i++) {
      //      s.PushBack(y[list[i]],f[list[i]]);
      s.PushBack(argT(y[list[i]]),argF(f[list[i]]));
    }
    s.Init();
    return argF.Inverse(s.Interpolate(argT(yy)));
  }
#endif

  //#define POLYNOMIAL_T
#ifdef POLYNOMIAL_T
  error("6th order polynomials cannot reproduce dP/dT<0");
  if (y[list[0]]<=yy && yy<=y[list.Last()]) {
    int nP =  list.Size();
    Array1 <double> yList(nP);
    Array1 <double> fList(nP);
    Array1 <double> pList(nP);
    for(int i=0; i<nP; i++) {
      yList[i] = y[list[i]];
      fList[i] = f[list[i]];
      //      yList[i] = i;
      //      fList[i] = i;
      pList[i] = 1.0; // no weights yet
    }
#endif

  int i = 0;
  while (i<list.Size() && y[list[i]]<yy) {
    //    Write3(i,y[list[i]]*PC::AUToK,yy*PC::AUToK);
    i++;
  }

  if (i>0) i--;
  if (i>=list.Size()-1) i=list.Size()-2;

  int i1=list[i];
  int i2=list[i+1];

  double ff = argF.Inverse(LinearInterpolation(argT(y[i1]),argF(f[i1]),argT(y[i2]),argF(f[i2]),argT(yy)));

  /*
  Write2(i1,i2);
  Write3(y[i1]*PC::AUToK,y[i2]*PC::AUToK,yy*PC::AUToK);
  Write3(f[i1],f[i2],ff);
  */

  return ff;
}

double EOSTableDiffT::LinearInterpolation(const double x1, const double y1,
					  const double x2, const double y2,
					  const double xx) const {
  const double qx2=(xx-x1)/(x2-x1);  
  const double qx1=(x2-xx)/(x2-x1);  
#ifndef NO_WARNINGS
  if (qx1<0.0 || qx1>1.0 || qx2<0.0 || qx2>1.0)
    warning("Outside look up",qx1,qx2);
#endif
  //  Write4(qx1,qx2,y1,y2);
  return qx1*y1 + qx2*y2;
}

//////////////////////////////////////////////////////////////////////////////////////////////

double EOSTableDiffT::PressureTemperatureDerivative(const double nn, const double T, const double eps) const {
  double dT = T*eps;
  double T1 = T-dT;
  double T2 = T+dT;
  double P1 = Pressure(nn,T1);
  double P2 = Pressure(nn,T2);
  double dPdT = (P2-P1)/(2.0*dT);
  //  cout << "dP/dT for "; Write3(nn,T,dPdT);
  return dPdT;
}

double EOSTableDiffT::EnergyTemperatureDerivative(const double nn, const double T, const double eps) const {
  double dT = T*eps;
  double T1 = T-dT;
  double T2 = T+dT;
  double E1 = Energy(nn,T1);
  double E2 = Energy(nn,T2);
  double dEdT = (E2-E1)/(2.0*dT);
  return dEdT;
}

double EOSTableDiffT::PressureDensityDerivative(const double nn, const double T, const double eps) const {
  double dnn = nn*eps;
  double nn1 = nn-dnn;
  double nn2 = nn+dnn;
  double P1 = Pressure(nn1,T);
  double P2 = Pressure(nn2,T);
  double dPdnn = (P2-P1)/(2.0*dnn);
  return dPdnn;
}

double EOSTableDiffT::PressureDensitySecondDerivative(const double nn, const double T, const double eps) const {
  double dnn = nn*eps;
  double nnM = nn-dnn;
  double nnP = nn+dnn;
  double P  = Pressure(nn, T);
  double PM = Pressure(nnM,T);
  double PP = Pressure(nnP,T);
  double d2Pdnn2 = (PP-2.0*P+PM)/(dnn*dnn);
  return d2Pdnn2;
}

double EOSTableDiffT::EnergyDensityDerivative(const double nn, const double T, const double eps) const {
  double dnn = nn*eps;
  double nn1 = nn-dnn;
  double nn2 = nn+dnn;
  double E1 = Energy(nn1,T);
  double E2 = Energy(nn2,T);
  double dEdnn = (E2-E1)/(2.0*dnn);
  return dEdnn;
}

double EOSTableDiffT::PressureDensityDerivativeConstantEnergy(const double nn, const double T, const double eps) const {
  double dPdnnCT = PressureDensityDerivative(nn,T,eps);
  double dPdTCnn = PressureTemperatureDerivative(nn,T,eps);
  double dEdnnCT = EnergyDensityDerivative(nn,T,eps);
  double dEdTCnn = EnergyTemperatureDerivative(nn,T,eps);
  double dPdnnCE = dPdnnCT - dPdTCnn * dEdnnCT / dEdTCnn;
  return dPdnnCE;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////

void EOSTableDiffT::PrintOnePoint(ostream & of, const int i, const bool printEOS) const {
  //  double nnn  = nn[i];
  //  double TT   = T[i];

  //  double E    = ee[i];
  //  double EE   = eE[i];
  //  double P    = pp[i];
  //  double PE   = pE[i];
  //  double PV   = P/nnn;
  //  double PVV  = P/nnn/nnn;
  //  double PEV  = PE/nnn;
  //  double PEVV = PE/nnn/nnn;

  //  double TinK     = TT*PC::AUToK;
  //  double EineV    = E*PC::AUToeV;
  //  double EEineV   = EE * PC::AUToeV;
  //  double PinGPa   = P*PC::AUToGPa;
  //  double PEinGPa  = PE * PC::AUToGPa;
  
  //  double rho = MassDensityGCC(tnn[inn]);
  double rho = MassDensityGCC(nn[i]);
  //  cout << " ";
  if (printEOS) of << "EOS: ";
  of << " rho[g/cc]= " << fix(10,6,rho);
  of << " V[A^3]= " << fix(12,6,1.0/nn[i]*PC::AUToA3);
  of << " T[K]= " << fix(10,0,T[i]*PC::AUToK);
  of << " P[GPa]= " << fix(14,3,pp[i]*PC::AUToGPa);
  of << " +- " << fix(9,3,pE[i]*PC::AUToGPa);
  of << " E[Ha]= " << fix(18,8,ee[i]);
  of << " +- " << fix(11,8,eE[i]);
  of << endl;

  //  Write8(TinK,nnn,EineV,EEineV,PinGPa,PEinGPa,F,S);

  /* 
  if (dPdTGPaK<0.0) { // map out dP/dT<0 region
    cout << s << " ";
    Write7(TinK,rs,rhoH2gcc,EineV,PinGPa,dEdTeVK,dPdTGPaK);
  }
  */
  /*
  double dPdV  = eos.PressureVolumeDerivative(nn,T);
  double dVdP    = 1.0/dPdV;
  double dVH2dP  = 2.0*dVdP;
  double V   = 1.0/nn; // volume per electron in AU
  double VH2 = 2.0*V;

  double VH2OMixing = VH2 - dVH2dP   *   0.2513714 * PC::GPaToAU * 64.0;
  double rhoH2Ogcc  = 18*PC::u/(PC::ab*PC::ab*PC::ab)/1000.0 * VH2OMixing;
  
  cout << s << " ";
  Write9(TinK,rs,nn,PinGPa,VH2,VH2OMixing,dVH2dP,dVH2dP * 0.2513714 * PC::GPaToAU,rhoH2Ogcc);
  */

}

/*
void EOSTableDiffT::PrintOnePoint(const double nnn, const double TT) const {
  double rho = MassDensityGCC(nnn);
  double V = 1.0/nnn;
  cout << " rho[g/cc]= " << fix(9,6,rho);
  cout << " V[A^3/FU]= " << fix(9,3,V*PC::AUToA3);
  cout << " V[A^3/atom]= " << fix(9,3,V*PC::AUToA3);
  cout << " T[K]= " << fix(9,0,TT*PC::AUToK);
  
  double P = Pressure(nnn,TT);
  cout << " P[GPa]= " << fix(12,3,P*PC::AUToGPa);

  double PV = P*V;
  cout << " PV[Ha/FU]= " << fix(12,3,PV);

  double E = Energy(nnn,TT);
  cout << " E[Ha/FU]= " << fix(16,8,E);

  double H = Enthalpy(nnn,TT);
  cout << " H[Ha/FU]= " << fix(16,8,H);

  if (fSFlag.Size()==n) {
    double F = FreeEnergy(nnn,TT);
    cout << " F[Ha/FU]= " << fix(16,8,F);
    
    double S = Entropy(nnn,TT);
    cout << " S[kb/FU]= " << fix(16,8,S);
    
    double mTS = -TT*Entropy(nnn,TT);
    cout << " -TS[Ha/FU]= " << fix(16,8,mTS);  // F = E - TS   -->   -TS = F - E
    
    double G = GibbsFreeEnergy(nnn,TT);
    cout << " G[Ha/FU]= " << fix(16,8,G);
  }
  cout << endl;

}
*/

void EOSTableDiffT::PrintOnePoint(const double nnn, const double TT) const {
  double f = 1.0/nFU; // print extensive quatities per atom (not per FU)

  cout << name << ": ";

  double rho = MassDensityGCC(nnn);
  double V = 1.0/nnn;
  cout << " rho[g/cc]= " << fix(9,6,rho);
  cout << " V[A^3/atom]= " << fix(16,8,V*f*PC::AUToA3);
  cout << " T[K]= " << fix(9,0,TT*PC::AUToK);
  
  double P = Pressure(nnn,TT);
  cout << " P[GPa]= " << fix(12,3,P*PC::AUToGPa);

  double PV = P*V;
  cout << " PV[Ha/atom]= " << fix(16,8,PV*f);

  double E = Energy(nnn,TT);
  cout << " E[Ha/atom]= " << fix(16,8,E*f);

  double H = Enthalpy(nnn,TT);
  cout << " H[Ha/atom]= " << fix(16,8,H*f);

  cout << endl;

}

void EOSTableDiffT::PrintOnePoint(ostream & of, const double nnn, const double TT) const {
  //  double f = 1.0/nFU; // print extensive quatities per atom (not per FU)
  double f = 1.0; // print extensive quatities per FU (not per atom nor per electron)

  double rho = MassDensityGCC(nnn);
  double V = 1.0/nnn;
  of << " rho[g/cc]= " << fix(11,8,rho);
  of << " V[A^3]= " << fix(16,8,V*f*PC::AUToA3);
  of << " T[K]= " << fix(9,0,TT*PC::AUToK);
  
  double P = Pressure(nnn,TT);
  of << " P[GPa]= " << fix(16,6,P*PC::AUToGPa);

  //  double PV = P*V;
  //  of << " PV[Ha]= " << fix(16,8,PV*f);

  double E = Energy(nnn,TT);
  of << " E[Ha]= " << fix(16,8,E*f);

  //  double H = Enthalpy(nnn,TT);
  //  of << " H[Ha]= " << fix(16,8,H*f);

  /*
  if (fSFlag.Size()==n) {
    double F = FreeEnergy(nnn,TT);
    of << " F[Ha/atom]= " << fix(16,8,F*f);
    
    double S = Entropy(nnn,TT);
    of << " S[kb/atom]= " << fix(16,8,S*f);
    
    double mTS = -TT*Entropy(nnn,TT);
    of << " -TS[Ha/atom]= " << fix(16,8,mTS*f);  // F = E - TS   -->   -TS = F - E
    
    double G = GibbsFreeEnergy(nnn,TT);
    of << " G[atom/FU]= " << fix(16,8,G*f);
  }
  */
  of << endl;

}

void EOSTableDiffT::PrintAllPoints() const {
  cout << "/-------------------- Printing all EOS points in table --------------------\\" << endl;
  for(int inn=0; inn<tnn.Size(); inn++) {
    for(int iT=0; iT<lists[inn].Size(); iT++) {
      PrintOnePoint(inn,iT);
    }
  }
  cout << "\\--------------------------------------------------------------------------/" << endl;
}

///////////////////////////////////////////////////////////////////////////////////////////

void EOSTableDiffT::WriteOnePointToFile(ofstream & of, const int i) const {
  of << "f= " << name;
  of << " N= " << nFU;

  double rho = MassDensityGCC(nn[i]);
  of << " rho[g/cc]= " << fix(10,6,rho);

  double V = 1.0/nn[i];
  of << " V[A^3]= " << fix(16,8,V*PC::AUToA3);
  of << " T[K]= " << fix(10,0,T[i]*PC::AUToK);
  
  of << " P[GPa]= " << fix(14,3,pp[i]*PC::AUToGPa);
  of << " "         << fix(9,3,pE[i]*PC::AUToGPa); // no " +- " string
  of << " E[Ha]= "  << fix(18,8,ee[i]);
  of << " "         << fix(11,8,eE[i]);

  of << endl;
}

/*
void EOSTableDiffT::WriteAllPointsToFile(ofstream & of) const {
  of << "#################################################################################" << endl;
  of << "# First-Principles Equation of State Database for Warm Dense Matter Computation #" << endl;
  of << "# Code written by Burkhard Militzer                        Berkeley, 09/06/2020 #" << endl;
  of << "#################################################################################" << endl;
  for(int inn=0; inn<tnn.Size(); inn++) {
    of << endl;    
    for(int iT=0; iT<lists[inn].Size(); iT++) {
      WriteOnePointToFile(of,inn,iT);
    }
  }
}
*/

Array1 <string> EOSTableDiffT::SplitString(const string & s) const {
  Array1 <string> lines;
  int iLast=0;
  for(int i=0; i<s.length(); i++) {
    if (s[i]=='\n') {
      lines.PushBack(s.substr(iLast,i-iLast));
      iLast = i+1; // +1 b/c we want to skip the \n
    }
  }
  if (iLast<s.length()) {
    lines.PushBack(s.substr(iLast));
  }
  return lines;
}

int EOSTableDiffT::MaxLength(const Array1 <string> & s) const {
  int l=0;
  for(int i=0; i<s.Size(); i++) {
    Array1 <string> si = SplitString(s[i]);
    for(int j=0; j<si.Size(); j++) {
      if (si[j].length()>l) l = si[j].length();
    }
  }
  return l;
}

void EOSTableDiffT::PrintString(ofstream & of, const string & s, const int l, const bool center) const {
  if (!center) {
    of << "# " << s << Spaces(l-s.length()) << " #" << endl;
  } else {
    int d = l-s.length();
    int d1 = d/2;
    int d2 = d-d1;
    of << "# " << Spaces(d1) << s << Spaces(d2) << " #" << endl;
  }
}

void EOSTableDiffT::WriteAllPointsToFile(ofstream & of) const {

  string s1 = "First-Principles Equation of State Database for Warm Dense Matter Computation";
  string s2 = "Code written by Burkhard Militzer                        Berkeley, 09/07/2020";
  //  int l = max(int(s1.length()),int(s2.length()),MaxLength(citation));
  int l = max(int(s1.length()),int(s2.length()));
  l = max(l,MaxLength(reference));

  of << Spaces(l+4,'#') << endl;
  PrintString(of," ",l);
  PrintString(of,s1,l,true);
  PrintString(of,s2,l,true);
  if (reference.Size()>0) {
    PrintString(of," ",l);
    if (reference.Size()==1) {
      PrintString(of,"To thank the authors, please cite this 1 article:",l);
    } else {
      PrintString(of,"To thank the authors, please cite these "+IntToString(reference.Size())+" articles:",l);
    }
    for(int i=0; i<reference.Size(); i++) {
      PrintString(of," ",l);
      Array1 <string> s = SplitString(reference[i]);
      for(int j=0; j<s.Size(); j++) {
	PrintString(of,s[j],l);
      }
    }
    //    PrintString(" ",l);
  } 
  if (GetHugoniotFlag()) {
    if (reference.Size()>0) PrintString(of," ",l);
    of << "# Hugoniot initial condition E0[Ha]=  " << fix(18,10,GetHugoniotE0())                 << Spaces(l-53) << "#" << endl;
    of << "# Hugoniot initial condition P0[GPa]= " << fix(18,10,GetHugoniotP0()*PC::AUToGPa)     << Spaces(l-53) << "#" << endl;
    of << "# Hugoniot initial condition V0[A^3]= " << fix(18,10,1.0/GetHugoniotnn0()*PC::AUToA3) << Spaces(l-53) << "#" << endl;
    PrintString(of," ",l);
  }
  of << Spaces(l+4,'#') << endl;

  //  of << "#################################################################################" << endl;
  //  of << "# First-Principles Equation of State Database for Warm Dense Matter Computation #" << endl;
  //  of << "# Code written by Burkhard Militzer                        Berkeley, 09/06/2020 #" << endl;
  //  of << "#################################################################################" << endl;

  for(int inn=0; inn<tnn.Size(); inn++) {
    of << endl;    
    for(int iT=0; iT<lists[inn].Size(); iT++) {
      WriteOnePointToFile(of,inn,iT);
    }
  }
}

void EOSTableDiffT::ExtractHugoniotDataFromFile(const string & fileName) {
  int n=0;
  Parser p(fileName);
  p.UnSetIgnoreComments();
  while(p.ReadLine()) {
    if (p.GetNWords()>=6) {
      if (p.GetString(1)=="Hugoniot" && p.GetString(2)=="initial" && p.GetString(3)=="condition") {
	if (p.GetString(4)=="E0[Ha]=")  { n++; hugoniotE0  = p.GetDouble(5);                    }
	if (p.GetString(4)=="P0[GPa]=") { n++; hugoniotP0  = p.GetDouble(5)/PC::AUToGPa;        }
	if (p.GetString(4)=="V0[A^3]=") { n++; hugoniotnn0 = 1.0 / (p.GetDouble(5)/PC::AUToA3); }
	if (n==3) { 
	  //	  Write3(hugoniotE0,hugoniotP0,hugoniotnn0);
	  hugoniotFlag=true; 
	  return; 
	}
      }
    }
  }
  warning("No Hugoniot information could be extracted from file",fileName);
}

void StripOffCharacters(string & s, const char c) {
  while(s[0]==c) {
    s = s.substr(1);
  }
  while(s.length()>0 && s[s.length()-1]==c) {
    s = s.substr(0,s.length()-1);
  }
}

void StripOffCharacters(string & s) {
  StripOffCharacters(s,'#');
  StripOffCharacters(s,' ');
}

void EOSTableDiffT::ExtractReferencesFromFile(const string & fileName) {
  reference.Resize(0);
  Parser p(fileName);
  p.UnSetIgnoreComments();
  while(p.ReadLine()) {
    if (p.GetLineString().find("To thank the authors, please cite")!=string::npos) {
      int n = p.GetInt(8);
      p.ReadLineSafely(); // skip over first empty file
      while(n>0) {
	string reference;
	while(true) {
	  p.ReadLineSafely();
	  string s = p.GetLineString();
	  StripOffCharacters(s);
	  if (s=="") break; // ok fine empty line, marks end of reference
	  if (reference!="") reference += " \n";
	  reference += s;
	}
	if (reference=="") error("Could not extra references properly.");
	AddReference(reference);
	n--;
      }
      return; // n reference should now have been added
    }
  }
  warning("No references could be extracted from file",fileName);
}

///////////////////////////////////////////////////////////////////////////////////////////

class FindDensityGivenTemperatureAndPressure {
  const EOSTableDiffT & eos;
  double T,P;
public:
  FindDensityGivenTemperatureAndPressure(const EOSTableDiffT & eos_, const double T_, const double P_)
    :eos(eos_),T(T_),P(P_) {}

  double operator()(const double nn) const {
    double PP = eos.Pressure(nn,T);
    //    eos.PrintOnePoint(nn,T);
    return PP-P;
  }

};

bool EOSTableDiffT::DensityGivenTemperatureAndPressure(const double T, const double P, double & nn, const bool strict) {
  nn = 0.0;
  FindDensityGivenTemperatureAndPressure fdgtp(*this,T,P);
  double T1 = GetMinimumTemperature();
  double T2 = GetMaximumTemperature();
  const double eps=1e-8;
  const double f1p = 1.0+eps;
  const double f1m = 1.0-eps;
  if (T<T1*f1m || T>T2*f1p) {
    if (!strict) return false;
    error("T to outside of EOS range",name,T*PC::AUToK,T1*PC::AUToK,T2*PC::AUToK);
  }
  double nn1 = MinimumDensityForTemperature(T);
  double nn2 = MaximumDensityForTemperature(T);
  double rho1 = MassDensityGCC(nn1);
  double rho2 = MassDensityGCC(nn2);
  double P1 = Pressure(nn1,T);
  double P2 = Pressure(nn2,T);
  if (P<P1*f1m || P>P2*f1p) {
    if (!strict) return false;
    cout << endl;
    cout << "Error: "; Write2(T*PC::AUToK,P*PC::AUToGPa);
    cout << "Error: "; Write2(rho1,rho2);
    cout << "Error: "; Write3(P*PC::AUToGPa,P1*PC::AUToGPa,P2*PC::AUToGPa);
    error("P or T not in range of EOS table:",name);
  }
  //  double rho1 = MassDensityGCC(nn1);
  //  double rho2 = MassDensityGCC(nn2);
  //  double P1 = Pressure(nn1,T);
  //  double P2 = Pressure(nn2,T);
  //  cout << "DensityGivenTemperatureAndPressure: "; Write6(T*PC::AUToK,rho1,rho2,P*PC::AUToGPa,P1*PC::AUToGPa,P2*PC::AUToGPa);
  nn = FindRootRegulaFalsiSafely(nn1*f1m,nn2*f1p,eps,fdgtp,"DensityGivenTemperatureAndPressure: "
				 +GetName()+" T[K]= "+DoubleToString(T*PC::AUToK)
				 +" P[GPa]= "+DoubleToString(P*PC::AUToGPa)+
				 " rho[g/cc]= "+DoubleToString(rho1)+"-"+DoubleToString(rho2)+" :");
  return true;
}

class FindTemperatureGivenDensityAndPressure {
  const EOSTableDiffT & eos;
  double nnn;
  double PP;
public:
  FindTemperatureGivenDensityAndPressure(const EOSTableDiffT & eos_, const double nnn_, const double PP_):
    eos(eos_),nnn(nnn_),PP(PP_){}
  double operator()(const double TT) const {
    return eos.Pressure(nnn,TT)-PP;
  }
};


double EOSTableDiffT::TemperatureGivenDensityAndPressure(const double nnn, const double PP, 
							 const double T1, const double T2, const double eps) const {
  FindTemperatureGivenDensityAndPressure hfT(*this,nnn,PP);
  return FindRootBisection(T1,T2,eps,hfT,"Find T such the P(nn,T)=P_target");
}

Array1 <int> EOSTableDiffT::DetermineConvexHull(const double eps) const {
  Array1 <int> ch;
  
  int inn;
  for(inn=0; inn<tnn.Size(); inn++) {
    ch.PushBack(lists[inn].First()); // increase density 'nn' and add all lowest-T points
  }
  for(int i=1; i<ch.Size()-1; i++) {
    int i1 = i-1;
    int i2 = i+1;
    if (T[ch[i1]]==T[ch[i2]] && T[ch[i]]>T[ch[i2]]*(1.0+eps)) {
      ch.Delete(i); // remove any single-point kinks like _____/\______
    }
  }

  inn = tnn.Size()-1; // increase T at highest nn
  for(int iT=1; iT<lists[inn].Size(); iT++) {
    ch.PushBack(lists[inn][iT]);
  }
  /* wrong - conflicts with picking all lowest T first
  Array1 <double> TT = GetListOfAllTemperatures();
  for(int iT=0; iT<TT.Size(); iT++) {
    int inn = MaximumDensityIndexForTemperature(TT[iT]);
    int jT = FindClosestTemperatureFixedDensity(inn,TT[iT],false);
    if (T[lists[inn][jT]]==TT[iT] && ch.Find(lists[inn][jT])==notFound) ch.PushBack(lists[inn][jT]);
  }
  */

  int j = ch.Size(); // decrease nn add highest T
  for(inn=tnn.Size()-2; inn>=0; inn--) {
    ch.PushBack(lists[inn].Last());
  }
  for(int i=j; i<ch.Size()-1; i++) {
    int i1 = i-1;
    int i2 = i+1;
    if (T[ch[i1]]==T[ch[i2]] && T[ch[i]]<T[ch[i2]]*(1.0-eps)) {
      ch.Delete(i); // remove any single-point kinks like _______  __________
    }               //                                           \/
  }


  inn = 0;
  for(int iT=lists[inn].Size()-2; iT>0; iT--) {
    ch.PushBack(lists[inn][iT]);
  }
  /* wrong - conflicts with picking all lowest T first
  for(int iT=TT.Size()-1; iT>=0; iT--) {
    int inn = MinimumDensityIndexForTemperature(TT[iT]);
    int jT = FindClosestTemperatureFixedDensity(inn,TT[iT],false);
    if (T[lists[inn][jT]]==TT[iT] && ch.Find(lists[inn][jT])==notFound) ch.PushBack(lists[inn][jT]);
  }
  */

  return ch;
}

