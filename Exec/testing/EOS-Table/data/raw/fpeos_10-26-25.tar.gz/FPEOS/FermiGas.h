/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// Ideal Fermi gas in 3D                                                   // 
//                                                                         //
// Burkhard Militzer                                Washington, 03-23-07   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////

#ifndef _FERMIGAS_
#define _FERMIGAS_

#include "Spline.h"

double PressureBoltzmannGas(const double beta, const double ne);
double EnergyBoltzmannGas(const double beta);
double FreeEnergyBoltzmannGas(const double lambda, const double beta, const double nn, const double g=1.0, const double e=0.0);
double EntropyBoltzmannGas(const double lambda, const double beta, const double nn, const double g=1.0, const double e=0.0);

//double LambdaDB(const double lambda, const double beta); -- conflict with LambdaDB(m,T)
//double LambdaDebyeLambdaBeta(const double lambda, const double beta); // wrong name
double LambdaDeBroglieLambdaBeta(const double lambda, const double beta); // correct name
double LambdaDeBroglieMassTemperature(const double m, const double T); // correct name

double FermiEnergy(const double lambda, const double ne, const double g);
double FermiDegeneracy(const double lambda, const double ne, const double g, const double T);

double MuFermiGas(const double lambda, const double beta, const double ne, const double g);
double EnergyFermiGas(const double lambda, const double beta, const double ne, const double g);
double PressureFermiGas(const double lambda, const double beta, const double ne, const double g);
double FreeEnergyFermiGas(const double lambda, const double beta, const double ne, const double g);
double EntropyFermiGas(const double lambda, const double beta, const double ne, const double g);

class FermiFunctionTable {
public:
  FermiFunctionTable():lambda0(0.5),ne0(1.0),g0(2),EF0(FermiEnergy(lambda0,ne0,g0)),nn(1000),thetaMax(10.0){
    ff.PushBack(0.0,3.0/5.0); // T->0 limit
    cout << "Initializing Fermi function table ... ";
    cout.flush();
    for(int i=1; i<=nn; i++) {
      double theta = thetaMax*double(i)/double(nn);
      double T = theta*EF0;
      ff.PushBack(theta,FreeEnergyFermiGas(lambda0,1.0/T,ne0,g0)/EF0);
    }
    ff.Init();  // spline contains ff( theta=T/EF , F/N/EF(theta) )
    cout << "done." << endl << endl;
  }
  double f(const double lambda, const double beta, const double ne, const double g) const {
    double EF = FermiEnergy(lambda,ne,g);
    double theta = 1.0/(beta*EF);
    if (theta>thetaMax) return FreeEnergyBoltzmannGas(lambda,beta,ne,g,0.0);
    double ff1 = ff.Interpolate(theta)*EF;
    //    double ff2 = FreeEnergyFermiGas(lambda,beta,ne,g);
    //    Write3(ff1,ff2,ff1/ff2-1.0);
    return ff1;
  }
private:
  const double lambda0;
  const double ne0;
  const double g0;
  const double EF0;
  const int nn;
  const double thetaMax;

  Spline ff;
};

extern FermiFunctionTable fermiFunctionTable;

#endif // _FERMIGAS_

