/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// Keep an Array1 <T> in order v[i]<=v[i+1]                                // 
// using the function Add(T) or Sort()                                     //
//                                                                         //
// Burkhard Militzer                                  Washington 4-25-06   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////

#ifndef _ORDERARRAY_
#define _ORDERARRAY_

#include "Array.h"
#include "HeapSort.h"

// return smallest 'i' so that 'a <= v[i]'
template<class T>
int FindIndex(const T & t, const Array1 <T> & a) {
  if (a.Size()==0) error("array size error",a.Size());
  int iLow  = 0;
  int iHigh = a.Size()-1;
  while (iLow+1<iHigh) {
    int iMid=(iLow+iHigh)/2;
    if (t<a[iMid]) {
      iHigh = iMid;
    } else {
      iLow  = iMid;
    }
  }
  return iHigh;
}

template <class T> class OrderedArray1 {
 public:
  Array1 <T> v;
  void Add(const T & a) {
    if (v.Size()==0 || a>v.Last()) 
      v.PushBack(a);
    int i=0;
    while(a>v[i] && i<v.Size()) i++;
    Write2(i,FindIndex(a,v));
    v.Insert(a,i);
    Check();
  }
  void Add(const Array1 <T> & a) {
    for(int i=0; i<a.Size(); i++) 
      Add(a[i]);
  }
  void AddIfDistinct(const T & a) {
    if (v.Size()==0 || a>v.Last()) 
      v.PushBack(a);
    int i=0;
    while(a>v[i] && i<v.Size()) i++;
    if (a!=v[i]) v.Insert(a,i);
    Check();
  }
  void AddIfDistinct(const Array1 <T> & a) {
    for(int i=0; i<a.Size(); i++) 
      AddIfDistinct(a[i]);
  }
  void Check() const {
    for(int i=0; i<v.Size()-1; i++) {
      if (v[i]>v[i+1]) error("OrderedArray got disordered",i,v[i],v[i+1]);
    }
  }
  int Find(const T & a) {
    return FindIndex(a,v);
  }
  void Sort() {
    HeapSort(v);
  }

};

#endif // _ORDERARRAY_
