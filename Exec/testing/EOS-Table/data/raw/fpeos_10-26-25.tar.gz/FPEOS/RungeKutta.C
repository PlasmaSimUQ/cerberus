//////////////////////////////////////////////////////////////////////////////
//                                                                          //
// Runge Kutta algorithm                                                    //
//                                                                          //
// Burkhard Militzer                                  Livermore 9-26-00     //
//                                                    Washington 11-25-05   //
//                                                                          //
//////////////////////////////////////////////////////////////////////////////

#include "RungeKutta.h"

const double RungeKuttaParameter::tiny=1.0e-16; 
const int RungeKuttaParameter::stepDivMax = 10; // Standard is 10

const double RungeKuttaParameter::alpha[2]= {0.25, 27.0/40.0};
const double RungeKuttaParameter::beta2[1]= {0.25};
const double RungeKuttaParameter::beta3[2]= {-189.0/800.0,  729.0/800.0};
const double RungeKuttaParameter::beta4[3]= {214.0/891.0, 1.0/33.0, 650.0/891.0};
const double RungeKuttaParameter::Gamma[3]= {214.0/891.0, 1.0/33.0, 650.0/891.0};
const double RungeKuttaParameter::c[4]= {-23.0/1782.0, 1.0/33.0, -350.0/11583.0, 1.0/78.0};

/*

class Circle {
public:
  Circle():y(n){
    y[0] = -1.0;
    y[1] = +1.0;
  }
  static const int n=2;
  Array1 <double> GetInitialConditions(const double x0) {
    return y;
  }
  void Diff(const double x, const Array1 <double> & y, Array1 <double> & dydx) const {
    dydx[0] = -y[1];
    dydx[1] =  y[0];
  }
  bool OutPut(const double x, const double h, const Array1 <double> & y, Array1 <double> & dydx) {
    Write4(x,y[0],y[1],sqrt(sqr(y[0])+sqr(y[1])));
    return false;
  }
  Array1 <double> y;
};

int main() {
  Circle circle;
  RungeKutta<Circle> rk;
  rk.Solve(0.0,1.0,1e-8,1e-8,circle);
  cout << rk;
}

*/
