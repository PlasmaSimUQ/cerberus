/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// Debye plasma model                                                      // 
//                                                                         //
// Burkhard Militzer                                Washington, 11-03-01   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////

#include "Standard.h"
#include "Array.h"

// Put in the numbers of particle and the volume
// assume atomic units [e^2/(4 Pi e0) = 1]
double QQ(const double N, const double Z, const double V) { // N ions of charge Z in volume V (just one ion type)
  double Ne = N*Z; // add enough electron to make system charge neutral
  double Ze = -1;
  double qq = ( Ne*Ze*Ze + N*Z*Z )/V;
  return qq;
}

double QQ(const double N1, const double Z1, const double N2, const double Z2, const double V) { // N ions of charge Z in volume V (two ion types here)
  double Ne = N1*Z1+N2*Z2; // add enough electron to make system charge neutral
  double Ze = -1;
  double qq = ( Ne*Ze*Ze + N1*Z1*Z1 + N2*Z2*Z2 )/V;
  return qq;
}

double QQ(const Array1 <double> & N, const Array1 <double> & Z, const double V) { // N ions of charge Z in volume V (two ion types here)
  double Ne = 0.0;
  double qq = 0.0;
  for(int i=0; i<N.Size(); i++) {
    qq += N[i]*Z[i]*Z[i];
    Ne += N[i]*Z[i]; // all Z must be possible
    if (Z[i]<0.0) error("problem in Debye model");
  }
  double Ze = -1.0; // add electronic contributions
  qq += Ne * Ze*Ze;
  qq = qq/V;
  //  double Ne = N1*Z1+N2*Z2; // add enough electron to make system charge neutral
  //  double qq = ( Ne*Ze*Ze + N1*Z1*Z1 + N2*Z2*Z2 )/V;
  return qq;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

// kappa = 1/r_debye in a.u.
double Kappa(const double N, const double Z, const double V, const double kbT) {
  const double e0= 1.0/(4.0*pi); 
  double kappa  = sqrt( QQ(N,Z,V)/(e0*kbT) );
  return kappa;
}

// kappa = 1/r_debye in a.u.
double Kappa(const double N1, const double Z1, const double N2, const double Z2, const double V, const double kbT) {
  const double e0= 1.0/(4.0*pi); 
  double kappa  = sqrt( QQ(N1,Z1,N2,Z2,V)/(e0*kbT) );
  return kappa;
}

// kappa = 1/r_debye in a.u.
double Kappa(const Array1 <double> & N, const Array1 <double> & Z, const double V, const double kbT) {
  const double e0= 1.0/(4.0*pi); 
  double kappa  = sqrt( QQ(N,Z,V)/(e0*kbT) );
  return kappa;
}

////////////////////////////////////////////////////////////////////////////////////////////////////


// Debye radius
double RDebye(const double N, const double Z, const double V, const double kbT) {
  return 1.0/Kappa(N, Z, V, kbT);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

// in a.u. per cell
double UDebye(const double NI, const double ZI, const double V, const double kbT) {
  double kappa = Kappa(NI,ZI,V,kbT);
  double uDebye = - kbT * kappa*kappa*kappa*V / (8.0*pi); // per cell of volume V with NI ions and Ne electrons
  return uDebye;
}

// in a.u. per cell
double UDebye(const double NI1, const double ZI1, const double NI2, const double ZI2, const double V, const double kbT) {
  double kappa = Kappa(NI1,ZI1,NI2,ZI2,V,kbT);
  double uDebye = - kbT * kappa*kappa*kappa*V / (8.0*pi); // per cell of volume V with NI ions and Ne electrons
  return uDebye;
}

// in a.u. per cell
double UDebye(const Array1 <double> & N, const Array1 <double> & Z, const double V, const double kbT) {
  double kappa = Kappa(N,Z,V,kbT);
  double uDebye = - kbT * kappa*kappa*kappa*V / (8.0*pi); // per cell of volume V with NI ions and Ne electrons
  return uDebye;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

// 10/11/19: This returns S*T not just S
// in a.u. per cell
double SDebye(const double NI, const double ZI, const double V, const double kbT) {
  double kappa = Kappa(NI,ZI,V,kbT);
  double sDebye = - kbT * kappa*kappa*kappa*V / (24.0*pi); // per cell of volume V with NI ions and Ne electrons
  return sDebye;
}

// 10/11/19: This returns S*T not just S
// in a.u. per cell
double SDebye(const Array1 <double> & N, const Array1 <double> & Z, const double V, const double kbT) {
  double kappa = Kappa(N,Z,V,kbT);
  double sDebye = - kbT * kappa*kappa*kappa*V / (24.0*pi); // per cell of volume V with NI ions and Ne electrons
  return sDebye;
}

////////////////////////////////////////////////////////////////////////////////////////////////////


// in a.u. per cell
double FDebye(const double NI, const double ZI, const double V, const double kbT) {
  double kappa = Kappa(NI,ZI,V,kbT);
  double fDebye = - kbT * kappa*kappa*kappa*V / (12.0*pi); // per cell of volume V with NI ions and Ne electrons
  return fDebye;
}

// in a.u. per cell
double FDebye(const Array1 <double> & N, const Array1 <double> & Z, const double V, const double kbT) {
  double kappa = Kappa(N,Z,V,kbT);
  double fDebye = - kbT * kappa*kappa*kappa*V / (12.0*pi); // per cell of volume V with NI ions and Ne electrons
  return fDebye;
}


////////////////////////////////////////////////////////////////////////////////////////////////////

// P in a.u.
double PDebye(const double NI, const double ZI, const double V, const double kbT) {
  double kappa = Kappa(NI,ZI,V,kbT);
  double pDebye = - kbT * kappa*kappa*kappa / (24.0*pi); 
  return pDebye;
}

// P in a.u.
double PDebye(const double NI1, const double ZI1, const double NI2, const double ZI2, const double V, const double kbT) {
  double kappa = Kappa(NI1,ZI1,NI2,ZI2,V,kbT);
  double pDebye = - kbT * kappa*kappa*kappa / (24.0*pi); 
  return pDebye;
}

// P in a.u.
double PDebye(const Array1 <double> & N, const Array1 <double> & Z, const double V, const double kbT) {
  double kappa = Kappa(N,Z,V,kbT);
  double pDebye = - kbT * kappa*kappa*kappa / (24.0*pi); 
  return pDebye;
}



/*

int main() {
  double L = 6.365627;
  double V = L*L*L;

  double TInK = 304332275;
  double T = TInK/315774.6608728946;

  double ZI = 6.0;
  double NI = 8.0;
  double Ne = NI*ZI;

  double pDebye = PDebye(NI,ZI,V,T);
  double uDebye = UDebye(NI,ZI,V,T);
  double sDebye = SDebye(NI,ZI,V,T);
  double fDebye = FDebye(NI,ZI,V,T);
  Write3(uDebye,uDebye/NI,uDebye/Ne);
  Write3(sDebye,sDebye/NI,sDebye/Ne);
  Write3(fDebye,fDebye/NI,fDebye/Ne);
  Write2(pDebye,pDebye*2.942100987404041e+04);
}

*/
