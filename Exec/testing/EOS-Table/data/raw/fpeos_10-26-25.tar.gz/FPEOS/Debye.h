/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// Debye plasma model                                                      // 
//                                                                         //
// Burkhard Militzer                                Washington, 11-03-01   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////

#ifndef _DEBYE_
#define _DEBYE_

double RDebye(const double N, const double Z, const double V, const double kbT);
double UDebye(const double NI, const double ZI, const double V, const double kbT);
double SDebye(const double NI, const double ZI, const double V, const double kbT);
double FDebye(const double NI, const double ZI, const double V, const double kbT);
double PDebye(const double NI, const double ZI, const double V, const double kbT);

double UDebye(const double NI1, const double ZI1, const double NI2, const double ZI2, const double V, const double kbT);
double PDebye(const double NI1, const double ZI1, const double NI2, const double ZI2, const double V, const double kbT);

double UDebye(const Array1 <double> & N, const Array1 <double> & Z, const double V, const double kbT);
double SDebye(const Array1 <double> & N, const Array1 <double> & Z, const double V, const double kbT);
double FDebye(const Array1 <double> & N, const Array1 <double> & Z, const double V, const double kbT);
double PDebye(const Array1 <double> & N, const Array1 <double> & Z, const double V, const double kbT);
#endif // _DEBYE_

