/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// Ideal Fermi gas in 3D                                                   // 
//                                                                         //
// Burkhard Militzer                                Washington, 03-23-07   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////

#include "Standard.h"
#include "GKIntegration.h"
#include "FindRoot.h"
#include "RelativisticFermiGas.h"
#include "Spline.h"
#include "Physics.h"

// relativistic corrections are large if alpha is large
// alpha ~ z/beta ~ T^2
// alpha ~ 1/m (electrons are much more important than nuclei)
// alpha ~ z ~ p^2 (obviously for high momentum k states)

inline double RelativisticEnergyFromZ(const double z, const double m, const double beta) {
  const double c2 = PC::cAU*PC::cAU;
  // z = p^2/(2m)*beta but no longer z = energy*beta
  double alpha = 2.0 * z / ( m*c2 * beta);
  double energy = ( alpha < 1e-10 ) ? m*c2*(alpha/2.0 - alpha*alpha/8.0) : m*c2*( sqrt(alpha+1.0)-1.0 );
  //  Write3(z,alpha,PC::cAU);
  //  Quit("c");
  return energy;
}

inline double RelativisticFermiDiracOccupation(const double z, const double a, const double m, const double beta) {
  double eBeta = beta * RelativisticEnergyFromZ(z,m,beta);
  return 1.0 / ( exp( (eBeta-a) ) + 1.0 );
}

/*
// E^2 = (m0*c^2)^2 + (p*c)^2
inline EnergyFromMomentum(const double p) {
  double m0 = 1.0; // since we are dealing with electrons
  double E2 = sqr(m0*PC::cAU*PC::cAU) + sqr(p*PC::cAU);
  return sqrt(E2);
}
*/

class RelativisticFermiIntegral {
  const double a,exponentZ,exponentE,m,beta;

 public:
  RelativisticFermiIntegral(const double a_, const double exponentZ_, const double exponentE_, const double m_, const double beta_):
    a(a_),exponentZ(exponentZ_),exponentE(exponentE_),m(m_),beta(beta_) {}

  double operator() (const double z) {
    // here we need m0*c^2 but we have removed it from energy scale when we integrate
    double E = RelativisticEnergyFromZ(z,m,beta) + m*PC::cAU*PC::cAU;
    return pow(z,exponentZ)*pow(E,exponentE)*RelativisticFermiDiracOccupation(z,a,m,beta);
  }
};

class RelativisticFermiIntegralInfinity {
  const double a,exponentZ,exponentE,m,beta;

 public:
  RelativisticFermiIntegralInfinity(const double a_, const double exponentZ_, const double exponentE_, const double m_, const double beta_):
    a(a_),exponentZ(exponentZ_),exponentE(exponentE_),m(m_),beta(beta_) {}

  double operator() (const double z1) {
    double z=1.0/z1;
    // here we need m0*c^2 but we have removed it from energy scale when we integrate
    double E = RelativisticEnergyFromZ(z,m,beta) + m*PC::cAU*PC::cAU;
    return z*z * pow(z,exponentZ)*pow(E,exponentE)*RelativisticFermiDiracOccupation(z,a,m,beta);
  }
};

double CalculateRelativisticFermiIntegral(const double a, const double exponentZ, const double exponentE, const double m, const double beta) {
  RelativisticFermiIntegral fi1(a,exponentZ,exponentE,m,beta);
  GKIntegration<RelativisticFermiIntegral,GK15> fii1(fi1,"Relativistic Fermi integral I");
  fii1.SetRelativeErrorMode();
  double f1 = fii1.Integrate(0.0,1.0,1e-12);

  RelativisticFermiIntegralInfinity fi2(a,exponentZ,exponentE,m,beta);
  GKIntegration<RelativisticFermiIntegralInfinity,GK15> fii2(fi2,"Relativistic Fermi integral II");
  fii2.SetRelativeErrorMode();
  double f2 = fii2.Integrate(0.0,1.0,1e-12);
  
  return f1+f2;
}

inline double CC(const double lambda, const double beta) {
  return 4.0*pi*pi*pow(lambda*beta,3.0/2.0);
}

class FindMuRelativisticFermiGas {
  const double lambda,m,beta,ne,g,cc; // derive mass, m, in AU from lambda=hbar^2/2m -> m = hbar^2/2lambda

public:
  FindMuRelativisticFermiGas(const double lambda_, const double beta_, const double ne_, const double g_):
    lambda(lambda_),m(0.5/lambda),beta(beta_),ne(ne_),g(g_),cc(CC(lambda,beta)) {}

  double operator()(const double a) const {
    double diff = ne/g * cc - CalculateRelativisticFermiIntegral(a,0.5,0.0,m,beta);
    //    Write2(a,diff);
    return diff;
  }
};

double MuRelativisticFermiGas(const double lambda, const double beta, const double ne, const double g) {
  FindMuRelativisticFermiGas fmfg(lambda,beta,ne,g);

  double betaMu = FindRootRegulaFalsi(5.0,10.0,1e-8,fmfg);
  double mu = betaMu/beta;
  return mu;
}

// pass in lambda instead m to keep it compatiblem PressureFermiGas() to avoid misunstanding later
// U per particle
double EnergyRelativisticFermiGas(const double lambda, const double beta, const double ne, const double g) {
  double m = 0.5/lambda;
  double mu = MuRelativisticFermiGas(lambda,beta,ne,g);
  //  Write(mu);

  double fi120 = CalculateRelativisticFermiIntegral(beta*mu,1.0/2.0,0.0,m,beta); 
  //  Write2(mu,fi12);

  double c = CC(lambda,beta);
  double ne2 = g/c * fi120;
  //  Write4(mu, fi120, ne, g/c * fi120);
  if (fabs(ne-ne2)>1e-8*ne)
    error("Problem with Fermi integrals");

  double fi121 = CalculateRelativisticFermiIntegral(beta*mu,1.0/2.0,1.0,m,beta); // no longer 3/2
  //  Write3(mu,fi12,fi32);

  //   Write(g*fi120 / (c*ne)); // should be exact 1
  double E = g*fi121 / (c*ne) - m*PC::cAU*PC::cAU;  // subtract m0*c^2 back out since we removed it from our zero of energy 

  return E;
}

// pass in lmabda instead m to keep it compatiblem PressureFermiGas() to avoid misunstanding later
double PressureRelativisticFermiGas(const double lambda, const double beta, const double ne, const double g) {
  // 3 PV = 2 E_kin  <<<<<<<<<<< no longer correct
  // In the extreme relativistic limit, we find 3 PV = 1 E_kin because E=p*c instead of E=p^2/2m
  //  double P = 2.0/3.0 * EnergyFermiGas(lambda,beta,ne,g) * ne;
  
  double m = 0.5/lambda;
  double mu = MuRelativisticFermiGas(lambda,beta,ne,g);
  //  Write(mu);

  double fi120  = CalculateRelativisticFermiIntegral(beta*mu,1.0/2.0,0.0,m,beta); 
  //  Write2(mu,fi12);

  // we want g/c*fi12/ne = 1.0
  // we want 1/c*fi12    = N_e / V / g
  double c = CC(lambda,beta);
  double ne2 = g/c * fi120;
  //  Write4(mu, fi120, ne, g/c * fi120);
  if (fabs(ne-ne2)>1e-8*ne)
    error("Problem with Fermi integrals");

  //  Write3(mu,fi12,fi32);
  //  Write(g*fi120 / (c*ne)); // should be exact 1

  double fi32M1 = CalculateRelativisticFermiIntegral(beta*mu,3.0/2.0,-1.0,m,beta);

  //  double P = PC::cAU*PC::cAU*ne/3.0 * 2.0*m * g*fi32M1 / (c*beta*ne);
  //  double P = PC::cAU*PC::cAU*ne/3.0 * 2.0*m/beta * g*fi32M1 / (c*ne);
  double P = PC::cAU*PC::cAU*ne/3.0 * 2.0*m/beta * g*fi32M1 / (c*ne);
  //  Write3(mu,fi12,fi32);

  return P;
}

/////////////////////////////////////////////////////////////////////////////////////

/*
int main() {
  cout.precision(8);
  const double AUToK = 315774.660873;     // old and wrong 315774.9076860828;
  const double AUToA = 0.529177208607388; // old and wrong 0.52917679499658208;
  const double AUToM = AUToA*1e-10;
  const double UToAU = 1.66053873e-27 / 9.10938188e-31; // nuclear mass unit 'u' / mass pf electron

  // electrons
  double m      = 1.0;
  double g      = 2.0;

  // protons
  //  m      = 1836.152786976163; // p/me
  //  g      = 2.0; // spin state should not matter, only add constant to free energy
  //  g = 1.0; // compare with Hugh

  // helium atoms
  //  m      = 4.00260*UToAU;
  //  g      = 2.0;

  // neon atoms
  //  m      = 20.1797*UToAU;
  //  g      = 1.0;
  //  g      = 2.0;

  // argon atoms
  //  m      = 39.948*UToAU;
  //  g      = 2.0;

  double lambda = 0.5/m;
  //  double TinK   =  125000.0;
  //  double TinK   = 1250000.000;
  //  double TinK   = 10000.000;
  //  double TinK   = 5000.000;
  //  double T      = TinK / AUToK;
  double T = 1.0/0.0010375984; // Kevin value at 304332275K
  double TinK = T*AUToK;

  double beta   = 1.0 / T;

  Write3(m,TinK,LambdaDeBroglieMassTemperature(m,T));

  //  int N = 110; // this number should not matter below if rs is kept constant
  //  int N = 64; // this number should not matter below if rs is kept constant
  //  int N = 1; // this number should not matter below if rs is kept constant
  int N = 8*6;

  double rs = 0.5441299520956544;
  //  double rs = 0.9;
  //  double rs = 1.1;
  //  double rs = 1.86;

  double L = rs*pow(4.0/3.0*pi*N , 1.0/3.0);

  // Comment section out to start with density in cm^-3
  //  double nPercc = 9.01631e+23; // particles per cm^3
  //  //  double nPercc = 1.82389e+24; // particles per cm^3
  //  double nPerM3 = nPercc*1e6;
  //  double nAU    = nPerM3*AUToM*AUToM*AUToM;
  //  rs = pow(3.0/(4.0*pi*nAU),1.0/3.0);

  //  L = 9.74871962;
  //  L = 11.74275818937414587033; // Hugh H runs
  //  L = 11.05111842476021967327; // Hugh He runs
  //  L = 11.63426901208; // Hugh's H128 run at 220 GPa
  //  L = 11.7630916425 ; // Hugh's H128+Ne1 run at 220 GPa
  //  L = 11.79820275   ;   // Hugh's H128+Ar1 run at 220 GPa
  //  L = 10.9358073361 ; // Hugh's He64 run at 220 GPa
  //  L = 11.0509105549 ; // Hugh's He64+Ne1 run at 220 GPa
  //  L = 11.1311861210 ; // Hugh's He64+Ar1 run at 220 GPa
  //  L = 8.9363207;
  L = 6.365627; // Kevin's Carbon run at 1Mbar
  rs = L / pow(4.0/3.0*pi*N , 1.0/3.0);

  double V = L*L*L;
  double nn= double(N)/V;
  double V1= V/double(N);
  Write6(rs,TinK,V,nn,V1,m);

  double EF = FermiEnergy(lambda,nn,g);
  cout << endl;
  cout << "Check Fermi degeneracy (electron gas only, no ions, all in AU per electron]:" << endl;
  Write3(T,EF,T/EF);
  double E0 = 3.0/5.0*EF; // T=0 limit of energy of Fermi gas
  cout << " E(T->0) = " << E0 << endl << endl;

  double mu = MuFermiGas(lambda,beta,nn,g); // mu < EF, mu(T->0)=EF
  if (TinK==125000.0) Write2("0.224743",mu);
  cout << " Check mu<EF: ";
  Write2(mu,mu/EF);
  cout << endl;

  double P      = PressureFermiGas(lambda,beta,nn,g);
  double PBoltz = PressureBoltzmannGas(beta,nn);
  cout << " Check P>PBoltz: "; 
  Write4(T/EF,P,PBoltz,P/PBoltz);
  cout << endl;

  double E = EnergyFermiGas(lambda,beta,nn,g);
  double EBoltz = EnergyBoltzmannGas(beta);
  if (TinK==125000.0) Write2("0.714316",E);
  cout << " Compare energies: "; 
  Write4(E,EBoltz,E/EBoltz,E0);

  cout << endl;

  double F = FreeEnergyFermiGas(lambda,beta,nn,g);
  double TS = E - F;
  double S  = TS/T;
  //  Write2(F,-2.0/3.0*E+mu); 
  Write4(F,E,TS,S); // F = E-TS < E   ,   F(T->0) = E
  cout << " Fermi entropy in AU = 1/kb : "; Write(S);
  cout << " Fermi entropy in Ha/kb     : "; Write(S/AUToK);
  cout << endl;

  double FBoltz = FreeEnergyBoltzmannGas(lambda,beta,nn,g);
  double TSBoltz = EBoltz - FBoltz;
  double SBoltz  = TSBoltz/T;
  double PVBoltz = PBoltz*V1;
  double GBoltz  = FBoltz+PVBoltz;

  Write4(FBoltz,EBoltz,TSBoltz,SBoltz);
  Write3(GBoltz,FBoltz,PVBoltz);
  Write4(FBoltz*N,EBoltz*N,TSBoltz*N,SBoltz*N);
  Quit("F0");
  Write3(GBoltz*N,FBoltz*N,PVBoltz*N);
  cout << " Note that SBoltz can go negative for small T." << endl;
  cout << " Boltzmann entropy in AU = 1/kb : "; Write(SBoltz);
  cout << " Boltzmann entropy in Ha/kb     : "; Write(SBoltz/AUToK);
  cout << endl;

  cout << " Check E = d(F*beta)/d beta" << endl;
  double dBeta = 1e-6*beta;
  double beta1 = beta+dBeta;
  double F1 = FreeEnergyFermiGas(lambda,beta1,nn,g);
  double EE = (F1*beta1-F*beta)/dBeta;
  Write4(T/EF,EF,E,EE);

  double FB1 = FreeEnergyBoltzmannGas(lambda,beta1,nn,g);
  double EEB = (FB1*beta1-FBoltz*beta)/dBeta;
  Write2(EBoltz,EEB);
}
*/
