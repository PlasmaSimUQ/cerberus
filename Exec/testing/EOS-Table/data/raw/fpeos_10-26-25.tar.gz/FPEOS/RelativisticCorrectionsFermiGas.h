/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// Relatisitic Ideal Fermi gas in 3D                                       // 
//                                                                         //
// Burkhard Militzer                                  Berkeley, 11-11-15   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////

#ifndef _RELATIVISTICCORRECTIONSFERMIGAS_
#define _RELATIVISTICCORRECTIONSFERMIGAS_

#include "FermiGas.h"
#include "RelativisticFermiGas.h"

inline double RelativisticEnergyCorrectionFermiGas(const double lambda, const double beta, const double ne, const double g) {
  double ENonrelativistic = EnergyFermiGas(lambda,beta,ne,g);
  double ERelativistic    = EnergyRelativisticFermiGas(lambda,beta,ne,g);
  return ERelativistic - ENonrelativistic;
}

inline double RelativisticEnergyCorrectionElectrons(const double beta, const double ne) {
  return RelativisticEnergyCorrectionFermiGas(0.5,beta,ne,2.0);
}

// so far, this was always extremely small
inline double RelativisticPressureCorrectionFermiGas(const double lambda, const double beta, const double ne, const double g) {
  double PNonrelativistic = PressureFermiGas(lambda,beta,ne,g);
  double PRelativistic    = PressureRelativisticFermiGas(lambda,beta,ne,g);
  return PRelativistic - PNonrelativistic;
}

inline double RelativisticPressureCorrectionElectrons(const double beta, const double ne) {
  return RelativisticPressureCorrectionFermiGas(0.5,beta,ne,2.0);
}

// not sure if good for anything
inline double RelativisticMuCorrectionFermiGas(const double lambda, const double beta, const double ne, const double g) {
  double muNonrelativistic = MuFermiGas(lambda,beta,ne,g);
  double muRelativistic    = MuRelativisticFermiGas(lambda,beta,ne,g);
  return muRelativistic - muNonrelativistic;
  
}

#endif // _RELATIVISTICCORRECTIONSFERMIGAS_

