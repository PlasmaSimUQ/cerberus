////////////////////////////////////////////////////////////////////////////
//                                                                         //
// EOS table class                                                         // 
// assume EOS is given on a density grid but the temperatures vary with rho//
//                                                                         //
// Burkhard Militzer                                  Livermore 2-26-03    //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////

#ifndef _EOSTABLEDIFFT_
#define _EOSTABLEDIFFT_

#include <algorithm>
#include "Array.h"
#include "Physics.h"
#include "Spline.h"
#include "Vector.h"
#include "Function.h"
#include "Elements.h"
#include "Form.h"

template <class T>
inline void Sort(Array1 <T> & a) { // is slow but it works
  Vector <T> vv(a.Size());
  for(int i=0; i<a.Size(); i++) {
    vv[i] = a[i];
  }
  std::sort(vv.begin(),vv.end());
  for(int i=0; i<a.Size(); i++) {
    a[i] = vv[i];
  }
}

class EOSTableDiffT {
  Spline eLast;
  double eTTLast; // initialized in PutIn1DArrays()
  Spline pLast;
  double pTTLast; // initialized in PutIn1DArrays()

  public:
  int n;
  bool wiggleFlag,errorBars,errorBarsT;
  // contains a list of all "nn" occuring in the dataset stored below
  Array1 <double> tnn;
  // contains a list of all "T" occuring in the dataset stored below
  Array1 <double> tT; // not set by default - must call SetUpTemperatureArray()
  // one element corresponds to one element of the following arrays

  Array1 <double> nn; // now density of formula units (e.g. SiO2) since ee will also be per FU (nn was density of electrons earlier)
  Array1 <double> T;
  Array1 <double> TE; // error bars
  Array1 <double> pp;
  Array1 <double> pE; // error bars
  Array1 <double> ee;
  Array1 <double> eE; // error bars
 private:
 public:
  Array1 <Array1 <int> > lists; // index for the 1D Array above index[iDensity][iTemp]

  // Set true for free energy fitting because T and V derivates are needed at boundaries
  // Otherwise set to false so that larger range extrapolations can be done reliably.
  static const bool splineExtraplolationFlag = true; 
  //  static const bool splineExtraplolationFlag = false; 

  //  static const double alpha; // leave it set to +1.0
  //  Power2Function argnn;
  //  LogFunction argnn; // splines as function of log(nn) worked better for He since ideal high T limits is included
  Function argnn;   // splines as function of nn work so far to DFT-MD H-He

  //  Function argT;    // splines as function of T, not log(T) worked better 1-29-08
  //  LogFunction argT; // needed for radiation correction I
  GeneralFunction argT; // linear interpolate initially but can be changed during executation (is slower)

  //  Function argF; // only used for E and P in Interpolation1D()
  //  LogFunction argF; // needed for radiation correction II
  GeneralFunction argF; // linear interpolate initially but can be changed during executation (is slower)

  Array1 <double> ZChargeFU; // number of positive charged of fully ionized ions of type 'i'
  Array1 <double> NChargeFU; // number of ions of type 'i'. Sum equals nFU below

  bool hugoniotFlag;
  double hugoniotE0;
  double hugoniotP0;
  double hugoniotnn0;

  Array1 <string> reference;
  int databaseIndex;

 public:
  EOSTableDiffT():wiggleFlag(false),errorBarsT(false),hugoniotFlag(false),databaseIndex(-1) {}
  void ReadTableInStandardFormat(const string & fileName, const double nFU, const double mFU);
   void ConvertEnergiesFromeVToHa() {
    ee *= PC::eVToAU;
    eE *= PC::eVToAU;
  }
  void PrintFileStatement(const string & filename, const bool open) const;
  void PrintFileOpeningStatement(const string & filename) const {
    PrintFileStatement(filename,true);
  }
  void PrintFileClosingStatement(const string & filename) const {
    PrintFileStatement(filename,false);
  }

  void Print() const;
  void PrintOnePoint(ostream & of, const int i, const bool printEOS=true) const;
  void PrintOnePoint(ostream & of, const int inn, const int iT, const bool printEOS=true) const {
    int i = lists[inn][iT];
    PrintOnePoint(of,i,printEOS);
  }
  void PrintOnePoint(const int i, const bool printEOS=true) const {
    PrintOnePoint(cout,i,printEOS);
  }
  void PrintOnePoint(const int inn, const int iT, const bool printEOS=true) const {
    int i = lists[inn][iT];
    PrintOnePoint(i,printEOS);
  }
  void PrintOnePoint(const double nnn, const double TT) const;
  void PrintOnePoint(ostream & of, const double nnn, const double TT) const;
  void PrintAllPoints() const;

  void WriteOnePointToFile(ofstream & of, const int i) const;
  void WriteOnePointToFile(ofstream & of, const int inn, const int iT) const {
    WriteOnePointToFile(of,lists[inn][iT]);
  }
  void WriteAllPointsToFile(ofstream & of) const;
  void WriteAllPointsToFile(const string & fileName) const {
    ofstream of(fileName.c_str());
    if (!of) error("Could not open file",fileName);
    WriteAllPointsToFile(of);
  }

  double Energy(const double nnn, const double TT) const {
    return Interpolate2D(nnn,TT,ee);
  }
  double E(const double nnn, const double TT) const { return Energy(nnn,TT); }
  double e(const double nnn, const double TT) const { return Energy(nnn,TT); }
  double EnergyFast(const double nnn, const double TT) { // much faster but not a "const" function
    return Interpolate2D(nnn,TT,ee,eTTLast,eLast);
  }

  double Pressure(const double nnn, const double TT) const {
    // #define INTERPOLATE_PV
#ifdef INTERPOLATE_PV
    return nnn*Interpolate2D(nnn,TT,pp);
#else 
    return Interpolate2D(nnn,TT,pp);
#endif
  }
  double P(const double nnn, const double TT) const { return Pressure(nnn,TT); }
  double p(const double nnn, const double TT) const { return Pressure(nnn,TT); }
  double PressureFast(const double nnn, const double TT) { // much faster but not a "const" function
    // #define INTERPOLATE_PV
#ifdef INTERPOLATE_PV
    return nnn*Interpolate2D(nnn,TT,pp,pTTLast,pLast);
#else 
    return Interpolate2D(nnn,TT,pp,pTTLast,pLast);
#endif
  }

  double Enthalpy(const double nnn, const double TT) const {
    double E = Energy(nnn,TT);
    double P = Pressure(nnn,TT);
    double V = 1.0/nnn;
    double H = E+P*V;
    return H;
  }
  double H(const double nnn, const double TT) const {
    return Enthalpy(nnn,TT);
  }

  double TemperatureGivenDensityAndPressure(const double nnn, const double PP, 
					    const double T1, const double T2, const double eps=1e-8) const;

  double PressureTemperatureDerivative(const double nn, const double T, const double eps=1e-6) const;
  double EnergyTemperatureDerivative(const double nn, const double T, const double eps=1e-6) const;
  double EntropyTemperatureDerivative(const double nn, const double T, const double eps=1e-6) const;
  double PressureDensityDerivative(const double nn, const double T, const double eps=1e-6) const;
  double PressureDensitySecondDerivative(const double nn, const double T, const double eps=1e-2) const;
  double PressureVolumeDerivative(const double nn, const double T, const double eps=1e-6) const {
    //    return -1.0/nn/nn*PressureDensityDerivative(nn,T,eps); // bug found 1/23/16
    return -nn*nn*PressureDensityDerivative(nn,T,eps);
    // dP/dV = dP/dnn dnn/dV = dP/dnn d(1/V)/dV = -1/V/V * dP/dnn = -nn^2 dP/dnn
  }
  // isothermal Bulk modulus K_T = -V*dP/dV = -1/nn * dP/dnn dnn/dV = -1/nn *dP/dnn (-1/V/V) = +nn*dP/dnn
  double IsothermalBulkModulus(const double nn, const double T, const double eps=1e-6) const {
    return nn*PressureDensityDerivative(nn,T,eps);
  }

  double EnergyDensityDerivative(const double nn, const double T, const double eps=1e-6) const;
  double EnergyVolumeDerivative(const double nn, const double T, const double eps=1e-6) const {
    return -nn*nn*EnergyDensityDerivative(nn,T,eps); // bug found 1/23/16
  }
  double EntropyDensityDerivative(const double nn, const double T, const double eps=1e-6) const;
  double EntropyVolumeDerivative(const double nn, const double T, const double eps=1e-6) const {
    return EntropyDensityDerivative(nn,T,eps)*(-nn*nn);
    //    return EntropyDensityDerivative(nn,T,eps)*nn;
  }
  double PressureDensityDerivativeConstantEnergy(const double nn, const double T, const double eps=1e-6) const;

  double Hugoniot(const double nn1, const double T1) const { // E0,P0,nn0 are stored in Physics.h!!!
    const double E1=E(nn1,T1);
    const double P1=P(nn1,T1);
    const double hug = HugoniotFunction(E1,P1,nn1);
    //  Write5(nn1,T1,e1,p1,hug);
    return hug;
  }
  void SetInitialConditionsOfHugoniotCurve(const double E0, const double P0, const double nn0) {
    hugoniotFlag = true;
    hugoniotE0 = E0;
    hugoniotP0 = P0;
    hugoniotnn0 = nn0;
  }
  void OverwriteHugoniotnn0(const double nn0) {
    hugoniotnn0 = nn0;
  }
  void OverwriteHugoniotRho0GCC(const double rho0) {
    cout << "Setting a new Hugoniot rho0[g/cc]= " << rho0 << endl;
    OverwriteHugoniotnn0(NumberDensityFromMassDensityGCC(rho0));
  }
  void OverwriteHugoniotE0(const double E0) {
    cout << "Setting a new Hugoniot E0[Ha]= " << E0 << endl;
    hugoniotE0 = E0;
  }
  void ExtractHugoniotDataFromFile(const string & fileName);
  bool GetHugoniotFlag() const {
    return hugoniotFlag;
  }
  double GetHugoniotE0() const {
    if (!hugoniotFlag) error("Hugoniot initial conditions were not set.");
    return hugoniotE0;
  }
  double GetHugoniotP0() const {
    if (!hugoniotFlag) error("Hugoniot initial conditions were not set.");
    return hugoniotP0;
  }
  double GetHugoniotnn0() const {
    if (!hugoniotFlag) error("Hugoniot initial conditions were not set.");
    return hugoniotnn0;
  }

  Array1 <double> GetListOfAllTemperatures() const {
    Array1 <double> TT;
    for(int i=0; i<n; i++) {
      if (TT.Find(T[i])==notFound) TT.PushBack(T[i]);
    }
    Sort(TT);
    return TT;
  }

  void Check();

  int GetNumberOfDensities() const {
    return tnn.Size();
  }
  int GetNumberOfTemperatures(const int inn) const {
    return lists[inn].Size();
  }
  int GetNumber() const {
    return n;
  }
  void GetDataPoint(const int i, double & nn1, double & T1) const {
    nn1 = nn[i];
    T1  = T[i];
  }
  double GetDensityPoint(const int inn) const {
    return tnn[inn];
  }
  double GetVolumePoint(const int inn) const {
    return 1.0/tnn[inn];
  }
  double GetMinimumDensity() const {
    return tnn.First();
  }
  double GetMaximumDensity() const {
    return tnn.Last();
  }
  double GetTemperaturePoint(const int inn, const int iT) const {
    return T[lists[inn][iT]];
  }
  double GetPressurePoint(const int inn, const int iT) const {
    return pp[lists[inn][iT]];
  }
  double GetEnergyPoint(const int inn, const int iT) const {
    return ee[lists[inn][iT]];
  }
  void SetPressurePoint(const int inn, const int iT, const double P) {
    pp[lists[inn][iT]] = P;
  }
  void SetEnergyPoint(const int inn, const int iT, const double E) {
    ee[lists[inn][iT]] = E;
  }
  double GetPressureErrorBarPoint(const int inn, const int iT) const {
    return pE[lists[inn][iT]];
  }
  double GetEnergyErrorBarPoint(const int inn, const int iT) const {
    return eE[lists[inn][iT]];
  }
  void FindClosestDataPoint(const double nn, const double TT, int & inn, int & iT, const bool inside=false) const {
    inn = FindClosestDensity(nn,inside);
    iT  = FindClosestTemperatureFixedDensity(inn,TT,inside);
  }
  int FindClosestDataPoint(const double nn, const double TT, const bool inside=false) const {
    int inn, iT;
    FindClosestDataPoint(nn,TT,inn,iT,inside);
    return lists[inn][iT];
  }
  bool IsDataPoint(const double nnn, const double TT, int & inn, int & iT, const double eps=1e-8) const {
    inn = FindClosestDensity(nnn,false);
    iT  = FindClosestTemperatureFixedDensity(inn,TT,false);
    int ii = lists[inn][iT];
    double dnn = fabs(nn[ii]-nnn);
    double dT  = fabs(T[ii]-TT);
    return ((dnn<eps*nnn) && (dT<eps*TT));
  }
  // no real error propagation done
  double PressureErrorBar(const double nn, const double TT) const {
    int ii = FindClosestDataPoint(nn,TT);
    double PClosest  = pp[ii];
    double PEClosest = pE[ii];
    double P = Pressure(nn,TT);
    return P * PEClosest/PClosest;
  }
  // no real error propagation done
  double EnergyErrorBar(const double nn, const double TT) const {
    int ii = FindClosestDataPoint(nn,TT);
    double EEClosest = eE[ii];
    return EEClosest;
  }

  int FindClosestDensity(const double nn, const bool inside=false) const {
    if (inside && (nn<tnn.First() || nn>tnn.Last()))
      error("Density outside range",nn,tnn.First(),tnn.Last());
    int iMin=0;
    double dMin=fabs(tnn[0]-nn);
    for(int i=1; i<tnn.Size(); i++) {
      double d=fabs(tnn[i]-nn);
      if (d<dMin) { dMin=d; iMin=i; }
    }
    return iMin;
  }
  void FindBracketingDensityIndices(const double nn, int & inn1, int & inn2) const {
    inn1 = FindClosestDensity(nn,false);
    if (inn1>0 && (inn1==GetNumberOfDensities()-1 || tnn[inn1]>nn)) inn1--; // if you above then switch to one lower index
    inn2 = inn1+1;
  }
  int FindClosestTemperatureFixedDensity(const int inn, const double TT, const bool inside=false) const {
    if (inside && (TT<T[lists[inn].First()] || TT>T[lists[inn].Last()]))
      error("Temp not inside table for this density",TT,T[lists[inn].First()],T[lists[inn].Last()]);
    int iMin=0;
    double dMin=fabs(T[lists[inn].First()]-TT);
    for(int i=1; i<lists[inn].Size(); i++) {
      double d=fabs(T[lists[inn][i]]-TT);
      if (d<dMin) { dMin=d; iMin=i; }
    }
    return iMin; // remember there is no uniform T grid
  }

  // return adjacent density indices i1 and i2
  void GetMinMaxIndices(const double nn, int & i1, int & i2) const { 
    i1 = FindClosestDensity(nn);
    if (i1==0) {
      i2=1;
    } else if (i1==tnn.Size()-1) {
      i2=tnn.Size()-2;
    } else {
      i2 = (nn>tnn[i1]) ? i1+1 : i1-1;
    }
  }
  double GetMinimumTemperature(const int inn) const { // for one density
    return T[lists[inn].First()];
  }
  double GetMinimumTemperature() const {
    return T.Min(); // could be made faster
  }
  double GetMaximumTemperature(const int inn) const {
    return T[lists[inn].Last()];
  }
  double GetMaximumTemperature() const {
    return T.Max(); // could be made faster
  }
  double GetMinimumTemperature(const double nnn) const { // for given density
    int i1,i2;
    GetMinMaxIndices(nnn,i1,i2);
    return max(T[lists[i1].First()],T[lists[i2].First()]);
  }
  double GetMaximumTemperature(const double nnn) const { // for given density
    int i1,i2;
    GetMinMaxIndices(nnn,i1,i2);
    return min(T[lists[i1].Last()],T[lists[i2].Last()]);
  }
  double GetMinimumPressure(const double nnn) const { // for given density
    double TT = GetMinimumTemperature(nnn);
    return Pressure(nnn,TT);
  }
  double GetMaximumPressure(const double nnn) const { // for given density
    double TT = GetMaximumTemperature(nnn);
    return Pressure(nnn,TT);
  }

  int MinimumDensityIndexForTemperature(const double TT, const bool strict=true, const double eps=1e-10) const {
    int inn=0;
    for(;;) {
      //      cout << "Min:"; 
      //      Write3(inn,T[lists[inn].First()]*PC::AUToK,T[lists[inn].Last()]*PC::AUToK);
      if (T[lists[inn].First()]<=TT*(1.0+eps) && TT*(1.0-eps)<=T[lists[inn].Last()]) break;
      inn++;
      if (inn==tnn.Size()) {
	if (strict) error("No density found for which T is included in table (+)",name,TT*PC::AUToK);
	return notFound;
      }
    }
    return inn;
  }
  double MinimumDensityForTemperature(const double TT, const double eps=1e-10) const {
    //    int inn = MinimumDensityIndexForTemperature(TT,true,eps);
    //    if (inn==notFound) error(name+": Could not determine minimum density for this temperature: "+DoubleToString(TT*PC::AUToK));
    return tnn[MinimumDensityIndexForTemperature(TT,true,eps)];
  }
  int MaximumDensityIndexForTemperature(const double TT, const double strict=true, const double eps=1e-10) const {
    int inn=tnn.Size()-1;
    for(;;) {
      //      cout << "Max:"; 
      //      Write3(inn,T[lists[inn].First()]*PC::AUToK,T[lists[inn].Last()]*PC::AUToK);
      if (T[lists[inn].First()]<=TT*(1.0+eps) && TT*(1.0-eps)<=T[lists[inn].Last()]) break;
      inn--;
      if (inn<0) {
	if (strict) error("No density found for which T is included in table (-)",name,TT*PC::AUToK);
	return notFound;
      }
    }
    return inn;
  }
  double MaximumDensityForTemperature(const double TT, const double eps=1e-10) const {
    //    int inn = MaximumDensityIndexForTemperature(TT,true,eps);
    //    if (inn==notFound) error(name+": Could not determine maximum density for this temperature: "+DoubleToString(TT*PC::AUToK));
    return tnn[MaximumDensityIndexForTemperature(TT,true,eps)];
  }

  double MinimumPressureForTemperature(const double TT, const double eps=1e-10) const {
    double nnn = MinimumDensityForTemperature(TT,eps); // assume dP/drho>0 
    return Pressure(nnn,TT);
  }
  double MaximumPressureForTemperature(const double TT, const double eps=1e-10) const {
    double nnn = MaximumDensityForTemperature(TT,eps); // assume dP/drho>0 
    return Pressure(nnn,TT);
  }
  void PrintMinimumMaximumPressureForTemperature(const double TT) const {
    double PMin = MinimumPressureForTemperature(TT);
    double PMax = MaximumPressureForTemperature(TT);
    cout << " " << name << " " ; Write2(PMin*PC::AUToGPa,PMax*PC::AUToGPa);
  }

  int HighestTemperatureDensityIndexJustBelowCertainPressure(const double PP, const double eps=1e-10) const {
    int index=notFound;
    for(int inn=0; inn<tnn.Size(); inn++) {
      int iT = lists[inn].Size()-1; // highest T index
      double P = GetPressurePoint(inn,iT);
      if (P*(1.0-eps)<PP) index=inn;
    }
    return index;
  }
  double HighestTemperatureJustBelowCertainPressure(const double PP, const double eps=1e-10) const {
    int inn = HighestTemperatureDensityIndexJustBelowCertainPressure(PP,eps);
    return T[lists[inn].Last()];
  }
  int HighestTemperatureDensityIndexJustAboveCertainPressure(const double PP, const double eps=1e-10) const {
    int index=notFound;
    for(int inn=tnn.Size()-1; inn>=0; inn--) {
      int iT = lists[inn].Size()-1; // highest T index
      double P = GetPressurePoint(inn,iT);
      if (P*(1.0+eps)>PP) index=inn;
    }
    return index;
  }
  double HighestTemperatureJustAboveCertainPressure(const double PP, const double eps=1e-10) const {
    int inn = HighestTemperatureDensityIndexJustAboveCertainPressure(PP,eps);
    return T[lists[inn].Last()];
  }
  int LowestTemperatureDensityIndexJustBelowCertainPressure(const double PP, const double eps=1e-10) const {
    int index=notFound;
    for(int inn=0; inn<tnn.Size(); inn++) {
      int iT = 0; // lists[inn].First(); // lowest T index
      double P = GetPressurePoint(inn,iT);
      if (P*(1.0-eps)<PP) index=inn;
    }
    return index;
  }
  double LowestTemperatureJustBelowCertainPressure(const double PP, const double eps=1e-10) const {
    int inn = LowestTemperatureDensityIndexJustBelowCertainPressure(PP,eps);
    return T[lists[inn].First()];
  }
  int LowestTemperatureDensityIndexJustAboveCertainPressure(const double PP, const double eps=1e-10) const {
    int index=notFound;
    for(int inn=tnn.Size()-1; inn>=0; inn--) {
      int iT = 0; // lists[inn].First(); // lowest T index
      double P = GetPressurePoint(inn,iT);
      if (P*(1.0+eps)>PP) index=inn;
    }
    return index;
  }
  double LowestTemperatureJustAboveCertainPressure(const double PP, const double eps=1e-10) const {
    int inn = LowestTemperatureDensityIndexJustAboveCertainPressure(PP,eps);
    return T[lists[inn].First()];
  }

  bool PointInside(const double nnn, const double TT, const int strict=false, const double eps=1e-10) const {
    if (TT*(1.0-eps)>GetMaximumTemperature()) return false;
    if (TT*(1.0+eps)<GetMinimumTemperature()) return false;
    double nnMin = MinimumDensityForTemperature(TT,eps);
    double nnMax = MaximumDensityForTemperature(TT,eps);
    if (nnn<nnMin*(1.0-eps)) return false;
    if (nnn>nnMax*(1.0+eps)) return false;
    if (!strict) return true;

    int inn1,inn2;
    FindBracketingDensityIndices(nnn,inn1,inn2);
    Write2(inn1,inn2);
    if (TT*(1.0+eps)<GetMinimumTemperature(inn1)) return false;
    if (TT*(1.0-eps)>GetMaximumTemperature(inn1)) return false;
    if (TT*(1.0+eps)<GetMinimumTemperature(inn2)) return false;
    if (TT*(1.0-eps)>GetMaximumTemperature(inn2)) return false;
    return true;
  }

  bool TemperaturePressurePointInside(const double TT, const double PP) const {
    double TMin = GetMinimumTemperature();
    double TMax = GetMaximumTemperature();
    if (TT<TMin) return false;
    if (TT>TMax) return false;

    double PMin = MinimumPressureForTemperature(TT);
    double PMax = MaximumPressureForTemperature(TT);
    if (PP<PMin) return false;
    if (PP>PMax) return false;
    
    return true;
  }

  Array1 <int> DetermineConvexHull(const double eps=1e-10) const;
  void PrintConvexHull(const string name, const double eps=1e-10) const {
    Array1 <int> ch = DetermineConvexHull(eps);
    for(int i=0; i<ch.Size(); i++) {
      cout << "Convex_hull_" << name;
      PrintOnePoint(ch[i],false);
    }
  }
  void PrintConvexHull(const double eps=1e-10) const {
    PrintConvexHull(name,eps);
  }

  string GetName() const {
    return name;
  }
  void SetName(const string & s) {
    name=s;
  }
 public:
  string name;
  double mFU; // mass in AU per formula unit
  double nFU; // number of atoms per formula unit

 public:

  void SetChargesFormulaUnit(const string & type, const double N) {
    SetChargesFormulaUnit(ChargeNumberFromName(type),N);
  }
  void SetChargesFormulaUnit(const string & type1, const double N1, const string & type2, const double N2) {
    SetChargesFormulaUnit(ChargeNumberFromName(type1),N1,ChargeNumberFromName(type2),N2);
  }
  void SetChargesFormulaUnit(const string & type1, const double N1, 
			     const string & type2, const double N2, 
			     const string & type3, const double N3) {
    SetChargesFormulaUnit(ChargeNumberFromName(type1),N1,ChargeNumberFromName(type2),N2,ChargeNumberFromName(type3),N3);
  }
  void SetChargesFormulaUnit(const int Z, const double N) {
    ZChargeFU.Resize(1);
    NChargeFU.Resize(1);
    ZChargeFU[0]=Z;
    NChargeFU[0]=N;
    if (N!=nFU) error("N!=nFU");
  }
  void SetChargesFormulaUnit(const int Z1, const double N1, const int Z2, const double N2) {
    ZChargeFU.Resize(2);
    NChargeFU.Resize(2);
    ZChargeFU[0]=Z1;
    NChargeFU[0]=N1;
    ZChargeFU[1]=Z2;
    NChargeFU[1]=N2;
    if (fabs(N1+N2-nFU)>1e-8) error("N1+N2!=nFU",N1,N2,nFU);
  }
  void SetChargesFormulaUnit(const int Z1, const double N1, const int Z2, const double N2, const int Z3, const double N3) {
    ZChargeFU.Resize(3);
    NChargeFU.Resize(3);
    ZChargeFU[0]=Z1;
    NChargeFU[0]=N1;
    ZChargeFU[1]=Z2;
    NChargeFU[1]=N2;
    ZChargeFU[2]=Z3;
    NChargeFU[2]=N3;
    if (fabs(N1+N2+N3-nFU)>1e-8) error("N1+N2+N3!=nFU",N1,N2,N3,nFU);
  }
  void SetChargesFormulaUnit(const Array1 <double> & ZChargeFU_, const Array1 <double> & NChargeFU_) {
    ZChargeFU = ZChargeFU_;
    NChargeFU = NChargeFU_;
    if (fabs(NChargeFU.Sum()-nFU)>1e-8) error("NChargeFU.Sum()!=nFU",NChargeFU,nFU);
  }
  void SetChargesFormulaUnit(const Array1 <string> & type, const Array1 <double> & NChargeFU_) {
    NChargeFU = NChargeFU_;
    ZChargeFU.Resize(type.Size());
    for(int i=0; i<type.Size(); i++) {
      ZChargeFU[i] = ChargeNumberFromName(type[i]);
    }
    if (fabs(NChargeFU.Sum()-nFU)>1e-8) error("NChargeFU.Sum()!=nFU",NChargeFU,nFU);
  }

  Array1 <double> GetZChargesFormulaUnit() const {
    return ZChargeFU;
  }
  Array1 <double> GetNChargesFormulaUnit() const {
    return NChargeFU;
  }
  double GetNElectronsFormulaUnit() const {
    double Ne = 0.0;
    for(int i=0; i<ZChargeFU.Size(); i++) {
      if (ZChargeFU[i] < +1.0) error("ZChargeFU[i] < +1",i,ZChargeFU[i]);
      Ne += NChargeFU[i]*ZChargeFU[i];
    }
    return Ne; // N_e = sum N_i * Z_i
  }
  double AverageIonicCharge() const {
    return GetNElectronsFormulaUnit() / nFU; 
  }

  void SetMassFormulaUnit(const double mFU_) {
    mFU = mFU_;
  }
  double GetMassFormulaUnit() const {
    return mFU;
  }
  void SetNAtomsFormulaUnit(const double nFU_) {
    nFU = nFU_;
  }
  double GetNAtomsFormulaUnit() const {
    return nFU;
  }
  double MassNAtoms(const double nAtoms) {
    return mFU * nAtoms / nFU;
  }
  double MassDensity(const double nn) const { // pass in density in FU per a0^3, return mass density in a.u. units (me/a0^3)
    return mFU*nn;
  };
  double MassDensity(const int inn) const {
    return MassDensity(GetDensityPoint(inn));
  };
  double MassDensitySI(const double nn) const {
    return MassDensity(nn)*PC::me/PC::ab/PC::ab/PC::ab;
  };
  double MassDensitySI(const int inn) const {
    return MassDensitySI(GetDensityPoint(inn));
  };
  double MassDensityGCC(const double nn) const {
    return MassDensitySI(nn)/1000.0;
  };
  double MassDensityGCC(const int inn) const {
    return MassDensityGCC(GetDensityPoint(inn));
  };

  double VolumeFromMassDensityGCC(const double rho2) const { // volume per formula unit in AU
    double V1  = 1.0;
    double nn1 = 1.0/V1;
    double rho1= MassDensityGCC(nn1);
    double V2 = V1 * rho1/rho2;
    return V2;
  }
  double VolumeInCCPerMolFUFromMassDensityGCC(const double rho2) const { // volume per formula unit in AU
    return VolumeFromMassDensityGCC(rho2) * PC::AUToA3 * 1e-30 * PC::NA * 1e6;
  }

  double NumberDensityFromMassDensityGCC(const double rho) const {
    return 1.0/VolumeFromMassDensityGCC(rho);
  }
  double MassDensityGCCFromVolume(const double V0) const { // pass in volume per formula unit
    return MassDensityGCC(1.0/V0);
  }

  bool DensityGivenTemperatureAndPressure(const double T, const double P, double & nn, const bool strict=true);
  double DensityGivenTemperatureAndPressure(const double T, const double P, const bool strict=true) {
    double nn;
    bool flag = DensityGivenTemperatureAndPressure(T,P,nn,strict);
    if (flag==false && strict) error("problem in DensityGivenTemperatureAndPressure()");
    return nn;
  }
  double MassDensityGivenTemperatureAndPressure(const double T, const double P, const bool strict=true) {
    double nn = DensityGivenTemperatureAndPressure(T,P,strict);
    return MassDensity(nn);
  }
  double MassDensityGCCGivenTemperatureAndPressure(const double T, const double P, const bool strict=true) {
    double nn = DensityGivenTemperatureAndPressure(T,P,strict);
    return MassDensityGCC(nn);
  }
  double PressureErrorBarGivenTemperatureAndPressure(const double T, const double P, const bool strict=true) {
    double nn = DensityGivenTemperatureAndPressure(T,P,strict);
    return PressureErrorBar(nn,T);
  }
  double EnergyGivenTemperatureAndPressure(const double T, const double P, const bool strict=true) {
    double nn = DensityGivenTemperatureAndPressure(T,P,strict);
    return Energy(nn,T);
  }
  double EnergyErrorBarGivenTemperatureAndPressure(const double T, const double P, const bool strict=true) {
    double nn = DensityGivenTemperatureAndPressure(T,P,strict);
    return EnergyErrorBar(nn,T);
  }
  double VolumeFormulaUnitGivenTemperatureAndPressure(const double T, const double P, const bool strict=true) {
    double nn = DensityGivenTemperatureAndPressure(T,P,strict);
    return 1.0/nn;
  }
  double VolumeNFormulaUnitsGivenTemperatureAndPressure(const double T, const double P, const double mFU, const bool strict=true) {
    return mFU * VolumeFormulaUnitGivenTemperatureAndPressure(T,P);
  }
  double VolumeNAtomsGivenTemperatureAndPressure(const double T, const double P, const double nAtoms, const bool strict=true) {
    return VolumeFormulaUnitGivenTemperatureAndPressure(T,P,strict) * nAtoms / nFU;
  }
 private:
  //return true if difference is less then 1e-06
  bool EqualAbs(const double a, const double b, const double eps=1e-6) const {
    double d = fabs(a-b);
    return d<eps;
  }
  //return true if relative difference is less then 1e-06
  bool EqualRel(const double a, const double b, const double eps=1e-6) const {
    double d = fabs(a-b);
    double m = max(fabs(a),fabs(b));
    return d<eps*m;
  }
  //return true if difference is less then 1e-06
  bool Equal(const double a, const double b, const double eps=1e-6) const {
    //    return EqualAbs(a,b,eps);
    return EqualRel(a,b,eps);
  }

  void FindInCurrentTable(const double nn, const double T, int & inn, int & iT) const;
  int FindTableIndex(const Array1 <double> x, 
		     const Array1 <double> y, 
		     const double xx, 
		     const double yy) const;
  int FindBigger(const Array1 <double> & x, const double xmin) const;
  void FindAllValues(const Array1<double> & x,
		     Array1 <double> & tx) const;
  int FindFirstYForGivenX(const Array1 <double> x, 
			  const Array1 <double> y, 
			  const double xx) const;
  int FindNextYForGivenX(const Array1 <double> x, 
			 const Array1 <double> y, 
			 const double xx, const double yy) const;


  void PutIn1DArraysSlow(const Array1<double> & x,
			 const Array1<double> & y,
			 Array1 <double> & tx,
			 Array1 <Array1<int> > & lists);
  void PutIn1DArrays(const Array1<double> & x,
		     const Array1<double> & y,
		     Array1 <double> & tx,
		     Array1 <Array1<int> > & lists);
 public:
  void GetTemperatureArray(Array1 <double> & TT) const;
  void SetUpTemperatureArray() {
    GetTemperatureArray(tT);
  }
  Array1 <double> GetTemperatureArray() const {
    Array1 <double> TT;
    GetTemperatureArray(TT);
    return TT;
  }
  void AddEOSPoints(const int nPoints, 
		     const Array1 <double> & nnNew,
		     const Array1 <double> & TNew,
		     const Array1 <double> & TENew,
		     const Array1 <double> & ppNew,
		     const Array1 <double> & PENew,
		     const Array1 <double> & eeNew,
		     const Array1 <double> & eENew);
  void AddEOSPoints(const int nPoints, 
		     const Array1 <double> & nnNew,
		     const Array1 <double> & TNew,
		     const Array1 <double> & ppNew,
		     const Array1 <double> & PENew,
		     const Array1 <double> & eeNew,
		     const Array1 <double> & eENew);
  void AddEOSPoints(const int nPoints, 
		    const Array1 <double> & nnNew,
		    const Array1 <double> & TNew,
		    const Array1 <double> & ppNew,
		    const Array1 <double> & eeNew);
  void AddOneEOSPoint(const double nnNew, const double TNew, 
		      const double ppNew, const double pENew, 
		      const double eeNew, const double eENew); // does not call PutIn1DArrays(...)
  void FinishedAddingEOSPoints() { PutIn1DArrays(nn,T,tnn,lists); } // process the 1D arrays pp, pE etc one more time

 private:
  void ReadTable(const string & fileName,
		 const int nRS, 
		 const int nT,
		 const int nTE,
		 const int nP, 
		 const int nPE,
		 const int nE, 
		 const int nEE,
		 const double fT,
		 const double fP,
		 const double fE,
		 const bool errorbars_,
		 const bool errorbarsT_);
  void ReadTable(const string & fileName,
		 const int nRS, 
		 const int nT,
		 const int nTE,
		 const int nP, 
		 const int nPE,
		 const int nE, 
		 const int nEE,
		 const int nF, 
		 const int nFE,
		 const int nS, 
		 const int nSE,
		 const double qT,
		 const double qP,
		 const double qE,
		 const double qF,
		 const double qS,
		 const bool errorBars_,
		 const bool errorBarsT_);
  double Interpolate2D(const double nnn, const double TT, const Array1 <double> & f) const {
    double TTLast=-1.0;
    Spline sLast;
    return Interpolate2D(nnn,TT,f,TTLast,sLast);
  }
  double Interpolate2D(const double nnn, const double TT, const Array1 <double> & f,
		       double & TTLast, Spline & sLast) const;
  double Interpolate1D(const Array1 <int> & list, 
		       const Array1 <double> & y,
		       const Array1 <double> & f,
		       const double yy) const;
  double LinearInterpolation(const double x1, const double y1,
			     const double x2, const double y2,
			     const double xx) const;

 private:

  Spline MakeSpline(const Array1 <int> & list, 
		    const Array1 <double> & y,
		    const Array1 <double> & f,
		    const double fy0,
		    const double fyn) const {
    Spline s(list.Size());
    for(int i=0; i<list.Size(); i++) {
      s.PushBack(y[list[i]],f[list[i]]);
    }
    s.Init(false,fy0,fyn); // make spline with given first derivatives at the end
    return s;
  }

 public:
  int NumberOfDecimals(const Array1 <double> & nn) const;
  void AddReference(const string & reference_) {
    reference.PushBack(reference_);
    //    Write(reference);
  }
  void PrintFirstReference() const {
    if (reference.Size()>0) {
      cout << reference[0] << endl;
      cout << endl;
    }
  }
  void PrintAllReferences() const {
    for(int i=0; i<reference.Size(); i++) {
      cout << reference[i] << endl;
      cout << endl;
    }
  }
  void ExtractReferencesFromFile(const string & fileName);
  void PrintString(ofstream & of, const string & s, const int l, const bool center=false) const;
  int MaxLength(const Array1 <string> & s) const;
  Array1 <string> SplitString(const string & s) const;

  void SwitchToLogInterpolation() {
    if (ee.Min() <= 0.0 ) {
      double EShift = -ee.Min()*2.0;
      cout << "To enable log(T) interpolation, adding shift to all energies of " << EShift << endl;
      ee += EShift;
      if (hugoniotFlag) hugoniotE0 += EShift;
    }
    if (hugoniotFlag && hugoniotP0<0.0) {
      hugoniotP0 = 1.0*PC::GPaToAU;
    }
    argT.SwitchToLogInterpolation();
    argF.SwitchToLogInterpolation();
  }

  void PrintInfo() const {
    cout << "EOS table              : " << GetName() << endl;
    cout << "Number of points       : " << n << endl;
    cout << "Number of isochores    : " << tnn.Size() << endl;
    cout << "Lowest  density [g/cc] : " << MassDensityGCC(tnn.First()) << endl;
    cout << "Highest density [g/cc] : " << MassDensityGCC(tnn.Last()) << endl;
    cout << "Lowest  temperature [K]: " << GetMinimumTemperature()*PC::AUToK << endl;
    cout << "Highest temperature [K]: " << GetMaximumTemperature()*PC::AUToK << endl;
    cout << "References: " << reference.Size() << endl;
    for(int i=0; i<reference.Size(); i++) {
      cout << "(" << i+1 << ") " << reference[i] << endl;
    }
    cout << endl;
    /*
    string s = " & ";
    cout << GetName();
    cout << s << tnn.Size();
    cout << s << fix(5,3,MassDensityGCC(tnn.First()));
    cout << s << fix(6,3,MassDensityGCC(tnn.Last()));
    cout << s << fix(5,0,GetMinimumTemperature()*PC::AUToK);
    cout << s << sci(10,3,GetMaximumTemperature()*PC::AUToK);
    cout << s << n << " \\\\" << endl;
    */
  }

  void SetDatabaseIndex(const int index) {
    databaseIndex = index;
  }
  int GetDatabaseIndex() const {
    return databaseIndex;
  }

};

#endif // _EOSTABLE_
